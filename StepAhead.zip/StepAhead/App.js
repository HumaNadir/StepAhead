import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';

import AccountType from './src/screens/AccountType';
import Login from './src/screens/Login';
import ForgetPassword from './src/screens/ForgetPassword';
import Verification from './src/screens/Verification';
import ChangePassword from './src/screens/ChangePassword';

//admin
import RegisterTeacher from './src/screens/Admin/RegisterTeacher';
import RegisterStudent from './src/screens/Admin/RegisterStudent';

import TabNavigation from './src/Navigation/TabNavigation';

const Stack = createStackNavigator();
const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{headerShown: false}}>
        <Stack.Screen name="AccountType" component={AccountType} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="ForgetPassword" component={ForgetPassword} />
        <Stack.Screen name="Verification" component={Verification} />
        <Stack.Screen name="ChangePassword" component={ChangePassword} />
        <Stack.Screen name="RegisterTeacher" component={RegisterTeacher} />
        <Stack.Screen name="RegisterStudent" component={RegisterStudent} />
        <Stack.Screen name="TabNavigation" component={TabNavigation} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;

const styles = StyleSheet.create({});
