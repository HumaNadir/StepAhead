const appImages = {
  logo: require('../images/logo.jpeg'),
  logo1: require('../images/logo1.png'),
  announcement: require('../images/announcement.png'),
  graph: require('../images/graph.png'),
  group: require('../images/group.png'),
  teach: require('../images/teach.png'),
  student_registration: require('../images/student_registration.png'),
  profile: require('../images/profile.png'),
};

export default appImages;
