import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import React, {useState} from 'react';
import appColors from '../../../../assets/colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appFonts from '../../../../assets/fonts';
import Header from '../../../components/Header';
import CTextInput from '../../../components/CTextInput';
import Feather from 'react-native-vector-icons/Feather';
import CButton from '../../../components/CButton/CButton';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import FontistoIcon from 'react-native-vector-icons/Fontisto';

import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import DocumentPicker, {types} from 'react-native-document-picker';

const RegisterTeacher = () => {
  const [teacherName, setTeacherName] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [email, setEmail] = useState('');
  const [contactNo, setContactNo] = useState('');
  const [address, setAddress] = useState('');
  const [picture, setPicture] = useState('');
  const [pictureName, setPictureName] = useState('');
  const [pictureType, setPictureType] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [file, setFile] = useState({
    name: '',
    uri: '',
    type: '',
  });

  const handleCVPick = async () => {
    try {
      const response = await DocumentPicker.pick({
        presentationStyle: 'fullScreen',
        type: [types.pdf],
      });
      setFile({
        name: response[0].name,
        uri: response[0].uri,
        type: response[0].type,
      });
    } catch (err) {
      console.warn(err);
    }
  };
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <Header title={'Add Teacher'} />
        <View style={{flex: 1, alignItems: 'center'}}>
          <CTextInput
            state={teacherName}
            onChangeText={txt => setTeacherName(txt)}
            placeholder={'Teacher Name'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="teacherName"
          />
          <CTextInput
            state={contactNo}
            onChangeText={txt => setContactNo(txt)}
            placeholder={'Contact No'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="contactNo"
          />
          <CTextInput
            state={email}
            onChangeText={txt => setEmail(txt)}
            placeholder={'Email'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="email"
          />

          <CTextInput
            state={address}
            onChangeText={txt => setAddress(txt)}
            placeholder={'Address'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="address"
          />
          <View style={styles.textInputContainer}>
            <View style={styles.txtInputView}>
              <View
                style={{
                  flex: 1,
                }}>
                {file.name ? (
                  <Text
                    style={{
                      width: '90%',
                      color: appColors.dark,
                      fontSize: 13,
                    }}>
                    {file.name}
                  </Text>
                ) : (
                  <Text style={{marginLeft: 15, color: '#D5D5D5'}}>CV</Text>
                )}
              </View>

              <TouchableOpacity onPress={() => handleCVPick()}>
                <Feather name="upload" size={25} color={appColors.dark} />
              </TouchableOpacity>
            </View>
          </View>
          <CTextInput
            state={password}
            onChangeText={txt => setPassword(txt)}
            secureTextEntry={!showPassword}
            placeholder={'Password'}
            id="password"
            setIsActive={setIsActive}
            containerStyle={{width: wp(85)}}
            leftIcon={
              <FontistoIcon
                name="locked"
                size={wp(5)}
                color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
              />
            }
            rightIcon={
              <EntypoIcon
                onPress={() => setShowPassword(!showPassword)}
                name={!showPassword ? 'eye-with-line' : 'eye'}
                size={wp(5)}
                color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
              />
            }
          />
          <View
            style={{
              flex: 0.7,
              justifyContent: 'flex-end',
            }}>
            <CButton title="ADD" />
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default RegisterTeacher;

const styles = StyleSheet.create({
  textInputContainer: {
    marginVertical: hp(2),
    width: wp(85),
  },
  txtInputView: {
    borderWidth: 1.2,
    borderColor: '#D2D2D2',
    borderRadius: wp(1.5),
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: wp(2.5),
    height: hp(6.4),
  },
});
