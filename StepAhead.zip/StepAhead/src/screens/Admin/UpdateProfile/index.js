import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Image,
  InputAccessoryView,
} from 'react-native';
import React, {useState} from 'react';
import appColors from '../../../../assets/colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appFonts from '../../../../assets/fonts';
import Header from '../../../components/Header';
import CTextInput from '../../../components/CTextInput';
import Feather from 'react-native-vector-icons/Feather';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import FontistoIcon from 'react-native-vector-icons/Fontisto';
import CButton from '../../../components/CButton/CButton';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import appImages from '../../../../assets/images';

const UpdateProfile = () => {
  const [studentName, setStudentName] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [email, setEmail] = useState('');
  const [contactNo, setContactNo] = useState('');
  const [address, setAddress] = useState('');
  const [picture, setPicture] = useState('');
  const [pictureName, setPictureName] = useState('');
  const [pictureType, setPictureType] = useState('');
  const [isActive, setIsActive] = useState(false);

  const [userName, setUserName] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [phoneNo, setPhoneNo] = useState('');

  const [showCurrentPass, setShowCurrentPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);

  //pick image from gallery if
  const handleImagePicker = async () => {
    var options = {
      storageOptions: {
        skipBackup: true,
        path: 'images',
      },
      maxWidth: 500,
      maxHeight: 500,
      quality: 0.5,
    };
    await launchImageLibrary(options)
      .then(res => {
        setPictureName(res?.assets[0]?.fileName);
        setPictureType(res?.assets[0]?.type);
        setPicture(res?.assets[0]?.uri);
      })
      .catch(error => {
        console.log('error  :  ', error);
      });
  };
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <Header title={'Update Profile'} />
        <View style={{flex: 1, alignItems: 'center'}}>
          <View
            style={{
              width: wp(40),
              height: wp(40),
              borderRadius: wp(40) / 2,

              marginVertical: 18,

              //   overflow: 'hidden',
            }}>
            {picture ? (
              <Image
                source={{uri: picture}}
                style={{
                  width: wp(40),
                  height: wp(40),
                  borderRadius: wp(40) / 2,
                  borderWidth: 1,
                  borderColor: appColors.primary,
                  // width: wp(26),
                  // height: wp(26),
                  // borderRadius: wp(40) / 2,
                  // tintColor: appColors.primary,
                  resizeMode: 'contain',
                }}
              />
            ) : (
              <View
                style={{
                  width: wp(40),
                  height: wp(40),
                  borderRadius: wp(40) / 2,
                  overflow: 'hidden',
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderWidth: 1,
                  borderColor: appColors.primary,
                }}>
                <Image
                  source={appImages.profile}
                  style={{
                    width: wp(26),
                    height: wp(26),
                    // borderRadius: wp(40) / 2,
                    tintColor: appColors.primary,
                    resizeMode: 'contain',
                  }}
                />
              </View>
            )}
            <TouchableOpacity
              onPress={() => handleImagePicker()}
              style={{position: 'absolute', right: -10, top: '60%', zIndex: 1}}>
              <FontAwesome name="camera" size={30} color={appColors.primary} />
            </TouchableOpacity>
          </View>
          <CTextInput
            state={userName}
            onChangeText={txt => setUserName(txt)}
            placeholder={'User Name'}
            setIsActive={setIsActive}
            isActive={isActive}
            containerStyle={{width: wp(85)}}
            id="userName"
            leftIcon={
              <FontAwesome
                name="user"
                size={wp(5)}
                color={isActive == 'userName' ? appColors.primary : '#D2D2D2'}
              />
            }
          />

          <CTextInput
            state={currentPassword}
            onChangeText={txt => setCurrentPassword(txt)}
            placeholder={'Current Password'}
            secureTextEntry={!showCurrentPass}
            id="currentPassword"
            setIsActive={setIsActive}
            containerStyle={{width: wp(85)}}
            leftIcon={
              <FontistoIcon
                name="locked"
                size={wp(5)}
                color={
                  isActive == 'currentPassword' ? appColors.primary : '#D2D2D2'
                }
              />
            }
            rightIcon={
              <EntypoIcon
                onPress={() => setShowCurrentPass(!showCurrentPass)}
                name={!showCurrentPass ? 'eye-with-line' : 'eye'}
                size={wp(5)}
                color={
                  isActive == 'currentPassword' ? appColors.primary : '#D2D2D2'
                }
              />
            }
          />

          <CTextInput
            state={newPassword}
            onChangeText={txt => setNewPassword(txt)}
            placeholder={'New Password'}
            secureTextEntry={!showNewPass}
            id="newPassword"
            setIsActive={setIsActive}
            containerStyle={{width: wp(85)}}
            leftIcon={
              <FontistoIcon
                name="locked"
                size={wp(5)}
                color={
                  isActive == 'newPassword' ? appColors.primary : '#D2D2D2'
                }
              />
            }
            rightIcon={
              <EntypoIcon
                onPress={() => setShowNewPass(!showNewPass)}
                name={!showNewPass ? 'eye-with-line' : 'eye'}
                size={wp(5)}
                color={
                  isActive == 'newPassword' ? appColors.primary : '#D2D2D2'
                }
              />
            }
          />

          <CTextInput
            state={phoneNo}
            onChangeText={txt => setPhoneNo(txt)}
            placeholder={'Phone No'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="phoneNo"
            containerStyle={{width: wp(85)}}
            keyboardType={'phone-pad'}
            leftIcon={
              <EntypoIcon
                name="phone"
                size={wp(5)}
                color={isActive == 'phoneNo' ? appColors.primary : '#D2D2D2'}
              />
            }
          />

          <CButton title="Update" />
        </View>
      </ScrollView>
    </View>
  );
};

export default UpdateProfile;

const styles = StyleSheet.create({
  textInputContainer: {
    marginVertical: hp(2),
    width: wp(90),
  },
  txtInputView: {
    borderWidth: 1.2,
    borderColor: '#D2D2D2',
    borderRadius: wp(1.5),
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: wp(2.5),
    height: hp(6.4),
  },
});
