import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Image,
  TextInput,
} from 'react-native';
import React, {useState} from 'react';
import Header from '../../../components/Header';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import appColors from '../../../../assets/colors';
import appFonts from '../../../../assets/fonts';
import appImages from '../../../../assets/images';
import Modal from 'react-native-modal';
import CTextInput from '../../../components/CTextInput';
import CButton from '../../../components/CButton/CButton';

const Announcements = ({navigation}) => {
  const [announcement, setAnnouncement] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [isLike, setIsLike] = useState(false);

  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <Header
          showLeftIcon={false}
          rightIcon={
            <View style={{flexDirection: 'row'}}>
              <TouchableOpacity
                style={{marginHorizontal: wp(2)}}
                onPress={() => setIsVisible(true)}>
                <Ionicons name="add-circle" size={25} color={'#FFFFFF'} />
              </TouchableOpacity>
              <TouchableOpacity
                style={{marginHorizontal: wp(2)}}
                onPress={() => navigation?.replace('Login')}>
                <MaterialCommunityIcons
                  name="logout"
                  size={25}
                  color={'#FFFFFF'}
                />
              </TouchableOpacity>
            </View>
          }
        />
        <View style={{flex: 1, alignItems: 'center'}}>
          <Text
            style={{
              marginTop: hp(8),
              color: appColors.dark,
              fontSize: 18,
              fontFamily: appFonts.Time_New_Roman_Bold,
            }}>
            Recent Announcements
          </Text>
          <View style={styles.card}>
            {/* <View style={{flex: 1}}> */}
            <Text style={{color: appColors.dark, fontSize: 14}}>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text
              ever since the 1500s,
            </Text>
            {/* </View> */}
            <View style={styles.line}></View>
            <View style={styles.rowView}>
              <TouchableOpacity onPress={() => setIsLike(!isLike)}>
                <AntDesign
                  name="like2"
                  size={30}
                  color={isLike ? appColors.primary : appColors.dark}
                />
              </TouchableOpacity>
              <Image
                source={appImages.announcement}
                style={styles.commentImage}
              />
            </View>
          </View>
        </View>

        <Modal
          isVisible={isVisible}
          onBackdropPress={() => setIsVisible(false)}>
          <View
            style={{
              backgroundColor: '#fff',
              padding: 20,
              borderRadius: 10,
              alignItems: 'center',
            }}>
            <Text
              style={{
                color: appColors.dark,
                fontSize: 18,
                fontFamily: appFonts.Time_New_Roman_Bold,
              }}>
              Create Announcement
            </Text>
            <TextInput
              style={styles.input}
              value={announcement}
              onChangeText={text => setAnnouncement({text})}
              multiline={true}
              underlineColorAndroid="transparent"
              numberOfLines={5}
            />
            <CButton
              title="Create"
              width={wp(40)}
              height={hp(6)}
              onPress={() => setIsVisible(false)}
            />
          </View>
        </Modal>
      </ScrollView>
    </View>
  );
};

export default Announcements;

const styles = StyleSheet.create({
  card: {
    width: wp(90),
    // height: hp(30),
    padding: wp(6),
    marginVertical: hp(3),
    borderRadius: wp(3),
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.29,
    shadowRadius: 4.65,

    elevation: 7,
  },
  line: {
    borderTopWidth: 1,
    borderColor: '#D5D5D5',
    width: '100%',
    alignSelf: 'center',
    marginVertical: 15,
  },
  rowView: {flexDirection: 'row', alignItems: 'center'},
  commentImage: {
    width: wp(8),
    height: wp(8),
    marginHorizontal: wp(4),
    tintColor: appColors.dark,
  },
  input: {
    borderWidth: 1,
    borderColor: '#D5D5D5',
    borderRadius: 10,
    marginVertical: wp(8),
    width: wp(80),
  },
});
