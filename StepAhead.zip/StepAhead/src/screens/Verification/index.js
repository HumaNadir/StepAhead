import {StyleSheet, Text, View, ScrollView} from 'react-native';
import React, {useState} from 'react';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import AuthHeader from '../../components/AuthHeader';
import appColors from '../../../assets/colors';
import appFonts from '../../../assets/fonts';
import CButton from '../../components/CButton/CButton';
const Verification = ({navigation}) => {
  const [otpCode, setOtpCode] = useState('');
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <AuthHeader showLogo={true} showBackIcon />
        <View style={{flex: 1, paddingHorizontal: wp(5), marginTop: -25}}>
          <Text
            style={{
              color: appColors.dark,
              fontFamily: appFonts.Time_New_Roman_Bold,
              lineHeight: 40,
              fontSize: 16,
            }}>
            Verification
          </Text>
          <Text
            style={{
              color: appColors.dark,
              fontSize: 14,
              //   fontFamily: appFonts.Time_New_Roman,
            }}>
            Enter the verification code that you received on your email
          </Text>
          <View style={{height: hp(35)}}>
            <OTPInputView
              style={{
                height: 50,
                marginTop: hp(7),
              }}
              pinCount={4}
              code={otpCode}
              onCodeChanged={code => {
                setOtpCode(code);
              }}
              autoFocusOnLoad={true}
              placeholderCharacter={''}
              placeholderTextColor={'#ABA7AF'}
              codeInputFieldStyle={{
                ...styles.underlineStyleBase,
              }}
              codeInputHighlightStyle={{
                ...styles.underlineStyleHighLighted,
              }}
            />
          </View>
          <CButton
            title="Verify"
            onPress={() => navigation.navigate('ChangePassword')}
          />
        </View>
      </ScrollView>
    </View>
  );
};

export default Verification;

const styles = StyleSheet.create({
  underlineStyleBase: {
    color: '#000000',
    fontSize: 24,
    fontFamily: 'Rubik-Bold',
    width: 60,
    height: 50,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#CCC',
    marginHorizontal: 5,
  },
  underlineStyleHighLighted: {
    borderColor: appColors.primary,
    borderWidth: 1.2,
  },
});
