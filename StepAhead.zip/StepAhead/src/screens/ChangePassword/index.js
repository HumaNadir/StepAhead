import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ScrollView,
} from 'react-native';
import React, {useState} from 'react';
import AuthHeader from '../../components/AuthHeader';
import appColors from '../../../assets/colors';
import appFonts from '../../../assets/fonts';
import CTextInput from '../../components/CTextInput';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import CButton from '../../components/CButton/CButton';

import EntypoIcon from 'react-native-vector-icons/Entypo';
import FontistoIcon from 'react-native-vector-icons/Fontisto';
import Snackbar from 'react-native-snackbar';

const ChangePassword = ({navigation}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleChangePassword = () => {
    Snackbar.show({
      text: 'Password updated successfully',
      duration: Snackbar.LENGTH_SHORT,
      backgroundColor: 'green',
    });
  };
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <View style={{flex: 1}}>
          <AuthHeader showBackIcon />
          <View style={{flex: 1, alignItems: 'center'}}>
            <Text
              style={{
                color: appColors.dark,
                fontSize: 22,
                fontFamily: appFonts.Time_New_Roman_Bold,
                marginBottom: hp(4),
              }}>
              Change Password
            </Text>

            <CTextInput
              state={password}
              onChangeText={txt => setPassword(txt)}
              secureTextEntry={!showPassword}
              id="password"
              setIsActive={setIsActive}
              containerStyle={{width: wp(85)}}
              leftIcon={
                <FontistoIcon
                  name="locked"
                  size={wp(5)}
                  color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
                />
              }
              rightIcon={
                <EntypoIcon
                  onPress={() => setShowPassword(!showPassword)}
                  name={!showPassword ? 'eye-with-line' : 'eye'}
                  size={wp(5)}
                  color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
                />
              }
            />
            <CTextInput
              state={confirmPassword}
              onChangeText={txt => setConfirmPassword(txt)}
              secureTextEntry={!showConfirmPassword}
              id="confirmPassword"
              setIsActive={setIsActive}
              containerStyle={{width: wp(85)}}
              leftIcon={
                <FontistoIcon
                  name="locked"
                  size={wp(5)}
                  color={
                    isActive == 'confirmPassword'
                      ? appColors.primary
                      : '#D2D2D2'
                  }
                />
              }
              rightIcon={
                <EntypoIcon
                  onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                  name={!showConfirmPassword ? 'eye-with-line' : 'eye'}
                  size={wp(5)}
                  color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
                />
              }
            />

            <CButton title="Change" onPress={() => handleChangePassword()} />
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default ChangePassword;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});
