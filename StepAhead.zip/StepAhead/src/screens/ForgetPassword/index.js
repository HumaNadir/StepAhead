import {StyleSheet, Text, View, ScrollView} from 'react-native';
import React, {useState, useEffect} from 'react';
import AuthHeader from '../../components/AuthHeader';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appColors from '../../../assets/colors';
import appFonts from '../../../assets/fonts';
import CTextInput from '../../components/CTextInput';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import CButton from '../../components/CButton/CButton';

const ForgetPassword = ({navigation}) => {
  const [email, setEmail] = useState('');
  const [isActive, setIsActive] = useState(false);
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <AuthHeader showLogo={true} showBackIcon />
        <View style={{flex: 1, alignItems: 'center'}}>
          <Text style={styles.heading}>Forgot your password?</Text>
          <CTextInput
            heading={'Email'}
            state={email}
            onChangeText={txt => setEmail(txt)}
            placeholder={'Enter your email'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="email"
            containerStyle={{width: wp(85)}}
            leftIcon={
              <MaterialCommunityIcons
                name="email"
                size={wp(5)}
                color={isActive == 'email' ? appColors.primary : '#D2D2D2'}
              />
            }
          />
          <CButton
            title="Send Verification Code"
            width={wp(80)}
            onPress={() => navigation.navigate('Verification')}
          />
          <CButton
            title="Cancel"
            width={wp(50)}
            onPress={() => navigation?.goBack()}
          />
        </View>
      </ScrollView>
    </View>
  );
};

export default ForgetPassword;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  heading: {
    color: appColors.dark,
    fontSize: 22,
    fontFamily: appFonts.Time_New_Roman_Bold,
    marginBottom: hp(4),
  },
});
