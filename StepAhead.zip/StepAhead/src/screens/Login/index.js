import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ScrollView,
} from 'react-native';
import React, {useState} from 'react';
import AuthHeader from '../../components/AuthHeader';
import appColors from '../../../assets/colors';
import appFonts from '../../../assets/fonts';
import CTextInput from '../../components/CTextInput';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import CButton from '../../components/CButton/CButton';

import EntypoIcon from 'react-native-vector-icons/Entypo';
import FontistoIcon from 'react-native-vector-icons/Fontisto';

const Login = ({navigation}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = () => {
    // navigation.navigate('RegisterStudent');
    navigation.navigate('TabNavigation');
  };
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <View style={{flex: 1}}>
          <AuthHeader />
          <View style={{flex: 1, alignItems: 'center'}}>
            <Text
              style={{
                color: appColors.dark,
                fontSize: 22,
                fontFamily: appFonts.Time_New_Roman_Bold,
                marginBottom: hp(4),
              }}>
              Login
            </Text>

            <CTextInput
              // heading={'Email Address'}
              state={email}
              onChangeText={txt => setEmail(txt)}
              placeholder={'Email'}
              setIsActive={setIsActive}
              isActive={isActive}
              id="email"
              containerStyle={{width: wp(85)}}
              leftIcon={
                <FontistoIcon
                  name="email"
                  size={wp(5)}
                  color={isActive == 'email' ? appColors.primary : '#D2D2D2'}
                />
              }
            />

            <CTextInput
              state={password}
              onChangeText={txt => setPassword(txt)}
              secureTextEntry={!showPassword}
              id="password"
              setIsActive={setIsActive}
              containerStyle={{width: wp(85)}}
              leftIcon={
                <FontistoIcon
                  name="locked"
                  size={wp(5)}
                  color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
                />
              }
              rightIcon={
                <EntypoIcon
                  onPress={() => setShowPassword(!showPassword)}
                  name={!showPassword ? 'eye-with-line' : 'eye'}
                  size={wp(5)}
                  color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
                />
              }
            />

            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => navigation.navigate('ForgetPassword')}>
              <Text
                style={{
                  color: appColors.primary,
                  textAlign: 'right',
                  width: wp(85),
                }}>
                Forgot Password?
              </Text>
            </TouchableOpacity>

            <CButton title="Login" onPress={() => handleLogin()} />
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default Login;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});
