import {
  StyleSheet,
  Text,
  View,
  Image,
  StatusBar,
  useColorScheme,
} from 'react-native';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import appFonts from '../../../assets/fonts';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import appColors from '../../../assets/colors';

import RegisterStudent from '../../screens/Admin/RegisterStudent';
import RegisterTeacher from '../../screens/Admin/RegisterTeacher';
import Announcements from '../../screens/Admin/Announcements';
import UpdateProfile from '../../screens/Admin/UpdateProfile';

import appImages from '../../../assets/images';
const Tab = createBottomTabNavigator();

const TabNavigation = () => {
  return (
    <Tab.Navigator
      screenOptions={({route}) => ({
        headerShown: false,
        tabBarShowLabel: false,
        tabBarIcon: ({focused, color, size, title}) => {
          color = focused ? appColors.primary : '#888888';
          let iconName;
          let image = null;
          image = appImages.logo;

          if (route.name === 'RegisterStudent') {
            image = appImages.student_registration;
          } else if (route.name === 'RegisterTeacher') {
            image = appImages.teach;
          } else if (route.name === 'Announcements') {
            image = appImages.announcement;
          } else if (route.name === 'UpdateProfile') {
            image = appImages.profile;
          }

          // You can return any component that you like here!
          return (
            <>
              {route.name === 'RegisterTeacher' && (
                <Image
                  source={image}
                  style={{
                    tintColor: color,
                    height: wp(10),
                    width: wp(10),
                    resizeMode: 'contain',
                  }}
                />
              )}
              {route.name === 'RegisterStudent' && (
                <Image
                  source={image}
                  style={{
                    tintColor: color,
                    height: wp(8),
                    width: wp(8),
                    resizeMode: 'contain',
                  }}
                />
              )}
              {route.name === 'Announcements' && (
                <Image
                  source={image}
                  style={{
                    tintColor: color,
                    height: wp(7),
                    width: wp(7),
                    resizeMode: 'contain',
                  }}
                />
              )}
              {route.name === 'UpdateProfile' && (
                <Image
                  source={image}
                  style={{
                    tintColor: color,
                    height: wp(7),
                    width: wp(7),
                    resizeMode: 'contain',
                  }}
                />
              )}
            </>
          );
        },
      })}>
      <Tab.Screen name="RegisterStudent" component={RegisterStudent} />
      <Tab.Screen name="Announcements" component={Announcements} />
      <Tab.Screen name="RegisterTeacher" component={RegisterTeacher} />
      <Tab.Screen name="UpdateProfile" component={UpdateProfile} />
    </Tab.Navigator>
  );
};

export default TabNavigation;
