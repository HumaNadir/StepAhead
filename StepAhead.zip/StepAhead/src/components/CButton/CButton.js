import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
  Image,
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appColors from '../../../assets/colors';

const CButton = ({
  title = '',
  onPress,
  loading = false,
  bgColor,
  color,
  marginTop,
  bold = false,
  txtSize = 14,
  transparent,
  style,
  height,
  width,
  padding,
  disabled,
  iconImage,
  activeOpacity,
}) => {
  return (
    <TouchableOpacity
      activeOpacity={activeOpacity ? activeOpacity : 0.8}
      disabled={disabled ? disabled : loading}
      style={{
        ...styles.btn,
        height: height ? height : hp(6.7),
        width: width ? width : wp(90),
        padding: padding ? padding : 0,
        backgroundColor: transparent
          ? 'transparent'
          : bgColor
          ? bgColor
          : appColors.primary,
        marginTop: marginTop ? marginTop : hp(3),
        ...style,
      }}
      onPress={onPress}>
      {loading && (
        <ActivityIndicator color={appColors.primary} size={'small'} />
      )}
      {title && (
        <Text
          style={{
            ...styles.btnText,
            fontWeight: bold ? 'bold' : 'normal',
            color: transparent
              ? color
                ? color
                : appColors.primary
              : color
              ? color
              : appColors.white,
            fontSize: txtSize,
          }}>
          {title}
        </Text>
      )}

      {iconImage && (
        <Image
          source={iconImage}
          style={{
            height: wp(6.5),
            width: wp(6.5),
            resizeMode: 'contain',
          }}
        />
      )}
    </TouchableOpacity>
  );
};

export default CButton;

const styles = StyleSheet.create({
  btn: {
    backgroundColor: appColors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: wp(8),
    marginTop: hp(3),
    alignSelf: 'center',
    flexDirection: 'row',
  },
  btnText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '500',
    marginHorizontal: wp(3),
  },
});
