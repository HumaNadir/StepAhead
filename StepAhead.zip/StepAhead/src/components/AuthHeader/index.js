import {
  StyleSheet,
  Text,
  View,
  StatusBar,
  Image,
  TouchableOpacity,
} from 'react-native';
import React from 'react';
import appColors from '../../../assets/colors';
import appImages from '../../../assets/images';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {useNavigation} from '@react-navigation/native';
const AuthHeader = ({showLogo, showBackIcon}) => {
  const navigation = useNavigation();
  return (
    <View
      style={{
        flex: 0.5,
        marginBottom: showLogo == false ? '10%' : '25%',
        backgroundColor: appColors.primary,
        paddingHorizontal: wp(5),
        paddingTop: 10,
      }}>
      <StatusBar
        backgroundColor={appColors.primary}
        barStyle={'light-content'}
      />
      {showBackIcon && (
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Icon name="arrow-back-ios" size={25} color={'#fff'} />
        </TouchableOpacity>
      )}
      {showLogo == false ? null : (
        <View style={{bottom: -70, position: 'absolute', left: 0, right: 0}}>
          <Image
            source={appImages.logo1}
            style={{
              width: wp(42),
              height: wp(42),
              resizeMode: 'contain',
              // position: 'absolute',
              // top: '65%',
              // left: '34.5%',
              alignSelf: 'center',
            }}
          />
        </View>
      )}
    </View>
  );
};

export default AuthHeader;

const styles = StyleSheet.create({});
