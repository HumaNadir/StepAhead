const appImages = {
  logo: require('../images/logo.jpeg'),
  logo1: require('../images/logo1.png'),
  announcement: require('../images/announcement.png'),
  graph: require('../images/graph.png'),
  group: require('../images/group.png'),
  teach: require('../images/teach.png'),
  student_registration: require('../images/student_registration.png'),
  profile: require('../images/profile.png'),
  user: require('../images/user.jpg'),

  normal: require('../images/normal.png'),
  sadEmoji: require('../images/sadEmoji.png'),
  smile: require('../images/smile.png'),

  kitchening: require('../images/kitchening.png'),
  sports: require('../images/sports.png'),
  toileting: require('../images/toileting.png'),
  lunch: require('../images/lunch.png'),

  notes: require('../images/notes.png'),
  send: require('../images/send.png'),
  camera: require('../images/camera.png'),
};

export default appImages;
