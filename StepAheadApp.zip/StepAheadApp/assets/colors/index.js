const appColors = {
  primary: '#6267d4',
  dark: '#2D333A',
  black: '#000',
  white: '#fff',
};
export default appColors;
