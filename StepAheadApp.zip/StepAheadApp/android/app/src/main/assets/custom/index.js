const appFonts = {
  Time_New_Roman_Bold_Italic: 'times new roman bold italic',
  Time_New_Roman_Bold: 'times new roman bold',
  Time_New_Roman_Italic: 'times new roman italic',
  Time_New_Roman: 'times new roman',
};

export default appFonts;
