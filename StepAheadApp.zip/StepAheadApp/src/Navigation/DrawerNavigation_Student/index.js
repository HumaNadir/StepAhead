import React, {useState, useEffect} from 'react';
import {Button, View, StyleSheet, Image, Text} from 'react-native';
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItem,
} from '@react-navigation/drawer';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';

import {
  NavigationContainer,
  useFocusEffect,
  useNavigation,
} from '@react-navigation/native';

import FontAwesome from 'react-native-vector-icons/FontAwesome';

import appColors from '../../../assets/colors';
import appImages from '../../../assets/images';
import {Avatar} from 'react-native-paper';
import CButton from '../../components/CButton/CButton';

import TabNavigation_Student from '../TabNavigation_Student';
import UpdateProfile from '../../screens/UpdateProfile';
import ChangePassword from '../../screens/ChangePassword';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {BASE_URL_Image} from '../../constants/api';

const Drawer = createDrawerNavigator();

const CustomDrawerContent = props => {
  const navigation = useNavigation();
  const themeColor = appColors.primary;
  const [email, setEmail] = useState('');
  const [profile, setProfile] = useState('');
  const [role, setRole] = useState('');

  useFocusEffect(
    React.useCallback(() => {
      getUserData();
    }, []),
  );

  const getUserData = async () => {
    let user = await AsyncStorage.getItem('user');
    if (user) {
      user = JSON.parse(user);
      setEmail(user?.email);
      setProfile(BASE_URL_Image + user?.image);
      setRole(user?.user_type);

      console.log(
        'BASE_URL_Image + user?.image  :  ',
        BASE_URL_Image + user?.image,
      );
    }
  };

  const handleLogout = async () => {
    navigation.replace('Login');
    await AsyncStorage.clear();
  };

  const handleGraphPress = async () => {
    let user_id = await AsyncStorage.getItem('user_id');
    console.log('user_id ', user_id);

    let user = await AsyncStorage.getItem('user');
    if (user) {
      user = JSON.parse(user);
      setEmail(user?.email);
      setProfile(BASE_URL_Image + user?.image);
      setRole(user?.user_type);
      props.navigation.navigate('Graph', {
        id: user_id,
        user_type: user?.user_type,
        profile: user?.image,
        email: user?.email,
        name: user?.user_name,
      });
    }
  };
  return (
    <DrawerContentScrollView {...props} style={{backgroundColor: themeColor}}>
      <View
        style={{
          height: hp(100),
          backgroundColor: '#fff',
        }}>
        <View
          style={{
            backgroundColor: themeColor,
            paddingVertical: 20,
            alignItems: 'center',
          }}>
          {profile?.length > 0 ? (
            <Avatar.Image source={{uri: profile}} size={hp(13)} />
          ) : (
            <Avatar.Image source={appImages.user} size={hp(13)} />
          )}
          <Text
            style={{
              color: '#fff',
              marginLeft: 10,
              fontSize: 14,
              fontWeight: '400',
              lineHeight: 40,
            }}>
            {email}
          </Text>
          <Text
            style={{
              color: '#fff',
              marginLeft: 10,
              fontSize: 14,
              fontWeight: '400',
              //   lineHeight: 40,
              textTransform: 'capitalize',
            }}>
            ({role})
          </Text>
        </View>

        <DrawerItem
          label="Update Profile"
          labelStyle={{...styles.drawerLblStyle, color: themeColor}}
          onPress={() => props.navigation.navigate('UpdateProfile')}
        />
        <DrawerItem
          label="Change Password"
          labelStyle={{...styles.drawerLblStyle, color: themeColor}}
          onPress={() => props.navigation.navigate('ChangePassword')}
        />
        <DrawerItem
          label="Progress Report"
          labelStyle={{...styles.drawerLblStyle, color: themeColor}}
          onPress={() => handleGraphPress()}
        />
        {/* <DrawerItem
            label="Statistics"
            labelStyle={styles.drawerLblStyle}
            onPress={() => props.navigation.navigate('Statistics')}
            icon={focused => (
              <Image
                source={require('../../assets/images/graph.png')}
                style={{
                  width: 21,
                  height: 21,
                  tintColor: '#000',
                  resizeMode: 'contain',
                }}
              />
            )}
          />
          <DrawerItem
            label="Calender"
            labelStyle={styles.drawerLblStyle}
            onPress={() => props.navigation.navigate('Calender')}
           // icon={focused => <Entypo name="calendar" size={20} color={'#000'} />}
          /> */}
        {/* <DrawerItem
            label="Settings"
            labelStyle={styles.drawerLblStyle}
            onPress={() => props.navigation.navigate('Setting')}
            // icon={() => (
            //   <Ionicons name="settings-sharp" size={20} color={'#000'} />
            // )}
          /> */}

        <View style={{flex: 0.9, justifyContent: 'flex-end'}}>
          <CButton
            title="Logout"
            width={wp(37)}
            height={hp(6)}
            iconComponent={
              <FontAwesome name="power-off" color={appColors.white} size={15} />
            }
            onPress={() => handleLogout()}
          />
        </View>
      </View>
    </DrawerContentScrollView>
  );
};

const DrawerNavigation_Student = () => {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerShown: false,
      }}
      drawerContent={props => <CustomDrawerContent {...props} />}>
      <Drawer.Screen
        name="TabNavigation_Student"
        component={TabNavigation_Student}
        options={{title: 'Home'}}
      />
      {/* <Drawer.Screen name="Statistics" component={Statistics} />
    <Drawer.Screen name="Calender" component={Calender} />
    <Drawer.Screen name="Setting" component={Setting} /> */}
    </Drawer.Navigator>
  );
};

export default DrawerNavigation_Student;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  drawerStyles: {flex: 1, width: '50%', backgroundColor: 'transparent'},
  menu: {
    width: 38,
    height: 38,
    margin: 20,
  },
  drawerLblStyle: {
    color: '#555555',
    fontSize: 14,
    fontWeight: '300',
    // marginLeft: -13,
  },
});
