import {StyleSheet, Text, View, TouchableOpacity} from 'react-native';
import React from 'react';
import appColors from '../../../assets/colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appFonts from '../../../assets/fonts';

import {useNavigation} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
const Header = ({title, showLeftIcon, rightIcon, leftIcon}) => {
  const navigation = useNavigation();

  return (
    <View
      style={{
        backgroundColor: appColors.primary,
        paddingHorizontal: wp(3),
        paddingVertical: wp(7),
        flexDirection: 'row',
        alignItems: 'center',
      }}>
      {leftIcon && leftIcon}
      {showLeftIcon == false ? null : (
        <TouchableOpacity
          style={{paddingHorizontal: 8}}
          onPress={() => navigation.goBack()}>
          <Icon name="arrow-back-ios" size={22} color={'#fff'} />
        </TouchableOpacity>
      )}
      <Text
        style={{
          color: appColors.white,
          fontSize: 18,
          fontFamily: appFonts.Time_New_Roman,
        }}>
        {title}
      </Text>
      <View
        style={{
          flex: 1,
          alignItems: 'flex-end',
        }}>
        {rightIcon}
      </View>
    </View>
  );
};

export default Header;

const styles = StyleSheet.create({});
