import {StyleSheet, Text, View, TextInput} from 'react-native';
import React, {useState} from 'react';

import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';

import appColors from '../../../assets/colors';

const CTextInput = ({
  heading,
  state,
  setState,
  placeholder = '',
  secureTextEntry = false,
  leftIcon,
  rightIcon,
  setIsActive,
  id,
  onChangeText,
  containerStyle,
  multiline,
  keyboardType,
}) => {
  const [isFocus, setIsFocus] = useState(false);
  const handleOnFocus = () => {
    setIsFocus(true);
    setIsActive(id);
  };
  const handleOnBlur = () => {
    setIsFocus(false);
    setIsActive('');
  };
  return (
    <View style={{...styles.textInputContainer, ...containerStyle}}>
      {heading && (
        <Text
          style={{
            ...styles.textInputHeading,
          }}>
          {heading}
        </Text>
      )}
      <View
        style={{
          ...styles.txtInputView,
          borderColor: isFocus ? appColors.primary : '#D2D2D2',
        }}>
        {leftIcon && leftIcon}
        <TextInput
          style={{
            ...styles.textInput,
          }}
          // numberOfLines={30}
          // multiline={multiline}
          onFocus={() => handleOnFocus()}
          onBlur={() => handleOnBlur()}
          placeholder={placeholder}
          placeholderTextColor={appColors.border1}
          secureTextEntry={secureTextEntry}
          isFocus={isFocus}
          value={state}
          onChangeText={onChangeText}
          keyboardType={keyboardType ? keyboardType : 'default'}
        />
        {rightIcon && rightIcon}
      </View>
    </View>
  );
};

export default CTextInput;

const styles = StyleSheet.create({
  textInputContainer: {
    marginVertical: hp(2),
    width: wp(85),
  },
  txtInputView: {
    borderWidth: 1.2,
    borderColor: '#D2D2D2',
    borderRadius: wp(1.5),
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: wp(2.5),
    height: hp(6.4),
  },
  textInput: {
    flex: 1,
    marginHorizontal: wp(2),
  },
  textInputHeading: {
    marginVertical: hp(2),
    color: '#000',
    fontWeight: '400',
  },
});
