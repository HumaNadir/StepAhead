const BASE_URL = 'http://192.168.1.103:3000/';
export const BASE_URL_Image = 'http://192.168.1.103:3000/';

const api = {
  //upload image
  upload_image: BASE_URL + 'user/imageUpload',
  //users
  login: BASE_URL + 'user/login',
  register: BASE_URL + 'user/register',
  get_specific_user: BASE_URL + 'user/getSpecificUser',
  update_password: BASE_URL + 'user/updatePassword',
  update_image: BASE_URL + 'user/updateImage',
  update_user: BASE_URL + 'user/updateUser',
  getAllStudents: BASE_URL + 'user/getAllStudents',
  getAllTeachers: BASE_URL + 'user/getAllTeachers',
  get_all_users: BASE_URL + 'user/getAllUsers',

  //forget password
  send_OTP: BASE_URL + 'forgetPassword/userForgetPassword',
  verify_OTP: BASE_URL + 'forgetPassword/verifyOTP',

  //announcements
  get_announcements: BASE_URL + 'announcment/getLastSevenDaysAnnouncments',
  like_announcement: BASE_URL + 'announcment/likeAnnouncments',
  dislike_announcement: BASE_URL + 'announcment/disLikeAnnouncment',
  add_announcement: BASE_URL + 'announcment/addAnnouncment',
  get_announcement_comments: BASE_URL + 'comment/getAnnouncmentComments',
  add_announcement_comment: BASE_URL + 'comment/addComment',

  //classes
  create_class: BASE_URL + 'class/addClass',
  get_all_classes: BASE_URL + 'class/getAllClasses',
  get_class_detail: BASE_URL + 'class/getClassById?class_id=',
  get_teacher_classes: BASE_URL + 'class/getAllClassesOfTeacher?teacher_id=',
  delete_class: BASE_URL + 'class/deleteClass?class_id=',

  //attendance
  add_attendance: BASE_URL + 'attendence/addAttendence',
  get_attendance_of_class: BASE_URL + 'attendence/getAttendenceOfClasss',
  update_attendance: BASE_URL + 'attendence/updateAttendence',
  get_attendance_percentage_of_student:
    BASE_URL + 'attendence/getAttendencePercentage',

  //activites
  create_activity: BASE_URL + 'activity/createActivity',
  get_activity: BASE_URL + 'activity/getStudentActivity',

  //graph
  create_student_graph: BASE_URL + 'studentGraph/createStudentGraph',
  get_student_graph: BASE_URL + 'studentGraph/getStudentGraph',
};

export default api;
