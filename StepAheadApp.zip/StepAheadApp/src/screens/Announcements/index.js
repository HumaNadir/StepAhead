import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Image,
  TextInput,
  FlatList,
  Keyboard,
  KeyboardEvent,
} from 'react-native';
import React, {useState, useEffect, useRef} from 'react';
import Header from '../../components/Header';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import AntDesign from 'react-native-vector-icons/AntDesign';
import appColors from '../../../assets/colors';
import appFonts from '../../../assets/fonts';
import appImages from '../../../assets/images';
import Modal from 'react-native-modal';
import CTextInput from '../../components/CTextInput';
import CButton from '../../components/CButton/CButton';

import api, {BASE_URL_Image} from '../../constants/api';
import Loader from '../../components/Loader';
import Snackbar from 'react-native-snackbar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import RBSheet from 'react-native-raw-bottom-sheet';
import {Avatar} from 'react-native-paper';
import {AnimatedCircularProgress} from 'react-native-circular-progress';
import moment from 'moment';

const Announcements = ({navigation}) => {
  const refRBSheet = useRef(null);
  const refRBSheet1 = useRef(null);
  const refCommentFlatList = useRef(null);
  const [announcement, setAnnouncement] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [isLike, setIsLike] = useState(false);

  const [userType, setUserType] = useState('');
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [comment, setComment] = useState('');
  const [commentList, setCommentList] = useState([]);
  const [selected_announcement_id, setSelected_announcement_id] = useState('');
  const [keyboardHeight, setKeyboardHeight] = useState(0);
  const [likesUserList, setLikesUserList] = useState([]);
  const [attendance_percentage, setAttendance_percentage] = useState(0);

  useEffect(() => {
    function onKeyboardDidShow(e) {
      // Remove type here if not using TypeScript
      setKeyboardHeight(e.endCoordinates.height);
    }

    function onKeyboardDidHide() {
      setKeyboardHeight(0);
    }

    const showSubscription = Keyboard.addListener(
      'keyboardDidShow',
      onKeyboardDidShow,
    );
    const hideSubscription = Keyboard.addListener(
      'keyboardDidHide',
      onKeyboardDidHide,
    );
    return () => {
      showSubscription.remove();
      hideSubscription.remove();
    };
  }, []);

  useEffect(() => {
    getUser();
  }, [userType]);
  useEffect(() => {
    getAnnouncements();
  }, []);

  const getUser = async () => {
    let user_Type = await AsyncStorage.getItem('user_type');
    setUserType(user_Type);
    if (user_Type == 'student') {
      getStudentAttendance();
    }
  };

  const getAnnouncements = async () => {
    setLoading(true);
    let user_id = await AsyncStorage.getItem('user_id');
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };
    let url = `${api.get_announcements}?current_user_id=${user_id}`;

    fetch(url, requestOptions)
      .then(response => response.json())
      .then(result => {
        console.log('get announcement :  ', result);
        if (result?.status == true) {
          let list = result?.result ? result?.result : [];
          setData(list?.reverse());
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };
  const getAnnouncement_Comments = async id => {
    setLoading(true);
    setSelected_announcement_id(id);

    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };
    let url = `${api.get_announcement_comments}?announcment_id=${id}`;

    fetch(url, requestOptions)
      .then(response => response.json())
      .then(async result => {
        if (result?.status == true) {
          let list = result?.result ? result?.result : [];
          setCommentList(list);
          // for (const element of list) {
          // let user_detail = await getUserDetail();

          // }
          refRBSheet.current?.open();
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };

  const createAnnouncement = async () => {
    if (announcement?.length == 0) {
      Snackbar.show({
        text: 'Please Enter Text to add to announcement',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
    } else {
      setIsVisible(false);
      setLoading(true);
      var requestOptions = {
        method: 'POST',
        body: JSON.stringify({
          description: announcement,
        }),
        headers: {
          'Content-Type': 'application/json',
        },
      };
      fetch(api.add_announcement, requestOptions)
        .then(response => response.json())
        .then(async result => {
          if (result?.status == true) {
            let prevList = data;
            prevList.unshift(result?.result);
            setData(prevList);
          } else {
            Snackbar.show({
              text: result?.message,
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'red',
            });
          }
        })
        .catch(error => {
          Snackbar.show({
            text: 'Something went wrong',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        })
        .finally(() => setLoading(false));
    }
  };

  const handleLike = (id, like_status) => {
    if (like_status) {
      disLikeAnnouncement(id, like_status);
    } else {
      likeAnnouncement(id, like_status);
    }
  };

  const updateLikeStatus = async (id, status) => {
    const newData = data?.map(element => {
      if (id == element?._id) {
        return {
          ...element,
          user_liked: !element?.user_liked,
        };
      } else {
        return {
          ...element,
        };
      }
    });
    setData(newData);
    getAnnouncements();
  };
  const likeAnnouncement = async (id, status) => {
    setLoading(true);
    let user_id = await AsyncStorage.getItem('user_id');
    var requestOptions = {
      method: 'PUT',
      body: JSON.stringify({
        user_id: user_id,
        announcment_id: id,
      }),
      headers: {
        'Content-Type': 'application/json',
      },
    };
    fetch(api.like_announcement, requestOptions)
      .then(response => response.json())
      .then(async result => {
        if (result?.status == true) {
          updateLikeStatus(id, status);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => {
        Snackbar.show({
          text: 'Something went wrong',
          duration: Snackbar.LENGTH_SHORT,
          backgroundColor: 'red',
        });
      })
      .finally(() => setLoading(false));
  };
  const disLikeAnnouncement = async (id, status) => {
    setLoading(true);
    let user_id = await AsyncStorage.getItem('user_id');
    var requestOptions = {
      method: 'PUT',
      body: JSON.stringify({
        user_id: user_id,
        announcment_id: id,
      }),
      headers: {
        'Content-Type': 'application/json',
      },
    };
    fetch(api.dislike_announcement, requestOptions)
      .then(response => response.json())
      .then(async result => {
        if (result?.status == true) {
          updateLikeStatus(id, status);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => {
        Snackbar.show({
          text: 'Something went wrong',
          duration: Snackbar.LENGTH_SHORT,
          backgroundColor: 'red',
        });
      })
      .finally(() => setLoading(false));
  };

  const getUserDetail = async user_id => {
    return new Promise(async (resolve, reject) => {
      var requestOptions = {
        method: 'GET',
        redirect: 'follow',
      };
      fetch(`${api.get_specific_user}/${user_id}`, requestOptions)
        .then(response => response.json())
        .then(result => {
          if (result?.statusCode == 200) {
            let user_detail = result?.result;
            // setUserName(user_detail?.user_name);
            // setPhoneNo(user_detail?.contact_no);
            // setAddress(user_detail?.address);
            // if (user_detail?.image) {
            //   setPicture(BASE_URL_Image + user_detail?.image);
            // }
            resolve(user_detail);
          } else {
            resolve(false);
          }
        })
        .catch(error => resolve(false));
    });
  };
  const handleAddComment = async () => {
    let user_id = await AsyncStorage.getItem('user_id');
    setIsVisible(false);
    setLoading(true);
    var requestOptions = {
      method: 'POST',
      body: JSON.stringify({
        comment: comment,
        user_id: user_id,
        announcment_id: selected_announcement_id,
      }),
      headers: {
        'Content-Type': 'application/json',
      },
    };
    fetch(api.add_announcement_comment, requestOptions)
      .then(response => response.json())
      .then(async result => {
        if (result?.status == true) {
          let user_detail = await getUserDetail(user_id);
          let prevList = commentList;
          let obj = {
            ...result?.result,
            user_id: user_detail,
          };
          prevList.push(obj);
          setCommentList(prevList);
          setComment('');
          Keyboard.dismiss();
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => {
        Snackbar.show({
          text: 'Something went wrong',
          duration: Snackbar.LENGTH_SHORT,
          backgroundColor: 'red',
        });
      })
      .finally(() => setLoading(false));
  };

  const getStudentAttendance = async () => {
    setLoading(true);
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };
    let user_id = await AsyncStorage.getItem('user_id');
    let date = moment(new Date()).format('YYYY/MM/DD');
    let url =
      api.get_attendance_percentage_of_student +
      '?date=' +
      date +
      '&student_id=' +
      user_id;
    fetch(url, requestOptions)
      .then(response => response.json())
      .then(result => {
        if (result?.status == true || result?.status == 'success') {
          setAttendance_percentage(result?.percentage?.toFixed(0));
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      {/* <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}> */}
      <Header
        showLeftIcon={false}
        leftIcon={
          <TouchableOpacity
            style={{marginHorizontal: wp(2)}}
            onPress={() => navigation?.toggleDrawer()}>
            <SimpleLineIcons name="menu" size={25} color={'#FFFFFF'} />
          </TouchableOpacity>
        }
        rightIcon={
          <View style={{flexDirection: 'row'}}>
            {(userType == 'admin' || userType == 'teacher') && (
              <TouchableOpacity
                style={{marginHorizontal: wp(2)}}
                onPress={() => setIsVisible(true)}>
                <Ionicons name="add-circle" size={25} color={'#FFFFFF'} />
              </TouchableOpacity>
            )}
            <TouchableOpacity
              style={{marginHorizontal: wp(2)}}
              onPress={() => navigation?.replace('Login')}>
              <MaterialCommunityIcons
                name="logout"
                size={25}
                color={'#FFFFFF'}
              />
            </TouchableOpacity>
          </View>
        }
      />
      {loading && <Loader />}
      <View style={{flex: 1, alignItems: 'center', paddingHorizontal: 20}}>
        {userType == 'student' && (
          <>
            <Text
              style={{
                marginVertical: hp(3.5),
                color: appColors.dark,
                fontSize: 18,
                fontFamily: appFonts.Time_New_Roman_Bold,
              }}>
              Attendance
            </Text>
            <AnimatedCircularProgress
              size={140}
              width={13}
              fill={attendance_percentage}
              tintColor={appColors.primary}
              onAnimationComplete={() => console.log('onAnimationComplete')}
              backgroundColor="#3d5875">
              {fill => (
                <Text
                  style={{
                    fontSize: 16,
                    color: appColors.primary,
                    fontWeight: 'bold',
                  }}>
                  {fill}%
                </Text>
              )}
            </AnimatedCircularProgress>
          </>
        )}

        <Text
          style={{
            marginVertical: hp(3.5),
            color: appColors.dark,
            fontSize: 18,
            fontFamily: appFonts.Time_New_Roman_Bold,
          }}>
          Recent Announcements
        </Text>
        <FlatList
          keyExtractor={(item, index) => index.toString()}
          data={data}
          showsVerticalScrollIndicator={false}
          renderItem={({item}) => {
            console.log('item?.user_id?.user_name  : ', item);
            return (
              <View style={styles.card}>
                {/* <View style={{flex: 1}}> */}
                <Text style={{color: appColors.cardText, fontSize: 14}}>
                  {item?.description}
                </Text>
                <Text
                  style={{
                    color: appColors.cardText,
                    fontSize: 14,
                    marginTop: 5,
                    fontWeight: '500',
                  }}>
                  Created By : {item?.user_id?.user_name}{' '}
                </Text>

                {/* </View> */}
                <View style={styles.line}></View>

                <View style={styles.rowView}>
                  {/* <Text
                    style={{
                      color: appColors.dark,
                      fontSize: 20,
                      marginTop: 10,
                      marginHorizontal: 5,
                    }}>
                    {item?.likes?.length}
                  </Text> */}
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TouchableOpacity
                      onPress={() => handleLike(item?._id, item?.user_liked)}>
                      <AntDesign
                        name="like2"
                        size={30}
                        color={
                          item?.user_liked
                            ? appColors.primary
                            : appColors.cardText
                        }
                      />
                    </TouchableOpacity>
                    <Text
                      onPress={() => {
                        setLikesUserList(item?.likedBy);
                        refRBSheet1?.current?.open();
                      }}
                      style={{color: appColors.cardText}}>
                      {` ${
                        item?.likedBy?.length ? item?.likedBy?.length : 0
                      } Likes `}
                    </Text>
                  </View>

                  <TouchableOpacity
                    onPress={() => getAnnouncement_Comments(item?._id)}>
                    <Image
                      source={appImages.announcement}
                      style={styles.commentImage}
                    />
                  </TouchableOpacity>
                </View>
              </View>
            );
          }}
        />
      </View>

      <RBSheet
        ref={refRBSheet}
        height={hp(90)}
        openDuration={250}
        closeOnDragDown={true}
        customStyles={{
          container: {
            justifyContent: 'center',
            alignItems: 'center',
            borderTopEndRadius: 10,
            borderTopLeftRadius: 10,
          },
        }}>
        <View
          style={{
            flex: 1,
            width: wp(100),
            alignItems: 'center',
          }}>
          {loading && <Loader />}
          {commentList?.length == 0 ? (
            <Text style={{color: appColors.dark, marginVertical: hp(2)}}>
              No Comment found
            </Text>
          ) : (
            <FlatList
              data={commentList}
              showsVerticalScrollIndicator={false}
              keyExtractor={(item, index) => index.toString()}
              ref={refCommentFlatList}
              onContentSizeChange={() =>
                refCommentFlatList.current?.scrollToEnd({animated: true})
              }
              renderItem={({item}) => {
                return (
                  <TouchableOpacity
                    activeOpacity={1}
                    style={{
                      ...styles.card,
                      marginVertical: hp(1),
                      // backgroundColor: '#EEEEEE',
                      elevation: 3,
                      shadowColor: 'blue',
                      padding: hp(1.5),
                    }}>
                    <View style={styles.rowView}>
                      {item?.user_id?.image ? (
                        <Avatar.Image
                          size={40}
                          source={{uri: BASE_URL_Image + item?.user_id?.image}}
                          style={{backgroundColor: '#fff'}}
                        />
                      ) : (
                        <Avatar.Image
                          size={40}
                          source={appImages.profile}
                          style={{backgroundColor: '#fff'}}
                        />
                      )}
                      <View style={{marginLeft: 10}}>
                        <Text
                          style={{
                            color: appColors.dark,
                            fontWeight: 'bold',
                            fontSize: 14,
                          }}>
                          {item?.user_id?.user_name} ({item?.user_id?.user_type}
                          )
                        </Text>
                        <Text
                          style={{
                            color: appColors.dark,
                            fontSize: 14,
                            marginTop: 5,
                          }}>
                          {item?.comment}
                        </Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                );
              }}
            />
          )}

          <View style={{height: 80}}></View>
          <View
            style={{
              position: 'absolute',
              bottom: keyboardHeight == 0 ? 0 : keyboardHeight * 0.8,
              backgroundColor: '#fff',
              width: wp(100),
              alignItems: 'center',
              paddingBottom: 25,
            }}>
            <View style={styles.txtInputView}>
              <TextInput
                style={styles.textInput}
                placeholder={'Write Comment'}
                value={comment}
                onChangeText={text => setComment(text)}
              />
              <TouchableOpacity
                disabled={comment?.length == 0 ? true : false}
                onPress={() => handleAddComment()}>
                <FontAwesome name="send" size={25} color={appColors.primary} />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </RBSheet>

      <RBSheet
        ref={refRBSheet1}
        height={hp(90)}
        openDuration={250}
        closeOnDragDown={true}
        customStyles={{
          container: {
            justifyContent: 'center',
            alignItems: 'center',
            borderTopEndRadius: 10,
            borderTopLeftRadius: 10,
          },
        }}>
        <View
          style={{
            flex: 1,
            width: wp(100),
            alignItems: 'center',
          }}>
          {loading && <Loader />}
          {likesUserList?.length == 0 ? (
            <Text style={{color: appColors.dark, marginVertical: hp(2)}}>
              No Record found
            </Text>
          ) : (
            <FlatList
              data={likesUserList}
              showsVerticalScrollIndicator={false}
              keyExtractor={(item, index) => index.toString()}
              // ref={refCommentFlatList}
              // onContentSizeChange={() =>
              //   refCommentFlatList.current?.scrollToEnd({animated: true})
              // }
              renderItem={({item}) => {
                return (
                  <TouchableOpacity
                    activeOpacity={1}
                    style={{
                      ...styles.card,
                      marginVertical: hp(1),
                      // backgroundColor: '#EEEEEE',
                      elevation: 3,
                      shadowColor: 'blue',
                      padding: hp(1.5),
                    }}>
                    <View style={styles.rowView}>
                      {item?.user_id?.image ? (
                        <Avatar.Image
                          size={40}
                          source={{uri: BASE_URL_Image + item?.image}}
                          style={{backgroundColor: '#fff'}}
                        />
                      ) : (
                        <Avatar.Image
                          size={40}
                          source={appImages.profile}
                          style={{backgroundColor: '#fff'}}
                        />
                      )}
                      <View style={{marginLeft: 10}}>
                        <Text
                          style={{
                            color: appColors.dark,
                            fontWeight: 'bold',
                            fontSize: 14,
                          }}>
                          {item?.user_name} ({item?.user_type})
                        </Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                );
              }}
            />
          )}

          <View style={{height: 80}}></View>
        </View>
      </RBSheet>

      <Modal isVisible={isVisible} onBackdropPress={() => setIsVisible(false)}>
        <View
          style={{
            backgroundColor: '#fff',
            padding: 20,
            borderRadius: 10,
            alignItems: 'center',
          }}>
          <Text
            style={{
              color: appColors.dark,
              fontSize: 18,
              fontFamily: appFonts.Time_New_Roman_Bold,
            }}>
            Create Announcement
          </Text>
          <TextInput
            style={styles.input}
            value={announcement}
            onChangeText={text => setAnnouncement(text)}
            multiline={true}
            underlineColorAndroid="transparent"
            numberOfLines={5}
            textAlignVertical="top"
          />
          <CButton
            title="Create"
            width={wp(40)}
            height={hp(6)}
            onPress={() => {
              createAnnouncement();
            }}
          />
        </View>
      </Modal>
      {/* </ScrollView> */}
    </View>
  );
};

export default Announcements;

const styles = StyleSheet.create({
  card: {
    width: wp(85),
    marginHorizontal: 10,
    // height: hp(30),
    padding: wp(6),
    marginVertical: hp(2),
    borderRadius: wp(3),
    backgroundColor: appColors.card,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.29,
    shadowRadius: 4.65,

    elevation: 7,
  },
  line: {
    borderTopWidth: 1,
    borderColor: '#D5D5D5',
    width: '100%',
    alignSelf: 'center',
    marginVertical: 15,
  },
  rowView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  commentImage: {
    width: wp(8),
    height: wp(8),
    marginHorizontal: wp(4),
    tintColor: appColors.cardText,
  },
  input: {
    borderWidth: 1,
    borderColor: '#D5D5D5',
    borderRadius: 10,
    marginVertical: wp(8),
    width: wp(80),
    padding: 10,
  },
  textInputContainer: {
    marginVertical: hp(2),
    width: wp(85),
  },
  txtInputView: {
    borderWidth: 1.2,
    borderColor: '#D2D2D2',
    borderRadius: wp(1.5),
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: wp(2.5),
    height: hp(6.4),
    width: wp(85),
    backgroundColor: '#fff',
  },
  textInput: {
    flex: 1,
    marginHorizontal: wp(2),
  },
});
