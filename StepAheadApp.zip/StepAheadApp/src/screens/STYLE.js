import {StyleSheet} from 'react-native';
import appColors from '../../assets/colors';
import appFonts from '../../assets/fonts';

export const STYLE = StyleSheet.create({
  classCard: {
    backgroundColor: appColors.white,
    marginVertical: 8,
    padding: 20,
    marginHorizontal: 10,
    borderRadius: 0,
    alignItems: 'center',
  },
  classCardText: {
    color: appColors.dark,
    fontSize: 14,
    fontFamily: appFonts.Time_New_Roman_Bold,
  },
});
