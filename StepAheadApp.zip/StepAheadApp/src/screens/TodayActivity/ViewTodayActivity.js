import {
  StyleSheet,
  Text,
  View,
  FlatList,
  Image,
  TouchableOpacity,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import Header from '../../components/Header';
import Loader from '../../components/Loader';
import Snackbar from 'react-native-snackbar';
import api, {BASE_URL_Image} from '../../constants/api';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Avatar, Card, Checkbox, RadioButton} from 'react-native-paper';
import appColors from '../../../assets/colors';
import appFonts from '../../../assets/fonts';
import appImages from '../../../assets/images';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import CButton from '../../components/CButton/CButton';
import moment from 'moment';

const ViewTodayActivity = ({navigation, route}) => {
  const [loading, setLoading] = useState(false);
  const [selectedEmoji, setSelectedEmoji] = useState('');
  const [activitiesList, setActivitiesList] = useState([
    {
      id: 0,
      title: 'Lunch',
      value: 'lunch',
      icon: appImages.lunch,
      isSelected: false,
    },
    {
      id: 1,
      title: 'Toileting',
      value: 'toileting',

      icon: appImages.toileting,
      isSelected: false,
    },
    {
      id: 2,
      title: 'Kitchening',
      value: 'kitchening',

      icon: appImages.kitchening,
      isSelected: false,
    },
    {
      id: 3,
      title: 'Sports',
      value: 'sports',

      icon: appImages.sports,
      isSelected: false,
    },
  ]);
  const handleCheckbox = async id => {
    const newData = activitiesList.map(item => {
      if (item.id == id) {
        return {
          ...item,
          isSelected: !item.isSelected,
        };
      } else {
        return {...item};
      }
    });
    setActivitiesList(newData);
  };
  useEffect(() => {
    getActivity();
  }, []);

  const getActivity = async classId => {
    setLoading(true);
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };
    let user_id = await AsyncStorage.getItem('user_id');
    let url =
      api.get_activity +
      '?student_id=' +
      user_id +
      '&date=' +
      moment(new Date()).format('YYYY-MM-DD');

    fetch(url, requestOptions)
      .then(response => response.json())
      .then(result => {
        if (result?.status == true || result?.status == 'success') {
          setSelectedEmoji(result?.result?.emoji);
          const newData = activitiesList?.map(element => {
            if (element?.value == 'lunch') {
              console.log('kjkjkj');
              return {
                ...element,
                isSelected: result?.result?.lunch,
              };
            } else if (element?.value == 'toileting') {
              return {
                ...element,
                isSelected: result?.result?.toileting,
              };
            } else if (element?.value == 'kitchening') {
              return {
                ...element,
                isSelected: result?.result?.kitchening,
              };
            } else if (element?.value == 'sports') {
              return {
                ...element,
                isSelected: result?.result?.sports,
              };
            }
          });

          setActivitiesList(newData);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <Header title={'Today Activity'} />
      {loading && <Loader />}
      <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
        <Text style={styles.heading}>Child Day At School</Text>
        <View style={styles.emojiView}>
          {selectedEmoji == 'normal' ? (
            <Image source={appImages.normal} style={styles.emoji} />
          ) : selectedEmoji == 'sadEmoji' ? (
            <Image source={appImages.sadEmoji} style={styles.emoji} />
          ) : (
            <Image source={appImages.smile} style={styles.emoji} />
          )}
        </View>
        <Text style={styles.heading}>Activities Done in Class</Text>
        <Card
          style={{
            backgroundColor: '#fff',
            padding: 15,
            width: wp(90),
            marginBottom: 20,
          }}>
          <FlatList
            data={activitiesList}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({item}) => {
              return (
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginBottom: 8,
                    justifyContent: 'space-between',
                  }}>
                  <Image source={item.icon} />
                  <Text
                    style={{
                      //   flex: 1,
                      color: '#000',
                      fontWeight: '500',
                      fontSize: 17,
                    }}>
                    {item?.title}
                  </Text>
                  <Checkbox
                    status={item.isSelected ? 'checked' : 'unchecked'}
                    // onPress={() => handleCheckbox(item.id)}
                  />
                </View>
              );
            }}
          />
        </Card>
      </View>
    </View>
  );
};

export default ViewTodayActivity;

const styles = StyleSheet.create({
  heading: {
    color: '#000',
    fontWeight: '600',
    fontSize: 18,
    marginVertical: 25,
  },
  emojiView: {
    flexDirection: 'row',
    // alignItems: 'center',
    // alignContent: 'center',
    // justifyContent: 'space-between',
    // width: '50%',
    // backgroundColor: 'red',
  },
  emoji: {width: 45, height: 45},
});
