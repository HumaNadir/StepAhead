import {
  StyleSheet,
  Text,
  View,
  FlatList,
  Image,
  TouchableOpacity,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import Header from '../../components/Header';
import Loader from '../../components/Loader';
import Snackbar from 'react-native-snackbar';
import api, {BASE_URL_Image} from '../../constants/api';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Avatar, Card, Checkbox, RadioButton} from 'react-native-paper';
import appColors from '../../../assets/colors';
import appFonts from '../../../assets/fonts';
import appImages from '../../../assets/images';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import CButton from '../../components/CButton/CButton';
import moment from 'moment';

const MarkTodayActivity = ({navigation, route}) => {
  const [loading, setLoading] = useState(false);
  const [selectedEmoji, setSelectedEmoji] = useState('');
  const [activitiesList, setActivitiesList] = useState([
    {
      id: 0,
      title: 'Lunch',
      value: 'lunch',
      icon: appImages.lunch,
      isSelected: true,
    },
    {
      id: 1,
      title: 'Toileting',
      value: 'toileting',

      icon: appImages.toileting,
      isSelected: true,
    },
    {
      id: 2,
      title: 'Kitchening',
      value: 'kitchening',

      icon: appImages.kitchening,
      isSelected: true,
    },
    {
      id: 3,
      title: 'Sports',
      value: 'sports',

      icon: appImages.sports,
      isSelected: true,
    },
  ]);
  const handleCheckbox = async id => {
    const newData = activitiesList.map(item => {
      if (item.id == id) {
        return {
          ...item,
          isSelected: !item.isSelected,
        };
      } else {
        return {...item};
      }
    });
    setActivitiesList(newData);
  };

  const handleSave = async () => {
    if (selectedEmoji?.length == 0) {
      alert('Please Select Emoji');
    } else {
      let data = {
        student_id: route?.params?.id,
        date: moment(new Date()).format('YYYY-MM-DD'),
        emoji: selectedEmoji,
        lunch: activitiesList[0]?.isSelected,
        toileting: activitiesList[1]?.isSelected,
        kitchening: activitiesList[2]?.isSelected,
        sports: activitiesList[3]?.isSelected,
      };
      console.log('data  :  ', data);
      setLoading(true);

      var requestOptions = {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
          'Content-Type': 'application/json',
        },
      };
      fetch(api.create_activity, requestOptions)
        .then(response => response.json())
        .then(async result => {
          console.log('result  :  ', result);
          if (result?.status == true) {
            Snackbar.show({
              text: ' Added successfully',
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'green',
            });
            navigation.goBack();
          } else {
            Snackbar.show({
              text: result?.message,
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'red',
            });
          }
        })
        .catch(error => {
          console.log('error raised  :  ', error);
          Snackbar.show({
            text: 'Something went wrong',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        })
        .finally(() => setLoading(false));
    }
  };
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <Header title={'Today Activity'} />
      {loading && <Loader />}
      <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
        <Text style={styles.heading}>Child Day At School</Text>
        <View style={styles.emojiView}>
          <TouchableOpacity onPress={() => setSelectedEmoji('normal')}>
            <Image
              source={appImages.normal}
              style={{
                ...styles.emoji,
                marginBottom: selectedEmoji == 'normal' ? 20 : 0,
              }}
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setSelectedEmoji('sadEmoji')}>
            <Image
              source={appImages.sadEmoji}
              style={{
                ...styles.emoji,
                marginBottom: selectedEmoji == 'sadEmoji' ? 20 : 0,
              }}
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setSelectedEmoji('smile')}>
            <Image
              source={appImages.smile}
              style={{
                ...styles.emoji,
                marginBottom: selectedEmoji == 'smile' ? 20 : 0,
              }}
            />
          </TouchableOpacity>
        </View>
        <Text style={styles.heading}>Activities Done in Class</Text>
        <Card
          style={{
            backgroundColor: '#fff',
            padding: 15,
            width: wp(90),
            marginBottom: 20,
          }}>
          <FlatList
            data={activitiesList}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({item}) => {
              return (
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginBottom: 8,
                    justifyContent: 'space-between',
                  }}>
                  <Image source={item.icon} />
                  <Text
                    style={{
                      //   flex: 1,
                      color: '#000',
                      fontWeight: '500',
                      fontSize: 17,
                    }}>
                    {item?.title}
                  </Text>
                  <Checkbox
                    status={item.isSelected ? 'checked' : 'unchecked'}
                    onPress={() => handleCheckbox(item.id)}
                  />
                </View>
              );
            }}
          />
        </Card>
        <CButton title="Save" onPress={() => handleSave()} />
      </View>
    </View>
  );
};

export default MarkTodayActivity;

const styles = StyleSheet.create({
  heading: {
    color: '#000',
    fontWeight: '600',
    fontSize: 18,
    marginVertical: 25,
  },
  emojiView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '50%',
  },
  emoji: {width: 45, height: 45},
});
