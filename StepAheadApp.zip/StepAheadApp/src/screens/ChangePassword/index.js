import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ScrollView,
} from 'react-native';
import React, {useState} from 'react';
import AuthHeader from '../../components/AuthHeader';
import appColors from '../../../assets/colors';
import appFonts from '../../../assets/fonts';
import CTextInput from '../../components/CTextInput';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import CButton from '../../components/CButton/CButton';

import EntypoIcon from 'react-native-vector-icons/Entypo';
import FontistoIcon from 'react-native-vector-icons/Fontisto';

import Snackbar from 'react-native-snackbar';
import api from '../../constants/api';
import Loader from '../../components/Loader';

const ChangePassword = ({navigation, route}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [loading, setLoading] = useState(false);

  const validate = () => {
    if (password?.length == 0) {
      Snackbar.show({
        text: 'Please Enter Password',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (password?.length < 6) {
      Snackbar.show({
        text: 'Password must be at least 6 characters',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (confirmPassword?.length == 0) {
      Snackbar.show({
        text: 'Please Enter Confirm Password',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (password !== confirmPassword) {
      Snackbar.show({
        text: 'Password and confirm password are not matched',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else {
      return true;
    }
  };
  const handleChangePassword = () => {
    if (validate()) {
      setLoading(true);
      var requestOptions = {
        method: 'PUT',
        body: JSON.stringify({
          email: route?.params?.email,
          password: password,
        }),
        headers: {
          'Content-Type': 'application/json',
        },
      };
      fetch(api.update_password, requestOptions)
        .then(response => response.json())
        .then(async result => {
          console.log('response :   ', result);
          if (result) {
            if (route?.params?.screen) {
              navigation?.goBack();
            } else {
              navigation?.popToTop();
              navigation.navigate('Login');
            }
            Snackbar.show({
              text: 'Password has been updated successfully',
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'green',
            });
          } else {
            Snackbar.show({
              text: result?.message,
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'red',
            });
          }
        })
        .catch(error => {
          console.log('error raised  :  ', error);
          Snackbar.show({
            text: 'Something went wrong',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        })
        .finally(() => setLoading(false));
    }
  };
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <View style={{flex: 1}}>
          <AuthHeader showBackIcon />
          {loading && <Loader />}
          <View style={{flex: 1, alignItems: 'center'}}>
            <Text
              style={{
                color: appColors.dark,
                fontSize: 22,
                fontFamily: appFonts.Time_New_Roman_Bold,
                marginBottom: hp(4),
              }}>
              Change Password
            </Text>

            <CTextInput
              state={password}
              onChangeText={txt => setPassword(txt)}
              secureTextEntry={!showPassword}
              placeholder="Password"
              id="password"
              setIsActive={setIsActive}
              containerStyle={{width: wp(85)}}
              leftIcon={
                <FontistoIcon
                  name="locked"
                  size={wp(5)}
                  color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
                />
              }
              rightIcon={
                <EntypoIcon
                  onPress={() => setShowPassword(!showPassword)}
                  name={!showPassword ? 'eye-with-line' : 'eye'}
                  size={wp(5)}
                  color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
                />
              }
            />
            <CTextInput
              state={confirmPassword}
              onChangeText={txt => setConfirmPassword(txt)}
              secureTextEntry={!showConfirmPassword}
              placeholder="Confirm Password"
              id="confirmPassword"
              setIsActive={setIsActive}
              containerStyle={{width: wp(85)}}
              leftIcon={
                <FontistoIcon
                  name="locked"
                  size={wp(5)}
                  color={
                    isActive == 'confirmPassword'
                      ? appColors.primary
                      : '#D2D2D2'
                  }
                />
              }
              rightIcon={
                <EntypoIcon
                  onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                  name={!showConfirmPassword ? 'eye-with-line' : 'eye'}
                  size={wp(5)}
                  color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
                />
              }
            />

            <CButton title="Change" onPress={() => handleChangePassword()} />
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default ChangePassword;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});
