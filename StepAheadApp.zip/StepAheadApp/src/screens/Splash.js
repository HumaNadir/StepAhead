import {StyleSheet, Text, View, Image} from 'react-native';
import React, {useEffect} from 'react';
import appImages from '../../assets/images';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appColors from '../../assets/colors';
import AsyncStorage from '@react-native-async-storage/async-storage';
const Splash = ({navigation}) => {
  useEffect(() => {
    checkUser();
  }, []);

  const checkUser = async () => {
    let user = await AsyncStorage.getItem('user');
    if (user) {
      user = JSON.parse(user);
      if (user?.user_type == 'admin') {
        navigation.navigate('DrawerNavigation_Admin');
      } else if (user?.user_type == 'teacher') {
        navigation.navigate('DrawerNavigation_Teacher');
      } else if (user?.user_type == 'student') {
        navigation.navigate('DrawerNavigation_Student');
      } else {
        navigation.navigate('AccountType');
      }
    } else {
      navigation.navigate('AccountType');
    }
  };

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: appColors.primary,
        alignItems: 'center',
        justifyContent: 'center',
      }}>
      <Image
        source={appImages.logo}
        style={{
          height: wp(50),
          width: wp(50),
          borderRadius: wp(50) / 2,
        }}
      />
    </View>
  );
};

export default Splash;

const styles = StyleSheet.create({});
