import {
  StyleSheet,
  Text,
  View,
  StatusBar,
  ScrollView,
  Image,
} from 'react-native';
import React from 'react';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';

import CButton from '../../components/CButton/CButton';
import AuthHeader from '../../components/AuthHeader';

import appColors from '../../../assets/colors';
import appImages from '../../../assets/images';

const AccountType = ({navigation}) => {
  return (
    <View style={styles.container}>
      <View style={{flex: 1}}>
        <AuthHeader />
        {/* <View
          style={{
            flex: 0.5,
            marginBottom: '40%',
            backgroundColor: appColors.primary,
          }}>
          <Image
            source={appImages.logo1}
            style={{
              width: wp(38),
              height: wp(38),
              resizeMode: 'contain',
              position: 'absolute',
              top: '75%',
              left: '32%',
            }}
          />
        </View> */}
        <View style={{flex: 1, alignItems: 'center'}}>
          <Text
            style={{color: appColors.dark, fontSize: 16, marginVertical: 10}}>
            Choose your account type
          </Text>
          <CButton
            title="Teacher"
            width={wp(50)}
            onPress={() => navigation?.navigate('Login')}
          />
          <CButton
            title="Parent"
            width={wp(50)}
            onPress={() => navigation?.navigate('Login')}
          />
          <CButton
            title="Admin"
            width={wp(50)}
            onPress={() => navigation?.navigate('Login')}
          />
        </View>
      </View>
    </View>
  );
};

export default AccountType;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});
