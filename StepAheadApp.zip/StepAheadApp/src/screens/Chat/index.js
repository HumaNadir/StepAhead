import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  FlatList,
  useWindowDimensions,
} from 'react-native';

import api, {BASE_URL_Image} from '../../constants/api';
import Snackbar from 'react-native-snackbar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Loader from '../../components/Loader';

import {TabView, SceneMap} from 'react-native-tab-view';
import {Avatar, Card} from 'react-native-paper';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appImages from '../../../assets/images';

import {
  getDatabase,
  get,
  ref,
  set,
  onValue,
  push,
  update,
  off,
} from 'firebase/database';
import Header from '../../components/Header';

const Chat = ({navigation, route}) => {
  const [parentsList, setParentsList] = useState([]);
  const [teachersList, setTeachersList] = useState([]);
  const [adminsList, setAdminsList] = useState([]);
  const layout = useWindowDimensions();

  const [index, setIndex] = React.useState(0);
  const [routes] = React.useState([
    {key: 'first', title: 'Parents'},
    {key: 'second', title: 'Teachers'},
    {key: 'third', title: 'Admins'},
  ]);

  const [loading, setLoading] = useState(false);
  useEffect(() => {
    getUsers();
  }, []);

  const getUsers = async () => {
    setLoading(true);
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };
    fetch(api.get_all_users, requestOptions)
      .then(response => response.json())
      .then(async result => {
        if (result?.status == true || result?.status == 'success') {
          let usersList = result?.result ? result?.result : [];
          let user_id = await AsyncStorage.getItem('user_id');
          usersList = usersList?.filter(item => item?._id != user_id);
          const teachers = usersList?.filter(
            item => item?.user_type == 'teacher',
          );
          const students = usersList?.filter(
            item => item?.user_type == 'student',
          );
          const admins = usersList?.filter(item => item?.user_type == 'admin');
          setTeachersList(teachers);
          setParentsList(students);
          setAdminsList(admins);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };

  const handleUserPress = async item => {
    // navigation.navigate('Conversations')
    // console.log('user_id   : ', user_id);
    onAddFriend(item);
  };

  const createUser = async (id, name, email) => {
    return new Promise((resolve, reject) => {
      try {
        const database = getDatabase();
        //first check if the user registered before
        const newUserObj = {
          id: id ? id : '',
          name: name ? name : '',
          email: email ? email : '',
        };
        set(ref(database, `users/${id}`), newUserObj);
        resolve(true);
      } catch (error) {
        console.log('error while creating new user', error);
        resolve(false);
      }
    });
  };
  const onAddFriend = async selected_item => {
    try {
      setLoading(true);
      const database = getDatabase();
      //current user
      let user_id = await AsyncStorage.getItem('user_id');
      let current_user = await findUser(user_id);
      if (current_user == null) {
        let user = await AsyncStorage.getItem('user');
        user = JSON.parse(user);
        await createUser(user?._id, user?.user_name, user?.email);
        current_user = await findUser(user_id);
      }

      let selected_user = await findUser(selected_item?._id);
      if (selected_user == null) {
        await createUser(
          selected_item?._id,
          selected_item?.user_name,
          selected_item?.email,
        );
        selected_user = await findUser(selected_item?._id);
      }

      if (selected_user) {
        if (selected_user?.id === current_user?.id) {
          // don't let user add himself
          let filter = current_user?.friends?.filter(
            f => f?.id === selected_user?.id,
          );
          navigation.navigate('Conversations', {
            current_user: current_user,
            selected_user: filter[0],
          });
          setLoading(false);
          return;
        }

        if (
          current_user?.friends &&
          current_user?.friends?.filter(f => f?.id === selected_user?.id)
            ?.length > 0
        ) {
          // don't let user add a user twice
          let filter = current_user?.friends?.filter(
            f => f?.id === selected_user?.id,
          );
          navigation.navigate('Conversations', {
            current_user: current_user,
            selected_user: filter[0],
          });
          setLoading(false);
          return;
        }

        // create a chatroom and store the chatroom id

        const newChatroomRef = push(ref(database, 'chatrooms'), {
          firstUser: current_user.id,
          secondUser: selected_user.id,
          messages: [],
        });

        const newChatroomId = newChatroomRef.key;

        const userFriends = selected_user.friends || [];
        //join myself to this user friend list
        update(ref(database, `users/${selected_user.id}`), {
          friends: [
            ...userFriends,
            {
              id: current_user.id,
              name: current_user.name,
              // avatar: myData.avatar,
              chatroomId: newChatroomId,
            },
          ],
        });

        const myFriends = current_user.friends || [];
        //add this user to my friend list
        update(ref(database, `users/${current_user.id}`), {
          friends: [
            ...myFriends,
            {
              id: selected_user.id,
              name: selected_user.name,
              // avatar: user.avatar,
              chatroomId: newChatroomId,
            },
          ],
        });
        current_user = await findUser(user_id);
        let filter = current_user?.friends.filter(
          f => f?.id === selected_user?.id,
        );
        navigation.navigate('Conversations', {
          current_user: current_user,
          selected_user: filter[0],
        });
      }

      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.error(error);
    }
  };
  const findUser = async id => {
    const database = getDatabase();
    const mySnapshot = await get(ref(database, `users/${id}`));
    return mySnapshot.val();
  };

  const renderItem = ({item, index}) => (
    <Card style={styles.card} onPress={() => handleUserPress(item)}>
      <View style={{flexDirection: 'row', alignItems: 'center'}}>
        <Avatar.Image
          source={{uri: BASE_URL_Image + item?.image}}
          size={wp(12)}
        />
        <Text style={styles.name}>{item?.user_name}</Text>
      </View>
    </Card>
  );

  const Parents = () => (
    <FlatList
      data={parentsList}
      keyExtractor={(item, index) => index.toString()}
      renderItem={renderItem}
    />
  );
  const Teachers = () => (
    <FlatList
      data={teachersList}
      keyExtractor={(item, index) => index.toString()}
      renderItem={renderItem}
    />
  );
  const Admins = () => (
    <FlatList
      data={adminsList}
      keyExtractor={(item, index) => index.toString()}
      renderItem={renderItem}
    />
  );

  const renderScene = SceneMap({
    first: Parents,
    second: Teachers,
    third: Admins,
  });
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <Header title="Chat" />
      <TabView
        navigationState={{index, routes}}
        renderScene={renderScene}
        onIndexChange={setIndex}
        initialLayout={{width: layout.width}}
      />
    </View>
  );
};

export default Chat;

const styles = StyleSheet.create({
  card: {
    width: wp(90),
    alignSelf: 'center',
    backgroundColor: '#fff',
    padding: 15,
    marginVertical: 5,
  },
  name: {
    color: '#000',
    fontSize: 18,
    marginLeft: 15,
    textTransform: 'capitalize',
  },
});
