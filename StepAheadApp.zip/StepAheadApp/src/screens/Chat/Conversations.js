import React, {useState, useCallback, useEffect} from 'react';
import {StyleSheet, Text, View, Image, TouchableOpacity} from 'react-native';
import Header from '../../components/Header';
import {
  GiftedChat,
  Send,
  Bubble,
  Time,
  InputToolbar,
  Composer,
  SystemMessage,
  Actions,
  MessageImage,
} from 'react-native-gifted-chat';
import appImages from '../../../assets/images';
import appColors from '../../../assets/colors';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import {Avatar} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {getDatabase, get, ref, onValue, off, update} from 'firebase/database';
import uuid from 'react-native-uuid';
import storage from '@react-native-firebase/storage';
import api, {BASE_URL_Image} from '../../constants/api';
import Snackbar from 'react-native-snackbar';
import Loader from '../../components/Loader';

const Conversations = ({navigation, route}) => {
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState([]);
  let {selected_user, current_user} = route?.params;

  useEffect(() => {
    //load old messages
    const loadData = async () => {
      const myChatroom = await fetchMessages();
      let list = myChatroom?.messages ? myChatroom?.messages?.reverse() : [];
      setMessages(list);
    };
    loadData();
    // set chatroom change listener
    const database = getDatabase();
    const chatroomRef = ref(database, `chatrooms/${selected_user?.chatroomId}`);
    onValue(chatroomRef, snapshot => {
      const data = snapshot.val();
      // setMessages(data?.messages);
      let list = data?.messages ? data?.messages?.reverse() : [];
      setMessages(list);
    });
    return () => {
      //remove chatroom listener
      off(chatroomRef);
    };
  }, [fetchMessages, selected_user?.chatroomId]);

  const fetchMessages = useCallback(async () => {
    const database = getDatabase();
    const snapshot = await get(
      ref(database, `chatrooms/${selected_user?.chatroomId}`),
    );
    return snapshot.val();
  }, [selected_user?.chatroomId]);

  const onSend = useCallback(
    async (msg = [], url, isImage, caption) => {
      //send the msg[0] to the other user
      const database = getDatabase();
      let newMessage = msg?.length > 0 ? msg[0] : '';

      //fetch fresh messages from server
      const currentChatroom = await fetchMessages();

      const lastMessages = currentChatroom.messages || [];

      let newMessageObj = {
        _id: uuid.v4(),
        type: isImage ? 'image' : 'text',
        //image: isImage ? url : '',
        text: isImage ? url : newMessage?.text,
        createdAt: new Date(),
        user: {
          _id: current_user?.id,
          name: current_user?.name,
        },
      };
      // return;
      update(ref(database, `chatrooms/${selected_user?.chatroomId}`), {
        messages: [...lastMessages, newMessageObj],
      });

      // setMessages(prevMessages =>
      //   GiftedChat.append(prevMessages, newMessageObj),
      // );
    },
    [fetchMessages, current_user.name, selected_user?.chatroomId],
  );

  const handleImageUpload = useCallback(async (fileName, filePath, caption) => {
    try {
      setLoading(true);
      const formData = new FormData();
      let imageObj = {
        uri: filePath,
        type: 'image/jpeg',
        name: fileName,
      };
      console.log('image obj :  ', imageObj);
      formData.append('image', imageObj);

      var requestOptions = {
        method: 'POST',
        body: formData,
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      };
      fetch(api.upload_image, requestOptions)
        .then(response => response.json())
        .then(async result => {
          console.log('result  : ', result);
          if (result?.status == true) {
            console.log('url uploaded....   :   ', result?.image_url);
            let url = result?.image_url;
            let isImage = true;
            let message = '';
            setLoading(false);

            // handleSend(message, url, isImage);
            onSend(message, url, isImage, '');
          } else {
            console.log('else......');

            Snackbar.show({
              text: result?.message,
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'green',
            });
          }
        })
        .catch(error => {
          console.log('error raised  :  ', error);
          Snackbar.show({
            text: 'Something went wrong',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        })
        .finally(() => setLoading(false));
    } catch (error) {
      setLoading(false);
    }

    // try {
    //   console.log('uploading image : ', fileName, filePath, caption);
    //   if (!fileName) return;
    //   setLoading(true);
    //   // let fileName = file?.path?.split('/').pop();

    //   const uploadTask = storage().ref().child(fileName).putFile(filePath);
    //   uploadTask.on(
    //     'state_changed',
    //     snapshot => {
    //       const progress = Math.round(
    //         (snapshot.bytesTransferred / snapshot.totalBytes) * 100,
    //       );
    //       console.log('progress  :  ', progress);
    //     },
    //     error => {
    //       // alert(error);
    //       console.log('error : ', error);
    //       setLoading(false);
    //     },
    //     async () => {
    //       const url = await storage().ref(fileName).getDownloadURL();
    //       console.log('url   :  ', url);
    //       let isImage = true;
    //       let message = '';
    //       setLoading(false);

    //       // handleSend(message, url, isImage);
    //       onSend(message, url, isImage, caption);
    //     },
    //   );
    // } catch (error) {
    //   console.log('Error raised: ' + error);
    //   setLoading(false);
    // }
  }, []);

  // const onSend = useCallback((messages = []) => {
  //   setMessages(previousMessages =>
  //     GiftedChat.append(previousMessages, messages),
  //   );
  // }, []);

  const handleImagePick = async () => {
    console.log('image called....');
    var options = {
      storageOptions: {
        skipBackup: true,
        path: 'images',
      },
    };
    let id = messages.length;
    await launchCamera(options)
      .then(res => {
        handleImageUpload(res.assets[0].fileName, res.assets[0].uri, '');
        if (res.assets[0].fileName && res.assets[0].uri) {
          //   setFileName(res.assets[0].fileName);
          //   setFileUri(res.assets[0].uri);
          //   setVisible(true);
          //   setIsSendPressed(false);
        } else {
          console.log('something went wrong in image picker');
        }
      })
      .catch(error => console.log(error));
  };

  const handleGallery = async () => {
    console.log('gallerry');
    var options = {
      storageOptions: {
        skipBackup: true,
        path: 'images',
      },
    };
    let id = messages.length;
    await launchImageLibrary(options)
      .then(res => {
        handleImageUpload(res.assets[0].fileName, res.assets[0].uri, '');
        // handleImageUpload(res.assets[0].fileName, res.assets[0].uri);
        if (res.assets[0].fileName && res.assets[0].uri) {
          //   setFileName(res.assets[0].fileName);
          //   setFileUri(res.assets[0].uri);
          //   setVisible(true);
          //   setIsSendPressed(false);
        } else {
          console.log('something went wrong in image picker');
        }
      })
      .catch(error => console.log(error));
  };

  const SendComponent = props => {
    return (
      <Send
        {...props}
        containerStyle={{
          borderWidth: 0,
        }}>
        <View
          style={{
            justifyContent: 'center',
            height: '100%',
            marginRight: 10,
            borderWidth: 0,
          }}>
          <Image
            source={appImages.send}
            style={{
              height: 20,
              width: 20,
              resizeMode: 'contain',
              // marginBottom: 14,
            }}
          />
        </View>
      </Send>
    );
  };
  const CustomInputToolbar = props => {
    return (
      <View
        style={{
          backgroundColor: '#fff',
          height: 60,
          alignContent: 'center',
          justifyContent: 'center',
          alignItems: 'center',
          position: 'relative',
          left: 0,
          right: 0,
          bottom: 9,
        }}>
        <View
          style={{
            backgroundColor: 'red',
            position: 'absolute',
            top: 52,
            left: 18,
            width: '100%',
          }}>
          <InputToolbar
            {...props}
            containerStyle={{
              //   backgroundColor: 'red',
              height: 42,
              borderColor: '#ccc',
              borderTopColor: '#ccc',
              borderTopWidth: 1,
              borderWidth: 1,
              borderRadius: 10,
              width: '90%',
            }}
          />
        </View>
      </View>
    );
  };

  const CustomBubble = props => {
    return (
      <Bubble
        // ref={_messageContainerRef}
        {...props}
        textStyle={{
          right: {
            color: '#ffffff',
          },
          left: {
            color: '#ffffff',
          },
        }}
        wrapperStyle={{
          left: {
            backgroundColor:
              props?.currentMessage?.text == '' ? 'transparent' : 'gray',
            marginBottom: 25,
          },
          right: {
            backgroundColor:
              props?.currentMessage?.text == ''
                ? 'transparent'
                : appColors.primary,
            marginBottom: 25,
          },
        }}
      />
    );
  };
  const CustomMessageImage = props => {
    return (
      <MessageImage
        {...props}
        //  source={{ uri: BASE}}
        source={appImages.camera}
        imageStyle={{
          width: 150,
          height: 100,
          borderRadius: 13,
          margin: 3,
          resizeMode: 'stretch',
        }}
      />
    );
  };

  const CustomBubbleText = props => {
    return (
      <View style={{padding: 8}}>
        {props?.currentMessage?.type == 'image' ? (
          <Image
            source={{uri: BASE_URL_Image + props?.currentMessage?.text}}
            style={{
              width: 150,
              height: 100,
              borderRadius: 13,
              margin: 3,
              resizeMode: 'stretch',
            }}
          />
        ) : (
          <Text
            style={{
              color: '#fff',
              paddingHorizontal: wp(1),
              paddingVertical: 0,
              //fontWeight: "bold",
            }}>
            {props.currentMessage.text}
          </Text>
        )}
      </View>
    );
  };

  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      {/* <Header title={'Conversations'} /> */}
      {loading && <Loader />}
      <View style={styles.headerView}>
        <TouchableOpacity
          style={{padding: 10, paddingLeft: 0}}
          onPress={() => navigation?.goBack()}>
          <Icon name="arrow-back-ios" size={22} color={'#fff'} />
        </TouchableOpacity>
        {/* {profile_Image ? (
            <Image
              source={{ uri: profile_Image }}
              style={{
                width: 40,
                height: 40,
                borderRadius: 40,
                backgroundColor: "#ccc",
                marginHorizontal: 10,
              }}
            />
          ) : ( */}
        {/* <Avatar.Image source={appImages.user} size={45} /> */}
        {/* )} */}

        <Text
          style={{
            color: '#fff',
            fontSize: 17,
            marginHorizontal: wp(5),
            textTransform: 'capitalize',
          }}>
          {selected_user?.name}
        </Text>
      </View>
      <View style={{flex: 1, paddingBottom: 15}}>
        <GiftedChat
          messages={messages}
          onSend={messages => onSend(messages)}
          user={{
            _id: current_user?.id,
          }}
          renderInputToolbar={props => {
            return <CustomInputToolbar {...props} />;
          }}
          renderSend={props => {
            return <SendComponent {...props} />;
          }}
          renderBubble={props => {
            return <CustomBubble {...props} />;
          }}
          // renderMessageImage={props => {
          //   return <CustomMessageImage {...props} />;
          // }}
          renderMessageText={props => {
            return <CustomBubbleText {...props} />;
          }}
          renderAvatar={null}
          alwaysShowSend
          renderActions={props => {
            return (
              <Actions
                style={{backgroundColor: 'red', marginBottom: 20}}
                {...props}
                options={{
                  ['Open Camera']: props => {
                    handleImagePick();
                  },
                  ['Open Gallery']: props => {
                    handleGallery();
                  },

                  Cancel: props => {
                    console.log('Cancel');
                  },
                }}
                icon={() => (
                  <Image
                    source={appImages.camera}
                    style={{width: 20, height: 20, marginTop: 2}}
                  />
                )}
              />
            );
          }}
        />
      </View>
    </View>
  );
};

export default Conversations;

const styles = StyleSheet.create({
  headerView: {
    backgroundColor: appColors.primary,
    paddingHorizontal: wp(5),
    paddingVertical: wp(2.5),
    flexDirection: 'row',
    alignItems: 'center',
  },
});
