import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ScrollView,
} from 'react-native';
import React, {useState} from 'react';
import AuthHeader from '../../components/AuthHeader';
import appColors from '../../../assets/colors';
import appFonts from '../../../assets/fonts';
import CTextInput from '../../components/CTextInput';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import CButton from '../../components/CButton/CButton';

import EntypoIcon from 'react-native-vector-icons/Entypo';
import FontistoIcon from 'react-native-vector-icons/Fontisto';

import api from '../../constants/api';
import Loader from '../../components/Loader';
import Snackbar from 'react-native-snackbar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Login = ({navigation}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const [loading, setLoading] = useState(false);

  const validate = (email, password) => {
    let reg = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w\w+)+$/;

    if (email?.length == 0) {
      Snackbar.show({
        text: 'Please Enter your email address',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (reg.test(email) == false) {
      Snackbar.show({
        text: 'Please Enter valid email address.',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (password?.length == 0) {
      Snackbar.show({
        text: 'Please Enter your password',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (password?.length < 6) {
      Snackbar.show({
        text: 'Password length must be at least 6 characters long',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
    } else {
      return true;
    }
  };

  const handleLogin = () => {
    // navigation.navigate('RegisterStudent');
    // navigation.navigate('TabNavigation');
    // navigation.navigate('TabNavigation_Student');
    // navigation.navigate('DrawerNavigation_Admin');
    // return;
    if (validate(email, password)) {
      setLoading(true);
      var requestOptions = {
        method: 'POST',
        body: JSON.stringify({
          email: email,
          password: password,
        }),
        headers: {
          'Content-Type': 'application/json',
        },
      };
      fetch(api.login, requestOptions)
        .then(response => response.json())
        .then(async result => {
          console.log('response :   ', result);
          if (result?.status == 'success') {
            let user_type = result?.result?.user_type;
            await AsyncStorage.setItem('user_type', result?.result?.user_type);
            await AsyncStorage.setItem('user', JSON.stringify(result?.result));
            await AsyncStorage.setItem('user_id', result?.result?._id);
            if (user_type == 'student') {
              // navigation.navigate('TabNavigation_Student');
              navigation.navigate('DrawerNavigation_Student');
            } else if (user_type == 'teacher') {
              // navigation.navigate('TabNavigation_Teacher');
              navigation.navigate('DrawerNavigation_Teacher');
            } else {
              // navigation.navigate('TabNavigation');
              navigation.navigate('DrawerNavigation_Admin');
            }
          } else {
            Snackbar.show({
              text: result?.message,
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'red',
            });
          }
        })
        .catch(error => {
          console.log('error raised  :  ', error);
          Snackbar.show({
            text: 'Something went wrong',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        })
        .finally(() => setLoading(false));
    }
  };
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <View style={{flex: 1}}>
          <AuthHeader />
          {loading && <Loader />}
          <View style={{flex: 1, alignItems: 'center'}}>
            <Text
              style={{
                color: appColors.dark,
                fontSize: 22,
                fontFamily: appFonts.Time_New_Roman_Bold,
                marginBottom: hp(4),
              }}>
              Login
            </Text>

            <CTextInput
              heading={'Email'}
              state={email}
              onChangeText={txt => setEmail(txt)}
              placeholder={'abc@gmail.com'}
              setIsActive={setIsActive}
              isActive={isActive}
              id="email"
              containerStyle={{width: wp(85)}}
              leftIcon={
                <FontistoIcon
                  name="email"
                  size={wp(5)}
                  color={isActive == 'email' ? appColors.primary : '#D2D2D2'}
                />
              }
            />

            <CTextInput
              heading={'Password'}
              state={password}
              onChangeText={txt => setPassword(txt)}
              secureTextEntry={!showPassword}
              id="password"
              placeholder="******"
              setIsActive={setIsActive}
              containerStyle={{width: wp(85), marginTop: -5}}
              leftIcon={
                <FontistoIcon
                  name="locked"
                  size={wp(5)}
                  color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
                />
              }
              rightIcon={
                <EntypoIcon
                  onPress={() => setShowPassword(!showPassword)}
                  name={!showPassword ? 'eye-with-line' : 'eye'}
                  size={wp(5)}
                  color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
                />
              }
            />

            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => navigation.navigate('ForgetPassword')}>
              <Text
                style={{
                  color: appColors.primary,
                  textAlign: 'right',
                  width: wp(85),
                }}>
                Forgot Password?
              </Text>
            </TouchableOpacity>

            <CButton title="Login" onPress={() => handleLogin()} />
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default Login;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});
