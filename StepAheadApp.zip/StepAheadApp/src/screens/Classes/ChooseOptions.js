import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  FlatList,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import appColors from '../../../assets/colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appFonts from '../../../assets/fonts';
import Header from '../../components/Header';
import CTextInput from '../../components/CTextInput';
import Feather from 'react-native-vector-icons/Feather';
import CButton from '../../components/CButton/CButton';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FontistoIcon from 'react-native-vector-icons/Fontisto';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

import api from '../../constants/api';
import Loader from '../../components/Loader';
import Snackbar from 'react-native-snackbar';
import {Card, Searchbar} from 'react-native-paper';
import {STYLE} from '../STYLE';
import {useFocusEffect} from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ChooseOptions = ({navigation, route}) => {
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <ScrollView
        contentContainerStyle={{
          height: hp(100),
          width: wp(100),
          paddingBottom: 50,
        }}>
        <Header title={'Choose Option'} />
        <View style={styles.container}>
          <Card
            style={styles.card}
            onPress={() => {
              navigation.navigate('Attendance', {
                id: route?.params?.id,
                name: route?.params?.name,
              });
            }}>
            <Text style={styles.heading}>Attendance</Text>
          </Card>
          <Card
            style={styles.card}
            onPress={() => {
              navigation.navigate('Students', {
                id: route?.params?.id,
                name: route?.params?.name,
              });
            }}>
            <Text style={styles.heading}>Mark Today Activity</Text>
          </Card>
          <Card
            style={styles.card}
            onPress={() => {
              navigation.navigate('Students', {
                id: route?.params?.id,
                name: route?.params?.name,
                type: 'progress',
              });
            }}>
            <Text style={styles.heading}>Add Student Progress</Text>
          </Card>
        </View>
      </ScrollView>
    </View>
  );
};

export default ChooseOptions;

const styles = StyleSheet.create({
  container: {
    width: wp(100),
    // height: hp(100),
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    width: wp(90),
    height: hp(22),
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: hp(5),
    marginBottom: hp(1),
    backgroundColor: '#fff',
  },
  heading: {
    fontSize: 16,
    color: appColors.dark,
    fontWeight: '600',
  },
});
