import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  FlatList,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import appColors from '../../../assets/colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appFonts from '../../../assets/fonts';
import Header from '../../components/Header';
import CTextInput from '../../components/CTextInput';
import Feather from 'react-native-vector-icons/Feather';
import CButton from '../../components/CButton/CButton';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FontistoIcon from 'react-native-vector-icons/Fontisto';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

import api from '../../constants/api';
import Loader from '../../components/Loader';
import Snackbar from 'react-native-snackbar';
import {Card, Searchbar} from 'react-native-paper';
import {STYLE} from '../STYLE';
import {useFocusEffect} from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AllClasses_Teacher = ({navigation}) => {
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = React.useState('');
  const [classesList, setClassesList] = useState([]);
  const [classesListCopy, setClassesListCopy] = useState([]);

  const onChangeSearch = query => {
    setSearchQuery(query);
    if (query) {
      const filter = classesListCopy.filter(item =>
        item?.className?.toLowerCase().includes(query?.toLowerCase()),
      );
      setClassesList(filter);
    } else {
      setClassesList(classesListCopy);
    }
  };

  useFocusEffect(
    React.useCallback(() => {
      getAllClassesList();
    }, []),
  );

  const getAllClassesList = async () => {
    setLoading(true);
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };
    let user_id = await AsyncStorage.getItem('user_id');
    let url = api.get_teacher_classes + user_id;
    console.log('url : ', url);
    fetch(url, requestOptions)
      .then(response => response.json())
      .then(result => {
        if (result?.status == true || result?.status == 'success') {
          let list = result?.result ? result?.result : [];
          setClassesList(list);
          setClassesListCopy(list);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <Header title={'Classes  teacher'} />
        {loading && <Loader />}
        <Searchbar
          placeholder="Search"
          onChangeText={onChangeSearch}
          value={searchQuery}
          style={{
            backgroundColor: '#EEEEEE',
            marginBottom: 10,
            borderRadius: 0,
            elevation: 5,
          }}
        />
        <ScrollView horizontal contentContainerStyle={{width: wp(100)}}>
          <FlatList
            data={classesList}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({item}) => {
              return (
                <Card
                  style={STYLE.classCard}
                  onPress={() => {
                    // navigation.navigate('ClassDetail', {id: item?._id})
                    navigation.navigate('ChooseOptions', {
                      id: item?._id,
                      name: item?.className,
                    });
                  }}>
                  <Text style={STYLE.classCardText}>{item?.className}</Text>
                </Card>
              );
            }}
          />
        </ScrollView>
      </ScrollView>
    </View>
  );
};

export default AllClasses_Teacher;

const styles = StyleSheet.create({
  card: {},
});
