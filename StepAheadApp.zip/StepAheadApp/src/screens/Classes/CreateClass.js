import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  FlatList,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import appColors from '../../../assets/colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appFonts from '../../../assets/fonts';
import Header from '../../components/Header';
import CTextInput from '../../components/CTextInput';
import Feather from 'react-native-vector-icons/Feather';
import CButton from '../../components/CButton/CButton';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FontistoIcon from 'react-native-vector-icons/Fontisto';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

import api, {BASE_URL_Image} from '../../constants/api';
import Loader from '../../components/Loader';
import Snackbar from 'react-native-snackbar';
import {Avatar, Card, RadioButton, Searchbar} from 'react-native-paper';
import {STYLE} from '../STYLE';
import appImages from '../../../assets/images';
import {Picker} from '@react-native-picker/picker';

const CreateClass = ({navigation}) => {
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = React.useState('');
  const [checked, setChecked] = React.useState('first');
  const onChangeSearch = query => setSearchQuery(query);
  const [isActive, setIsActive] = useState(false);
  const [className, setClassName] = useState('');
  const [selectedTeacher, setSelectedTeacher] = useState('');
  const [studentList, setStudentList] = useState([]);
  const [teachersList, setTeachersList] = useState([]);
  const [classesList, setClassesList] = useState([
    {
      id: 0,
      name: 'Art Class',
    },
    {
      id: 0,
      name: 'Art Class',
    },
    {
      id: 0,
      name: 'Art Class',
    },
    {
      id: 0,
      name: 'Art Class',
    },
    {
      id: 0,
      name: 'Art Class',
    },
    {
      id: 0,
      name: 'Art Class',
    },
    {
      id: 0,
      name: 'Art Class',
    },
    {
      id: 0,
      name: 'Art Class',
    },
    {
      id: 1,
      name: 'Sports Class',
    },
    {
      id: 2,
      name: 'Swimming Class',
    },
    {
      id: 3,
      name: 'Kitchning Class',
    },
    {
      id: 3,
      name: 'Kitchning Class',
    },
    {
      id: 3,
      name: 'Kitchning Class',
    },
    {
      id: 3,
      name: 'Kitchning Class',
    },
    {
      id: 3,
      name: 'Kitchning Class',
    },
  ]);

  useEffect(() => {
    getAllStudentsList();
    getAllTeachersList();
  }, []);

  const getAllStudentsList = async () => {
    setLoading(true);

    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };

    fetch(api.getAllStudents, requestOptions)
      .then(response => response.json())
      .then(result => {
        if (result?.status == true || result?.status == 'success') {
          let list = result?.result ? result?.result : [];
          setStudentList(list);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };

  const getAllTeachersList = async () => {
    setLoading(true);

    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };

    fetch(api.getAllTeachers, requestOptions)
      .then(response => response.json())
      .then(result => {
        if (result?.status == true || result?.status == 'success') {
          let list = result?.result ? result?.result : [];
          setTeachersList(list);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };

  const handleCreateClass = async () => {
    const selected_Students = studentList
      ?.filter(item => item?.selected)
      ?.map(item => item._id);
    if (className?.length == 0) {
      Snackbar.show({
        text: 'Please Enter Class Name',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
    } else if (selectedTeacher?.length == 0) {
      Snackbar.show({
        text: 'Please Select Teacher',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
    } else if (selected_Students?.length == 0) {
      Snackbar.show({
        text: 'Please Select Students to add in class',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
    } else {
      setLoading(true);
      var requestOptions = {
        method: 'POST',
        body: JSON.stringify({
          className: className,
          teacher: selectedTeacher,
          students: selected_Students,
        }),
        headers: {
          'Content-Type': 'application/json',
        },
      };
      fetch(api.create_class, requestOptions)
        .then(response => response.json())
        .then(async result => {
          console.log('response :   ', result);
          if (result?.status == 'success' || result?.status == true) {
            navigation.goBack();
            Snackbar.show({
              text: result?.message,
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'green',
            });
          } else {
            Snackbar.show({
              text: result?.message,
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'red',
            });
          }
        })
        .catch(error => {
          console.log('error raised  :  ', error);
          Snackbar.show({
            text: 'Something went wrong',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        })
        .finally(() => setLoading(false));
    }
  };

  const handleSelectStudent = id => {
    const newData = studentList?.map(element => {
      if (element?._id == id) {
        return {
          ...element,
          selected: true,
        };
      } else {
        return {
          ...element,
        };
      }
    });
    setStudentList(newData);
  };
  return (
    <View style={{flex: 1, backgroundColor: '#fff', marginBottom: 20}}>
      {loading && <Loader />}
      <ScrollView>
        <Header title={'Create Class'} />
        <CTextInput
          state={className}
          onChangeText={txt => setClassName(txt)}
          placeholder={'Class Name'}
          setIsActive={setIsActive}
          isActive={isActive}
          id="className"
          containerStyle={{
            width: wp(90),
            alignSelf: 'center',
            marginBottom: 0,
          }}
        />
        <View style={{backgroundColor: '#fff'}}>
          <View style={styles.textInputView}>
            <Text style={styles.title1}>Assign Teacher</Text>
            <View style={styles.pickerContainer}>
              <Picker
                selectedValue={selectedTeacher}
                mode="dialog"
                style={{height: hp(6.2)}}
                itemStyle={{height: hp(6.2)}}
                onValueChange={(itemValue, itemIndex) => {
                  setSelectedTeacher(itemValue);
                }}>
                {teachersList?.map((item, index) => {
                  return (
                    <Picker.Item
                      key={index}
                      label={item?.user_name}
                      value={item?._id}
                    />
                  );
                })}
              </Picker>
            </View>
          </View>
        </View>

        <ScrollView
          horizontal
          style={{flex: 1}}
          showsVerticalScrollIndicator={false}>
          <FlatList
            scrollEnabled={false}
            contentContainerStyle={{
              flexGrow: 1,
            }}
            data={studentList}
            keyExtractor={(item, index) => index.toString()}
            ListHeaderComponent={() => (
              <Text style={{...styles.title1, marginLeft: 15}}>
                Select Student to Register :
              </Text>
            )}
            renderItem={({item}) => {
              return (
                <Card style={styles.card}>
                  <View style={styles.rowView}>
                    <Avatar.Image
                      size={50}
                      source={{uri: BASE_URL_Image + item?.image}}
                      style={styles.avatarStyle}
                    />
                    <Text style={styles.title}>{item?.user_name}</Text>
                    <RadioButton
                      value="first"
                      status={item?.selected ? 'checked' : 'unchecked'}
                      onPress={() => handleSelectStudent(item?._id)}
                    />
                  </View>
                </Card>
              );
            }}
          />
        </ScrollView>
        <CButton title="Create" onPress={() => handleCreateClass()} />
      </ScrollView>
    </View>
  );
};

export default CreateClass;

const styles = StyleSheet.create({
  card: {
    backgroundColor: appColors.white,
    marginVertical: 8,
    padding: 10,
    marginHorizontal: 10,
    borderRadius: 0,
    alignItems: 'flex-start',
    width: wp(90),
    alignSelf: 'center',
  },
  title1: {
    color: appColors.dark,
    fontSize: 14,
    // fontFamily: appFonts.Time_New_Roman,
    fontWeight: '400',
    fontSize: 18,
    // textAlign: 'center',
    marginVertical: 10,
    marginTop: 20,
  },
  avatarStyle: {
    // marginLeft: 10,
    marginRight: 20,
  },
  title: {
    color: appColors.dark,
    fontSize: 14,
    fontFamily: appFonts.Time_New_Roman_Bold,
    flex: 1,
  },
  rowView: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
  },

  textInputView: {
    // marginVertical: 12,
    marginHorizontal: 15,
  },
  textInputHeading: {
    color: '#000000',
    fontSize: 16,
    marginTop: 5,
    marginBottom: hp(1),
    fontWeight: '500',
    // fontFamily: "Rubik-Regular",
  },
  pickerContainer: {
    borderRadius: wp(2.5),
    borderWidth: 1,
    borderColor: '#CDCDCD',
    width: wp(90),
    justifyContent: 'center',
  },
});
