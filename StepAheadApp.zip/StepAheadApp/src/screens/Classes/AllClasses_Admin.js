import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  FlatList,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import appColors from '../../../assets/colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appFonts from '../../../assets/fonts';
import Header from '../../components/Header';
import CTextInput from '../../components/CTextInput';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Feather from 'react-native-vector-icons/Feather';
import CButton from '../../components/CButton/CButton';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FontistoIcon from 'react-native-vector-icons/Fontisto';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

import api from '../../constants/api';
import Loader from '../../components/Loader';
import Snackbar from 'react-native-snackbar';
import {Card, Searchbar} from 'react-native-paper';
import {STYLE} from '../STYLE';
import {useFocusEffect} from '@react-navigation/native';

const AllClasses_Admin = ({navigation}) => {
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = React.useState('');
  const [classesList, setClassesList] = useState([]);
  const [classesListCopy, setClassesListCopy] = useState([]);

  const onChangeSearch = query => {
    setSearchQuery(query);
    if (query) {
      const filter = classesListCopy.filter(item =>
        item?.className?.toLowerCase().includes(query?.toLowerCase()),
      );
      setClassesList(filter);
    } else {
      setClassesList(classesListCopy);
    }
  };

  useFocusEffect(
    React.useCallback(() => {
      getAllClassesList();
    }, []),
  );

  const getAllClassesList = async () => {
    setLoading(true);
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };

    fetch(api.get_all_classes, requestOptions)
      .then(response => response.json())
      .then(result => {
        if (result?.status == true || result?.status == 'success') {
          let list = result?.result ? result?.result : [];
          setClassesList(list);
          setClassesListCopy(list);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };

  const handleDeleteClass = id => {
    setLoading(true);
    var requestOptions = {
      method: 'DELETE',
      redirect: 'follow',
    };
    let url = api.delete_class + id;
    console.log('url : ', url);
    fetch(url, requestOptions)
      .then(response => response.json())
      .then(result => {
        if (result?.status == true || result?.status == 'success') {
          const filter = classesList.filter(item => item?._id != id);
          setClassesList(filter);
          Snackbar.show({
            text: 'Class Deleted successfully',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'green',
          });
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <Header
          title={'Classes'}
          rightIcon={
            <TouchableOpacity
              onPress={() => navigation.navigate('CreateClass')}>
              <Ionicons
                name="add-circle"
                size={wp(8)}
                color={appColors.white}
              />
            </TouchableOpacity>
          }
        />
        {loading && <Loader />}
        <Searchbar
          placeholder="Search"
          onChangeText={onChangeSearch}
          value={searchQuery}
          style={{
            backgroundColor: '#EEEEEE',
            marginBottom: 10,
            borderRadius: 0,
            elevation: 5,
          }}
        />
        <ScrollView horizontal contentContainerStyle={{width: wp(100)}}>
          <FlatList
            data={classesList}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({item}) => {
              return (
                <View>
                  <Card
                    style={STYLE.classCard}
                    onPress={() =>
                      navigation.navigate('ClassDetail', {id: item?._id})
                    }>
                    <Text style={STYLE.classCardText}>{item?.className}</Text>
                  </Card>
                  <TouchableOpacity
                    onPress={() => handleDeleteClass(item?._id)}
                    style={{position: 'absolute', right: '10%', top: '30%'}}>
                    <MaterialCommunityIcons
                      size={25}
                      name="delete"
                      color={'red'}
                    />
                  </TouchableOpacity>
                </View>
              );
            }}
          />
        </ScrollView>
      </ScrollView>
    </View>
  );
};

export default AllClasses_Admin;

const styles = StyleSheet.create({
  card: {},
});
