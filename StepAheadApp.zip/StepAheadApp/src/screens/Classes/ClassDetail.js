import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  FlatList,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import appColors from '../../../assets/colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appFonts from '../../../assets/fonts';
import Header from '../../components/Header';
import CTextInput from '../../components/CTextInput';
import Feather from 'react-native-vector-icons/Feather';
import CButton from '../../components/CButton/CButton';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FontistoIcon from 'react-native-vector-icons/Fontisto';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

import api, {BASE_URL_Image} from '../../constants/api';
import Loader from '../../components/Loader';
import Snackbar from 'react-native-snackbar';
import {Avatar, Card, RadioButton, Searchbar} from 'react-native-paper';
import {STYLE} from '../STYLE';
import appImages from '../../../assets/images';
import {Picker} from '@react-native-picker/picker';

const ClassDetail = ({navigation, route}) => {
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = React.useState('');
  const onChangeSearch = query => {
    setSearchQuery(query);
    if (query) {
      console.log('query changed : ', query?.toLowerCase());
      const filter = studentListCopy.filter(item =>
        item?.user_name?.toLowerCase().includes(query?.toLowerCase()),
      );
      setStudentList(filter);
    } else {
      setStudentList(studentListCopy);
    }
  };

  const [classDetail, setClassDetail] = useState(null);
  const [studentList, setStudentList] = useState([]);
  const [studentListCopy, setStudentListCopy] = useState([]);

  useEffect(() => {
    getClassDetail();
  }, []);
  const getClassDetail = async () => {
    setLoading(true);
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };
    fetch(api.get_class_detail + route?.params?.id, requestOptions)
      .then(response => response.json())
      .then(result => {
        if (result?.status == true || result?.status == 'success') {
          let list = result?.result ? result?.result : null;
          setClassDetail(list);
          setStudentList(list?.students);
          setStudentListCopy(list?.students);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: '#fff',
        marginBottom: 20,
      }}>
      {loading && <Loader />}
      <ScrollView>
        <Header title={classDetail ? classDetail?.className : ''} />
        <Searchbar
          placeholder="Search"
          onChangeText={onChangeSearch}
          value={searchQuery}
          style={{
            backgroundColor: '#EEEEEE',
            borderRadius: 0,
            elevation: 5,
          }}
        />
        {classDetail && (
          <View style={{paddingHorizontal: 10}}>
            <View style={{backgroundColor: '#fff'}}>
              <View style={styles.textInputView}>
                <Text style={styles.title1}>Assignee Teacher</Text>
                <View style={styles.pickerContainer}>
                  <Text
                    style={{
                      fontSize: 18,
                      lineHeight: 45,
                      color: appColors.dark,
                      marginLeft: 15,
                    }}>
                    {classDetail?.teacher?.user_name}
                  </Text>
                </View>
              </View>
            </View>

            <ScrollView
              horizontal
              style={{
                flex: 1,
                marginLeft: 10,
              }}
              showsVerticalScrollIndicator={false}>
              <FlatList
                scrollEnabled={false}
                contentContainerStyle={{
                  flexGrow: 1,
                }}
                data={studentList}
                keyExtractor={(item, index) => index.toString()}
                ListHeaderComponent={() => (
                  <Text style={{...styles.title1}}>
                    Registered Student List:
                  </Text>
                )}
                renderItem={({item}) => {
                  return (
                    <Card style={styles.card}>
                      <View style={styles.rowView}>
                        <Avatar.Image
                          size={50}
                          source={{uri: BASE_URL_Image + item?.image}}
                          style={styles.avatarStyle}
                        />
                        <Text style={styles.title}>{item?.user_name}</Text>
                      </View>
                    </Card>
                  );
                }}
              />
            </ScrollView>
          </View>
        )}
      </ScrollView>
    </View>
  );
};

export default ClassDetail;

const styles = StyleSheet.create({
  card: {
    backgroundColor: appColors.white,
    marginVertical: 8,
    padding: 10,
    marginHorizontal: 10,
    borderRadius: 0,
    alignItems: 'flex-start',
    width: wp(85),
    alignSelf: 'center',
  },
  title1: {
    color: appColors.dark,
    fontSize: 14,
    // fontFamily: appFonts.Time_New_Roman,
    fontWeight: '400',
    fontSize: 18,
    // textAlign: 'center',
    marginVertical: 10,
    marginTop: 20,
  },
  avatarStyle: {
    // marginLeft: 10,
    marginRight: 20,
  },
  title: {
    color: appColors.dark,
    fontSize: 14,
    fontFamily: appFonts.Time_New_Roman_Bold,
    flex: 1,
  },
  rowView: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
  },

  textInputView: {
    // marginVertical: 12,
    marginHorizontal: 15,
  },
  textInputHeading: {
    color: '#000000',
    fontSize: 16,
    marginTop: 5,
    marginBottom: hp(1),
    fontWeight: '500',
    // fontFamily: "Rubik-Regular",
  },
  pickerContainer: {
    borderRadius: wp(2.5),
    borderWidth: 1,
    borderColor: '#CDCDCD',
    // width: wp(90),
    justifyContent: 'center',
  },
});
