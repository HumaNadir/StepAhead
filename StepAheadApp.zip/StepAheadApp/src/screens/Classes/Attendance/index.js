import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  FlatList,
  Image,
} from 'react-native';

import React, {useState, useEffect} from 'react';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';

import appColors from '../../../../assets/colors';
import Header from '../../../components/Header';
import api, {BASE_URL_Image} from '../../../constants/api';
import Loader from '../../../components/Loader';
import STYLE from '../../STYLE';

import CButton from '../../../components/CButton/CButton';

import Foundation from 'react-native-vector-icons/Foundation';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FontistoIcon from 'react-native-vector-icons/Fontisto';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import DateTimePickerModal from 'react-native-modal-datetime-picker';

import Snackbar from 'react-native-snackbar';
import {Card, Searchbar} from 'react-native-paper';

import {useFocusEffect} from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import moment from 'moment/moment';
import {RadioButton} from 'react-native-paper';
import appImages from '../../../../assets/images';
import {Avatar} from 'react-native-paper';
const Attendance = ({navigation, route}) => {
  const [loading, setLoading] = useState(false);
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [selectedDate, setSelectedDate] = useState(
    moment(new Date()).format('YYYY/MM/DD'),
  );
  const [selectedDateObj, setSelectedDateObj] = useState(new Date());
  const [checked, setChecked] = React.useState('first');
  const [studentList, setStudentList] = useState([]);

  const [isAttendance_already_added, setIsAttendance_already_added] =
    useState(false);

  const [attendance_id, setAttendance_id] = useState('');

  useEffect(() => {
    // getClassDetail(route?.params?.id);

    getClassAttendance(
      route?.params?.id,
      moment(new Date()).format('YYYY/MM/DD'),
    );
  }, []);

  const getClassDetail = async classId => {
    setLoading(true);
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };

    let url = api.get_class_detail + classId;

    fetch(url, requestOptions)
      .then(response => response.json())
      .then(result => {
        if (result?.status == true || result?.status == 'success') {
          let student_list = result?.result?.students
            ? result?.result?.students
            : [];
          setStudentList(student_list);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };

  const getClassAttendance = (class_id, date) => {
    setIsAttendance_already_added(false);
    setLoading(true);
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };
    let url =
      api.get_attendance_of_class + '?date=' + date + '&class_id=' + class_id;
    fetch(url, requestOptions)
      .then(response => response.json())
      .then(result => {
        if (result?.status == true || result?.status == 'success') {
          setAttendance_id(result?.result?._id);
          let attendence = result?.result?.attendence
            ? result?.result?.attendence
            : [];
          let list = [];
          for (const element of attendence) {
            let obj = {
              ...element?.student_id,
              isPresent: element?.isPresent,
            };
            list.push(obj);
          }
          setStudentList(list);
          setIsAttendance_already_added(true);
        } else {
          getClassDetail(class_id);
          // Snackbar.show({
          //   text: result?.message,
          //   duration: Snackbar.LENGTH_SHORT,
          //   backgroundColor: 'red',
          // });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleConfirm = date => {
    setSelectedDate(moment(date).format('YYYY/MM/DD'));
    hideDatePicker();
    getClassAttendance(route?.params?.id, moment(date).format('YYYY/MM/DD'));
    setSelectedDateObj(date);
  };
  const handleSelect = (id, isPresent) => {
    const newData = studentList?.map(item => {
      if (item?._id == id) {
        return {
          ...item,
          isPresent: isPresent,
        };
      } else {
        return {
          ...item,
        };
      }
    });
    setStudentList(newData);
  };

  const handleMarkAllAsPresent = () => {
    const newData = studentList?.map(item => {
      return {
        ...item,
        isPresent: true,
      };
    });
    setStudentList(newData);
  };
  const handleMarkAllAsAbsent = () => {
    const newData = studentList?.map(item => {
      return {
        ...item,
        isPresent: false,
      };
    });
    setStudentList(newData);
  };

  const handleSaveAttendance = async () => {
    const student_attendance = studentList?.map(item => {
      return {
        student_id: item?._id,
        isPresent: item?.isPresent ? item?.isPresent : false,
      };
    });

    let data = {
      class_id: route?.params?.id,
      date: selectedDate,
      attendence: student_attendance,
    };

    setLoading(true);

    var requestOptions = {
      method: 'POST',
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json',
      },
    };
    fetch(api.add_attendance, requestOptions)
      .then(response => response.json())
      .then(async result => {
        if (result?.status == true) {
          Snackbar.show({
            text: 'Attendance Added successfully',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'green',
          });
          navigation.goBack();
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => {
        console.log('error raised  :  ', error);
        Snackbar.show({
          text: 'Something went wrong',
          duration: Snackbar.LENGTH_SHORT,
          backgroundColor: 'red',
        });
      })
      .finally(() => setLoading(false));
  };
  const handleUpdateAttendance = async () => {
    const student_attendance = studentList?.map(item => {
      return {
        student_id: item?._id,
        isPresent: item?.isPresent ? item?.isPresent : false,
      };
    });

    let data = {
      attendence_id: attendance_id,
      attendence: student_attendance,
    };

    console.log('data   ', data);

    setLoading(true);

    var requestOptions = {
      method: 'PUT',
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json',
      },
    };
    fetch(api.update_attendance, requestOptions)
      .then(response => response.json())
      .then(async result => {
        console.log('result  :  ', result);
        if (result?.status == true) {
          Snackbar.show({
            text: 'Attendance Updated successfully',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'green',
          });
          navigation.goBack();
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => {
        console.log('error raised  :  ', error);
        Snackbar.show({
          text: 'Something went wrong',
          duration: Snackbar.LENGTH_SHORT,
          backgroundColor: 'red',
        });
      })
      .finally(() => setLoading(false));
  };
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <ScrollView>
        <Header title={'Attendance'} />
        {loading && <Loader />}

        <ScrollView horizontal contentContainerStyle={{width: wp(100)}}>
          <View style={{paddingVertical: 20, paddingHorizontal: wp(5)}}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                width: wp(90),
                marginBottom: 5,
              }}>
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: '500',
                  color: appColors.dark,
                }}>
                {route?.params?.name} Attendance
              </Text>
              <TouchableOpacity onPress={() => showDatePicker()}>
                <Foundation name="calendar" size={30} />
              </TouchableOpacity>
            </View>
            <Text
              style={{
                fontSize: 16,
                fontWeight: '500',
                color: appColors.dark,
                marginBottom: hp(2),
              }}>
              {selectedDate}
            </Text>

            <FlatList
              style={{paddingHorizontal: 5, paddingBottom: 10}}
              data={studentList}
              keyExtractor={(item, index) => index.toString()}
              ListHeaderComponent={() => (
                <View style={{...styles.card}}>
                  <View style={styles.rowView}>
                    <Text style={styles.title}>S.No</Text>
                    <View style={styles.rowView1}>
                      {/* <Avatar.Image
                      source={appImages.user}
                      size={25}
                      style={styles.avatar}
                    /> */}
                      <Text style={styles.title}>Student Name</Text>
                    </View>
                    <View style={styles.rowView1}>
                      <RadioButton
                        value="first"
                        status={checked === 'first' ? 'checked' : 'unchecked'}
                        onPress={() => setChecked('first')}
                      />
                      <Text style={{...styles.text, marginLeft: -4}}>P</Text>
                      <RadioButton
                        value="first"
                        status={checked === 'first' ? 'checked' : 'unchecked'}
                        onPress={() => setChecked('first')}
                      />
                      <Text style={{...styles.text, marginLeft: -4}}>A</Text>
                    </View>
                  </View>
                </View>
              )}
              renderItem={({item, index}) => {
                return (
                  <View style={styles.card}>
                    <View style={styles.rowView}>
                      <Text style={styles.text}>00{index + 1}</Text>
                      <View style={styles.rowView1}>
                        {item?.image ? (
                          <Avatar.Image
                            source={{uri: BASE_URL_Image + item?.image}}
                            size={25}
                            style={styles.avatar}
                          />
                        ) : (
                          <Avatar.Image
                            source={appImages.user}
                            size={25}
                            style={styles.avatar}
                          />
                        )}

                        <Text style={styles.text}>{item?.user_name}</Text>
                      </View>
                      <View style={styles.rowView1}>
                        <RadioButton
                          value="first"
                          status={
                            item?.isPresent === true ? 'checked' : 'unchecked'
                          }
                          onPress={() => handleSelect(item?._id, true)}
                        />
                        <RadioButton
                          value="first"
                          status={
                            item?.isPresent === false ? 'checked' : 'unchecked'
                          }
                          onPress={() => handleSelect(item?._id, false)}
                        />
                      </View>
                    </View>
                  </View>
                );
              }}
              ListFooterComponent={() => {
                return (
                  <View style={{...styles.rowView, marginTop: 5}}>
                    <View style={styles.rowView1}>
                      <Text style={styles.title}>Mark All :</Text>
                    </View>
                    <View style={styles.rowView1}>
                      <RadioButton
                        value="first1"
                        status={checked === 'first1' ? 'checked' : 'unchecked'}
                        onPress={() => {
                          handleMarkAllAsPresent();
                          setChecked('first1');
                        }}
                      />
                      <Text style={{...styles.text, marginLeft: -4}}>P</Text>
                      <RadioButton
                        value="first2"
                        status={checked === 'first2' ? 'checked' : 'unchecked'}
                        onPress={() => {
                          handleMarkAllAsAbsent();
                          setChecked('first2');
                        }}
                      />
                      <Text style={{...styles.text, marginLeft: -4}}>A</Text>
                    </View>
                  </View>
                );
              }}
            />
            {isAttendance_already_added ? (
              <CButton
                title="Update"
                onPress={() => handleUpdateAttendance()}
              />
            ) : (
              <CButton title="Save" onPress={() => handleSaveAttendance()} />
            )}
          </View>
        </ScrollView>
        <DateTimePickerModal
          isVisible={isDatePickerVisible}
          mode="date"
          date={selectedDateObj}
          maximumDate={new Date()}
          onConfirm={handleConfirm}
          onCancel={hideDatePicker}
        />
      </ScrollView>
    </View>
  );
};

export default Attendance;

const styles = StyleSheet.create({
  card: {
    width: wp(85),
    alignSelf: 'center',
    // marginHorizontal: 10,
    // height: hp(30),
    padding: wp(3),
    marginBottom: hp(2),
    // marginVertical: hp(2),
    borderRadius: wp(3),
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.29,
    shadowRadius: 4.65,

    elevation: 7,
  },
  rowView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  rowView1: {flexDirection: 'row', alignItems: 'center'},
  title: {color: appColors.dark, fontSize: 13, fontWeight: '600'},
  text: {color: appColors.dark, fontSize: 13},
  avatar: {marginHorizontal: 5},
});
