import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const AttendanceStudent = () => {
  return (
    <View>
      <Text>AttendanceStudent</Text>
    </View>
  );
};

export default AttendanceStudent;

const styles = StyleSheet.create({});
