import {
  StyleSheet,
  Text,
  View,
  FlatList,
  Image,
  TouchableOpacity,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import Header from '../../components/Header';
import Loader from '../../components/Loader';
import Snackbar from 'react-native-snackbar';
import api, {BASE_URL_Image} from '../../constants/api';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Avatar} from 'react-native-paper';
import appColors from '../../../assets/colors';
import appFonts from '../../../assets/fonts';
import appImages from '../../../assets/images';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {Item} from 'react-native-paper/lib/typescript/src/components/Drawer/Drawer';

const Students = ({navigation, route}) => {
  const [loading, setLoading] = useState(false);
  const [studentList, setStudentList] = useState([]);
  useEffect(() => {
    getClassStudents(route?.params?.id);
  }, []);

  const getClassStudents = async classId => {
    setLoading(true);
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };

    let url = api.get_class_detail + classId;

    fetch(url, requestOptions)
      .then(response => response.json())
      .then(result => {
        if (result?.status == true || result?.status == 'success') {
          let student_list = result?.result?.students
            ? result?.result?.students
            : [];
          setStudentList(student_list);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };

  const onItemSelect = async item => {
    if (route?.params?.type == 'progress') {
      navigation.navigate('Graph', {
        id: item?._id,
        name: route?.params?.name,

        user_type: item?.user_type,
        profile: item?.image,
        email: item?.email,
        name: item?.user_name,
      });
    } else {
      navigation.navigate('MarkTodayActivity', {
        id: item?._id,
      });
    }
  };
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <Header title={'Select Student'} />
      {loading && <Loader />}
      <FlatList
        style={{paddingHorizontal: 5, paddingBottom: 10, paddingVertical: 15}}
        data={studentList}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({item, index}) => {
          return (
            <TouchableOpacity
              onPress={() => onItemSelect(item)}
              style={styles.card}>
              <View style={styles.rowView}>
                <Text style={styles.text}>00{index + 1}</Text>
                <View style={styles.rowView1}>
                  {item?.image ? (
                    <Avatar.Image
                      source={{uri: BASE_URL_Image + item?.image}}
                      size={25}
                      style={styles.avatar}
                    />
                  ) : (
                    <Avatar.Image
                      source={appImages.user}
                      size={25}
                      style={styles.avatar}
                    />
                  )}

                  <Text style={styles.text}>{item?.user_name}</Text>
                </View>
              </View>
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );
};

export default Students;

const styles = StyleSheet.create({
  card: {
    width: wp(85),
    alignSelf: 'center',
    // marginHorizontal: 10,
    // height: hp(30),
    padding: wp(5),
    marginBottom: hp(2),
    // marginVertical: hp(2),
    borderRadius: wp(3),
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.29,
    shadowRadius: 4.65,

    elevation: 7,
  },
  rowView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  rowView1: {flexDirection: 'row', alignItems: 'center', flex: 0.95},
  title: {color: appColors.dark, fontSize: 13, fontWeight: '600'},
  text: {color: appColors.dark, fontSize: 13},
  avatar: {marginHorizontal: 5},
});
