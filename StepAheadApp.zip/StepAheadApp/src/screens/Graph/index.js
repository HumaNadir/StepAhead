import {
  StyleSheet,
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';

import api from '../../constants/api';
import Snackbar from 'react-native-snackbar';
import CButton from '../../components/CButton/CButton';
import Loader from '../../components/Loader';
import Header from '../../components/Header';

import {Avatar, Modal} from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import appImages from '../../../assets/images';

const Graph = ({navigation, route}) => {
  const [loading, setLoading] = useState(false);
  const [selectedColor, setSelectedColor] = useState('#FFF');
  const [visible, setVisible] = React.useState(false);
  const showModal = () => setVisible(true);
  const hideModal = () => setVisible(false);

  const [selectedArray, setSelectedArray] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [selectedKey, setSelectedKey] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState(0);

  const [currentUser, setCurrentUser] = useState('');
  const [user_type, setUser_type] = useState('');

  useEffect(() => {
    getCurrentUser();
  }, []);

  const getCurrentUser = async () => {
    let user_id = await AsyncStorage.getItem('user_id');
    let user_type1 = await AsyncStorage.getItem('user_type');
    console.log('user_type1  : ', user_type1);
    setCurrentUser(user_id);
    setUser_type(user_type1);
  };

  const [arr1, setArr1] = useState([
    {
      title: 'a1',
      data: [
        {
          key: 'a10',
          color: 'yellow',
        },
        {
          key: 'a11',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a2',
      data: [
        {
          key: 'a20',
          color: 'red',
        },
        {
          key: 'a21',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a3',
      data: [
        {
          key: 'a30',
          color: 'yellow',
        },
        {
          key: 'a31',
          color: '#FFF',
        },
        {
          key: 'a31',
          color: '#FFF',
        },
        {
          key: 'a32',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a4',
      data: [
        {
          key: 'a40',
          color: 'yellow',
        },
        {
          key: 'a41',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a5',
      data: [
        {
          key: 'a50',
          color: 'yellow',
        },
        {
          key: 'a51',
          color: '#FFF',
        },
        {
          key: 'a52',
          color: '#FFF',
        },
        {
          key: 'a53',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a6',
      data: [
        {
          key: 'a60',
          color: 'yellow',
        },
        {
          key: 'a61',
          color: '#FFF',
        },
        {
          key: 'a62',
          color: '#FFF',
        },
        {
          key: 'a63',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a7',
      data: [
        {
          key: 'a70',
          color: 'yellow',
        },
        {
          key: 'a71',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a8',
      data: [
        {
          key: 'a80',
          color: 'yellow',
        },
        {
          key: 'a81',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a9',
      data: [
        {
          key: 'a90',
          color: 'yellow',
        },
        {
          key: '191',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a10',
      data: [
        {
          key: 'a100',
          color: 'yellow',
        },
        {
          key: 'a101',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a11',
      data: [
        {
          key: 'a110',
          color: 'yellow',
        },
        {
          key: 'a111',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a12',
      data: [
        {
          key: 'a120',
          color: '#FFF',
        },
        {
          key: 'a121',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a13',
      data: [
        {
          key: 'a130',
          color: '#FFF',
        },
        {
          key: 'a131',
          color: '#FFF',
        },
        {
          key: 'a132',
          color: '#FFF',
        },
        {
          key: 'a133',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a14',
      data: [
        {
          key: 'a140',
          color: '#FFF',
        },
        {
          key: 'a141',
          color: '#FFF',
        },
        {
          key: 'a142',
          color: '#FFF',
        },
        {
          key: 'a143',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a15',
      data: [
        {
          key: 'a150',
          color: '#FFF',
        },
        {
          key: 'a151',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a16',
      data: [
        {
          key: 'a160',
          color: '#FFF',
        },
        {
          key: 'a161',
          color: '#FFF',
        },
        {
          key: 'a162',
          color: '#FFF',
        },
        {
          key: 'a163',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a17',
      data: [
        {
          key: 'a170',
          color: '#FFF',
        },
        {
          key: 'a171',
          color: '#FFF',
        },
        {
          key: 'a172',
          color: '#FFF',
        },
        {
          key: 'a173',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a18',
      data: [
        {
          key: 'a180',
          color: '#FFF',
        },
        {
          key: 'a181',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'a19',
      data: [
        {
          key: 'a190',
          color: '#FFF',
        },
        {
          key: 'a191',
          color: '#FFF',
        },
      ],
    },
  ]);

  const [arr2, setArr2] = useState([
    {
      title: 'b1',
      data: [
        {
          key: 'b10',
          color: 'yellow',
        },
        {
          key: 'b11',
          color: '#FFF',
        },
        {
          key: 'b12',
          color: 'yellow',
        },
        {
          key: 'b13',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b2',
      data: [
        {
          key: 'b20',
          color: 'red',
        },
        {
          key: 'b21',
          color: '#FFF',
        },
        {
          key: 'b22',
          color: '#FFF',
        },
        {
          key: 'b23',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b3',
      data: [
        {
          key: 'b30',
          color: 'yellow',
        },
        {
          key: 'b31',
          color: '#FFF',
        },
        {
          key: 'b31',
          color: '#FFF',
        },
        {
          key: 'b32',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b4',
      data: [
        {
          key: 'b40',
          color: 'yellow',
        },
        {
          key: 'b41',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b5',
      data: [
        {
          key: 'b50',
          color: 'yellow',
        },
        {
          key: 'b51',
          color: '#FFF',
        },
        {
          key: 'b52',
          color: '#FFF',
        },
        {
          key: 'b53',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b6',
      data: [
        {
          key: 'b60',
          color: 'yellow',
        },
        {
          key: 'b61',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b7',
      data: [
        {
          key: 'b70',
          color: 'yellow',
        },
        {
          key: 'b71',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b8',
      data: [
        {
          key: 'b80',
          color: 'yellow',
        },
        {
          key: 'b81',
          color: '#FFF',
        },
        {
          key: 'b82',
          color: '#FFF',
        },
        {
          key: 'b83',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b9',
      data: [
        {
          key: 'b90',
          color: 'yellow',
        },
        {
          key: 'b91',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b10',
      data: [
        {
          key: 'b100',
          color: 'yellow',
        },
        {
          key: 'b101',
          color: '#FFF',
        },
        {
          key: 'b102',
          color: '#FFF',
        },
        {
          key: 'b103',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b11',
      data: [
        {
          key: 'b110',
          color: 'yellow',
        },
        {
          key: 'b111',
          color: '#FFF',
        },
        {
          key: 'b112',
          color: '#FFF',
        },
        {
          key: 'b113',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b12',
      data: [
        {
          key: 'b120',
          color: '#FFF',
        },
        {
          key: 'b121',
          color: '#FFF',
        },
        {
          key: 'b122',
          color: '#FFF',
        },
        {
          key: 'b123',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b13',
      data: [
        {
          key: 'b130',
          color: '#FFF',
        },
        {
          key: 'b131',
          color: '#FFF',
        },
        {
          key: 'b132',
          color: '#FFF',
        },
        {
          key: 'b133',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b14',
      data: [
        {
          key: 'b140',
          color: '#FFF',
        },
        {
          key: 'b141',
          color: '#FFF',
        },
        {
          key: 'b142',
          color: '#FFF',
        },
        {
          key: 'b143',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b15',
      data: [
        {
          key: 'b150',
          color: '#FFF',
        },
        {
          key: 'b151',
          color: '#FFF',
        },
        {
          key: 'b152',
          color: '#FFF',
        },
        {
          key: 'b153',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b16',
      data: [
        {
          key: 'b160',
          color: '#FFF',
        },
        {
          key: 'b161',
          color: '#FFF',
        },
        {
          key: 'b162',
          color: '#FFF',
        },
        {
          key: 'b163',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b17',
      data: [
        {
          key: 'b170',
          color: '#FFF',
        },
        {
          key: 'b171',
          color: '#FFF',
        },
        {
          key: 'b172',
          color: '#FFF',
        },
        {
          key: 'b173',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b18',
      data: [
        {
          key: 'b180',
          color: '#FFF',
        },
        {
          key: 'b181',
          color: '#FFF',
        },
        {
          key: 'b182',
          color: '#FFF',
        },
        {
          key: 'b183',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b19',
      data: [
        {
          key: 'b190',
          color: '#FFF',
        },
        {
          key: 'b191',
          color: '#FFF',
        },
        {
          key: 'b192',
          color: '#FFF',
        },
        {
          key: 'b193',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b20',
      data: [
        {
          key: 'b200',
          color: '#FFF',
        },
        {
          key: 'b201',
          color: '#FFF',
        },
        {
          key: 'b202',
          color: '#FFF',
        },
        {
          key: 'b203',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b21',
      data: [
        {
          key: 'b210',
          color: '#FFF',
        },
        {
          key: 'b211',
          color: '#FFF',
        },
        {
          key: 'b212',
          color: '#FFF',
        },
        {
          key: 'b213',
          color: '#FFF',
        },
      ],
    },

    {
      title: 'b22',
      data: [
        {
          key: 'b220',
          color: '#FFF',
        },
        {
          key: 'b221',
          color: '#FFF',
        },
        {
          key: 'b222',
          color: '#FFF',
        },
        {
          key: 'b223',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b23',
      data: [
        {
          key: 'b230',
          color: '#FFF',
        },
        {
          key: 'b231',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b24',
      data: [
        {
          key: 'b240',
          color: '#FFF',
        },
        {
          key: 'b241',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b25',
      data: [
        {
          key: 'b250',
          color: '#FFF',
        },
        {
          key: 'b251',
          color: '#FFF',
        },
        {
          key: 'b252',
          color: '#FFF',
        },
        {
          key: 'b253',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b26',
      data: [
        {
          key: 'b260',
          color: '#FFF',
        },
        {
          key: 'b261',
          color: '#FFF',
        },
        {
          key: 'b262',
          color: '#FFF',
        },
        {
          key: 'b263',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'b27',
      data: [
        {
          key: 'b270',
          color: '#FFF',
        },
        {
          key: 'b271',
          color: '#FFF',
        },
      ],
    },
  ]);

  const [arr3, setArr3] = useState([
    {
      title: 'c1',
      data: [
        {
          key: 'c10',
          color: 'yellow',
        },
        {
          key: 'c11',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c2',
      data: [
        {
          key: 'c20',
          color: 'red',
        },
        {
          key: 'c21',
          color: '#FFF',
        },
        {
          key: 'c22',
          color: '#FFF',
        },
        {
          key: 'c23',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c3',
      data: [
        {
          key: 'c30',
          color: 'yellow',
        },
        {
          key: 'c31',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c4',
      data: [
        {
          key: 'c40',
          color: 'yellow',
        },
        {
          key: 'c41',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c5',
      data: [
        {
          key: 'c50',
          color: 'yellow',
        },
        {
          key: 'c51',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c6',
      data: [
        {
          key: 'c60',
          color: 'yellow',
        },
        {
          key: 'c61',
          color: '#FFF',
        },
        {
          key: 'c62',
          color: '#FFF',
        },
        {
          key: 'c63',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c7',
      data: [
        {
          key: 'c70',
          color: 'yellow',
        },
        {
          key: 'c71',
          color: '#FFF',
        },
        {
          key: 'c72',
          color: '#FFF',
        },
        {
          key: 'c73',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c8',
      data: [
        {
          key: 'c80',
          color: 'yellow',
        },
        {
          key: 'c81',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c9',
      data: [
        {
          key: 'c90',
          color: 'yellow',
        },
        {
          key: 'c91',
          color: '#FFF',
        },
        {
          key: 'c92',
          color: '#FFF',
        },
        {
          key: 'c93',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c10',
      data: [
        {
          key: 'c100',
          color: 'yellow',
        },
        {
          key: 'c101',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c11',
      data: [
        {
          key: 'c110',
          color: 'yellow',
        },
        {
          key: 'c111',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c12',
      data: [
        {
          key: 'c120',
          color: '#FFF',
        },
        {
          key: 'c121',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c13',
      data: [
        {
          key: 'c130',
          color: '#FFF',
        },
        {
          key: 'c131',
          color: '#FFF',
        },
        {
          key: 'c132',
          color: '#FFF',
        },
        {
          key: 'c133',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c14',
      data: [
        {
          key: 'c140',
          color: '#FFF',
        },
        {
          key: 'c141',
          color: '#FFF',
        },
        {
          key: 'c142',
          color: '#FFF',
        },
        {
          key: 'c143',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c15',
      data: [
        {
          key: 'c150',
          color: '#FFF',
        },
        {
          key: 'c151',
          color: '#FFF',
        },
        {
          key: 'c152',
          color: '#FFF',
        },
        {
          key: 'c153',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c16',
      data: [
        {
          key: 'c160',
          color: '#FFF',
        },
        {
          key: 'c161',
          color: '#FFF',
        },
        {
          key: 'c162',
          color: '#FFF',
        },
        {
          key: 'c163',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c17',
      data: [
        {
          key: 'c170',
          color: '#FFF',
        },
        {
          key: 'c171',
          color: '#FFF',
        },
        {
          key: 'c172',
          color: '#FFF',
        },
        {
          key: 'c173',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c18',
      data: [
        {
          key: 'c180',
          color: '#FFF',
        },
        {
          key: 'c181',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c19',
      data: [
        {
          key: 'c190',
          color: '#FFF',
        },
        {
          key: 'c191',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c20',
      data: [
        {
          key: 'c200',
          color: '#FFF',
        },
        {
          key: 'c201',
          color: '#FFF',
        },
        ,
      ],
    },
    {
      title: 'c21',
      data: [
        {
          key: 'c210',
          color: '#FFF',
        },
        {
          key: 'c211',
          color: '#FFF',
        },
        {
          key: 'c212',
          color: '#FFF',
        },
        {
          key: 'c213',
          color: '#FFF',
        },
      ],
    },

    {
      title: 'c22',
      data: [
        {
          key: 'c220',
          color: '#FFF',
        },
        {
          key: 'c221',
          color: '#FFF',
        },
        {
          key: 'c222',
          color: '#FFF',
        },
        {
          key: 'c223',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c23',
      data: [
        {
          key: 'c230',
          color: '#FFF',
        },
        {
          key: 'c231',
          color: '#FFF',
        },
        {
          key: 'c232',
          color: '#FFF',
        },
        {
          key: 'c233',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c24',
      data: [
        {
          key: 'c240',
          color: '#FFF',
        },
        {
          key: 'c241',
          color: '#FFF',
        },
        {
          key: 'c242',
          color: '#FFF',
        },
        {
          key: 'c243',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c25',
      data: [
        {
          key: 'c250',
          color: '#FFF',
        },
        {
          key: 'c251',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c26',
      data: [
        {
          key: 'c260',
          color: '#FFF',
        },
        {
          key: 'c261',
          color: '#FFF',
        },
        {
          key: 'c262',
          color: '#FFF',
        },
        {
          key: 'c263',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c27',
      data: [
        {
          key: 'c270',
          color: '#FFF',
        },
        {
          key: 'c271',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c28',
      data: [
        {
          key: 'c280',
          color: '#FFF',
        },
        {
          key: 'c281',
          color: '#FFF',
        },
        {
          key: 'c282',
          color: '#FFF',
        },
        {
          key: 'c283',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c29',
      data: [
        {
          key: 'c290',
          color: '#FFF',
        },
        {
          key: 'c291',
          color: '#FFF',
        },
        {
          key: 'c292',
          color: '#FFF',
        },
        {
          key: 'c293',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c30',
      data: [
        {
          key: 'c300',
          color: '#FFF',
        },
        {
          key: 'c301',
          color: '#FFF',
        },
        {
          key: 'c302',
          color: '#FFF',
        },
        {
          key: 'c303',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c31',
      data: [
        {
          key: 'c310',
          color: '#FFF',
        },
        {
          key: 'c311',
          color: '#FFF',
        },
        {
          key: 'c312',
          color: '#FFF',
        },
        {
          key: 'c313',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c32',
      data: [
        {
          key: 'c320',
          color: '#FFF',
        },
        {
          key: 'c321',
          color: '#FFF',
        },
      ],
    },
    {
      title: 'c33',
      data: [
        {
          key: 'c330',
          color: '#FFF',
        },
        {
          key: 'c331',
          color: '#FFF',
        },
        {
          key: 'c332',
          color: '#FFF',
        },
        {
          key: 'c333',
          color: '#FFF',
        },
      ],
    },
  ]);

  const updateRecord1 = (item, index, key) => {
    console.log('item, index, key  : ', item, index, key);
    let list = [...arr1];
    let selected = arr1[index];
    // console.log('selected  : ', selected);
    const newData = selected?.data?.map(element => {
      if (element?.key == key) {
        return {
          ...element,
          color: selectedColor,
        };
      } else {
        return {
          ...element,
        };
      }
    });

    // console.log('newData  : ', newData);
    list[index] = {
      title: item?.title,
      data: newData,
    };
    setArr1(list);
  };
  const updateRecord2 = (item, index, key) => {
    let list = [...arr2];
    let selected = arr2[index];
    // console.log('selected  : ', selected);
    const newData = selected?.data?.map(element => {
      if (element?.key == key) {
        return {
          ...element,
          color: selectedColor,
        };
      } else {
        return {
          ...element,
        };
      }
    });

    // console.log('newData  : ', newData);
    list[index] = {
      title: item?.title,
      data: newData,
    };
    setArr2(list);
  };

  const updateRecord3 = (item, index, key) => {
    let list = [...arr3];
    let selected = arr3[index];
    // console.log('selected  : ', selected);
    const newData = selected?.data?.map(element => {
      if (element?.key == key) {
        return {
          ...element,
          color: selectedColor,
        };
      } else {
        return {
          ...element,
        };
      }
    });

    // console.log('newData  : ', newData);
    list[index] = {
      title: item?.title,
      data: newData,
    };
    setArr3(list);
  };

  useEffect(() => {
    getStudentProgress();
  }, []);

  const getStudentProgress = async () => {
    setLoading(true);
    console.log('route?.prams?.id  : ', route?.params?.id);
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };
    fetch(
      api.get_student_graph + '?student_id=' + route?.params?.id,
      requestOptions,
    )
      .then(response => response.json())
      .then(result => {
        if (result?.status == true || result?.status == 'success') {
          let list = result?.result ? result?.result : null;
          let list1 = list?.a || [];
          let list2 = list?.b || [];
          let list3 = list?.c || [];
          setArr1(list1);
          setArr2(list2);
          setArr3(list3);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };

  const saveRecord = async () => {
    setLoading(true);
    var requestOptions = {
      method: 'POST',
      body: JSON.stringify({
        student_id: route?.params?.id,
        a: arr1,
        b: arr2,
        c: arr3,
      }),
      headers: {
        'Content-Type': 'application/json',
      },
    };
    fetch(api.create_student_graph, requestOptions)
      .then(response => response.json())
      .then(async result => {
        console.log('response :   ', result);
        if (result?.status == 'success' || result?.status == true) {
          navigation.goBack();
          Snackbar.show({
            text: 'Record inserted/updated successfully',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'green',
          });
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => {
        console.log('error raised  :  ', error);
        Snackbar.show({
          text: 'Something went wrong',
          duration: Snackbar.LENGTH_SHORT,
          backgroundColor: 'red',
        });
      })
      .finally(() => setLoading(false));
  };

  const handleFill = async () => {
    hideModal();
    console.log('selected color: ', selectedColor);
    if (selectedArray == 'a') {
      updateRecord1(selectedItem, selectedIndex, selectedKey);
    } else if (selectedArray == 'b') {
      updateRecord2(selectedItem, selectedIndex, selectedKey);
    } else {
      updateRecord3(selectedItem, selectedIndex, selectedKey);
    }
  };

  const RenderItem1 = ({element, item, index, data}) => {
    return (
      <TouchableOpacity
        disabled={user_type == 'student' ? true : false}
        onPress={() => {
          // updateRecord1(item, index, element.item.key);
          setSelectedArray('a');
          setSelectedItem(item);
          setSelectedIndex(index);
          setSelectedKey(element.item.key);
          showModal();
        }}
        style={{
          height: 30,
          // flex: 1,
          width: 150 / item?.data?.length,
          borderWidth: 1,
          backgroundColor: element?.item?.color,
        }}></TouchableOpacity>
    );
  };
  const renderItem = ({item, index}) => {
    return (
      <View style={styles.graphView}>
        <Text
          style={{
            color: '#000',
            textTransform: 'capitalize',
            width: 35,
          }}>
          {item?.title}
        </Text>
        <View style={{flexGrow: 1}}>
          <FlatList
            data={item?.data}
            horizontal
            keyExtractor={(item, index) => index.toString()}
            renderItem={element => (
              <RenderItem1
                element={element}
                item={item}
                data={arr1}
                index={index}
              />
            )}
          />
        </View>
      </View>
    );
  };

  const RenderItemB_1 = ({element, item, index, data}) => {
    return (
      <TouchableOpacity
        disabled={user_type == 'student' ? true : false}
        onPress={() => {
          // updateRecord1(item, index, element.item.key);
          setSelectedArray('b');
          setSelectedItem(item);
          setSelectedIndex(index);
          setSelectedKey(element.item.key);
          showModal();
        }}
        style={{
          height: 30,
          // flex: 1,
          width: 150 / item?.data?.length,
          borderWidth: 1,
          backgroundColor: element?.item?.color,
        }}></TouchableOpacity>
    );
  };
  const renderItem_B = ({item, index}) => {
    return (
      <View style={styles.graphView}>
        <Text
          style={{
            color: '#000',
            textTransform: 'capitalize',
            width: 35,
          }}>
          {item?.title}
        </Text>
        <View style={{flexGrow: 1}}>
          <FlatList
            data={item?.data}
            horizontal
            keyExtractor={(item, index) => index.toString()}
            renderItem={element => (
              <RenderItemB_1
                element={element}
                item={item}
                data={'b'}
                index={index}
              />
            )}
          />
        </View>
      </View>
    );
  };

  const RenderItemC_1 = ({element, item, index, data}) => {
    return (
      <TouchableOpacity
        disabled={user_type == 'student' ? true : false}
        onPress={() => {
          // updateRecord1(item, index, element.item.key);
          setSelectedArray('c');
          setSelectedItem(item);
          setSelectedIndex(index);
          setSelectedKey(element.item.key);
          showModal();
        }}
        style={{
          height: 30,
          // flex: 1,
          width: 150 / item?.data?.length,
          borderWidth: 1,
          backgroundColor: element?.item?.color,
        }}></TouchableOpacity>
    );
  };
  const renderItem_C = ({item, index}) => {
    return (
      <View style={styles.graphView}>
        <Text
          style={{
            color: '#000',
            textTransform: 'capitalize',
            width: 35,
          }}>
          {item?.title}
        </Text>
        <View style={{flexGrow: 1}}>
          <FlatList
            data={item?.data}
            horizontal
            keyExtractor={(item, index) => index.toString()}
            renderItem={element => (
              <RenderItemC_1
                element={element}
                item={item}
                data={'c'}
                index={index}
              />
            )}
          />
        </View>
      </View>
    );
  };
  const keyExtractor = (item, index) => index.toString();

  return (
    <View style={{flex: 1}}>
      <ScrollView style={{height: hp(100), width: wp(100)}}>
        <Header title={'Progress Report'} />

        {loading && <Loader />}
        {!loading && (
          <View style={styles.container}>
            <View
              style={{
                marginVertical: 10,
                flexDirection: 'row',
                height: 40,
                alignItems: 'center',
              }}>
              <Avatar.Image source={appImages.user} size={40} />
              <Text
                style={{
                  fontSize: 16,
                  marginHorizontal: 10,
                  fontWeight: '500',
                  color: '#000',
                }}>
                {route?.params?.name}
              </Text>
            </View>

            <ScrollView horizontal contentContainerStyle={{flexGrow: 1}}>
              <View
                style={{
                  position: 'absolute',
                  top: 40,
                  flexDirection: 'row',
                  zIndex: 999,
                }}>
                <View style={{alignItems: 'center'}}>
                  <TouchableOpacity
                    // onPress={() => {
                    //   console.log('pressed....');
                    //   showModal();
                    //   setSelectedColor('#FFFF00');
                    // }}
                    style={{
                      width: 60,
                      height: 40,
                      backgroundColor: '#FFFF00',
                      marginHorizontal: 5,
                    }}></TouchableOpacity>
                  <Text style={{color: '#FFFF00', fontSize: 16}}>Best</Text>
                </View>
                <View style={{alignItems: 'center'}}>
                  <TouchableOpacity
                    // onPress={() => {
                    //   showModal();
                    //   setSelectedColor('#0000FF');
                    // }}
                    style={{
                      width: 60,
                      height: 40,
                      backgroundColor: '#0000FF',
                      marginHorizontal: 5,
                    }}></TouchableOpacity>
                  <Text style={{color: '#0000FF', fontSize: 16}}>Average</Text>
                </View>
                <View style={{alignItems: 'center'}}>
                  <TouchableOpacity
                    // onPress={() => {
                    //   showModal();
                    //   setSelectedColor('#D41919');
                    // }}
                    style={{
                      width: 60,
                      height: 40,
                      backgroundColor: '#D41919',
                      marginHorizontal: 5,
                    }}></TouchableOpacity>
                  <Text style={{color: '#D41919', fontSize: 16}}>Bad</Text>
                </View>
              </View>
              <View style={{marginRight: 10, width: 200}}>
                <FlatList
                  //   style={{flexDirection: 'column-reverse'}}
                  data={arr1}
                  inverted
                  renderItem={renderItem}
                  keyExtractor={keyExtractor}
                  initialNumToRender={10}
                  maxToRenderPerBatch={10}
                  removeClippedSubviews={true} // Unmount components when outside of window
                  updateCellsBatchingPeriod={100} // Increase time between renders
                  windowSize={7} // Reduce the window size
                />
              </View>
              <View style={{marginRight: 10, width: 200}}>
                <FlatList
                  //   style={{flexDirection: 'column-reverse'}}
                  data={arr2}
                  inverted
                  renderItem={renderItem_B}
                  keyExtractor={keyExtractor}
                  initialNumToRender={10}
                  maxToRenderPerBatch={10}
                  removeClippedSubviews={true} // Unmount components when outside of window
                  updateCellsBatchingPeriod={100} // Increase time between renders
                  windowSize={7} // Reduce the window size
                />
              </View>
              <View style={{marginRight: 10, width: 200}}>
                <FlatList
                  //   style={{flexDirection: 'column-reverse'}}
                  data={arr3}
                  inverted
                  renderItem={renderItem_C}
                  keyExtractor={keyExtractor}
                  initialNumToRender={10}
                  maxToRenderPerBatch={10}
                  removeClippedSubviews={true} // Unmount components when outside of window
                  updateCellsBatchingPeriod={100} // Increase time between renders
                  windowSize={7} // Reduce the window size
                />
              </View>
            </ScrollView>

            {user_type == 'teacher' && (
              <CButton title="Update" onPress={() => saveRecord()} />
            )}
          </View>
        )}
      </ScrollView>
      <Modal
        visible={visible}
        onDismiss={hideModal}
        contentContainerStyle={{
          flex: 1,
          height: hp(100),
          width: wp(100),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <View
          style={{
            backgroundColor: '#FFF',
            borderRadius: 10,
            padding: 20,
          }}>
          <Text
            style={{
              color: '#000',
              fontSize: 16,
              fontWeight: '500',
              textAlign: 'center',
              marginBottom: 15,
            }}>
            Select Color
          </Text>
          <View
            style={{
              flexDirection: 'row',
            }}>
            <TouchableOpacity
              onPress={() => setSelectedColor('#FFFF00')}
              style={{
                width: 60,
                height: 40,
                backgroundColor: '#FFFF00',
                marginHorizontal: 5,
                opacity: selectedColor == '#FFFF00' ? 0.9 : 1,
              }}></TouchableOpacity>
            <TouchableOpacity
              onPress={() => setSelectedColor('#0000FF')}
              style={{
                width: 60,
                height: 40,
                backgroundColor: '#0000FF',
                marginHorizontal: 5,
                opacity: selectedColor == '#0000FF' ? 0.9 : 1,
              }}></TouchableOpacity>
            <TouchableOpacity
              onPress={() => setSelectedColor('#D41919')}
              style={{
                opacity: selectedColor == '#D41919' ? 0.9 : 1,
                width: 60,
                height: 40,
                backgroundColor: '#D41919',
                marginHorizontal: 5,
              }}></TouchableOpacity>
          </View>
          <CButton title="Fill" width={wp(50)} onPress={() => handleFill()} />
        </View>
      </Modal>
    </View>
  );
};

export default Graph;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
    justifyContent: 'flex-end',
    padding: 20,
  },

  graphView: {
    flexDirection: 'row',
    // backgroundColor: 'red',
    width: 170,
  },
});

// import {StyleSheet, Text, View, TouchableOpacity, FlatList} from 'react-native';
// import React, {useState, useEffect} from 'react';

// const Graph = () => {
//   const [data, setData] = useState([
//     {
//       a1: [
//         {
//           key: 'a10',
//           color: 'red',
//         },
//         {
//           key: 'a11',
//         color: '#FFF',
//         },
//       ],
//       a2: [
//         {
//           key: 'a10',
//           color: 'yellow',
//         },
//         {
//           key: 'a11',
//           color: '#FFF',
//         },
//       ],
//       a3: [
//         {
//           key: 'a30',
//           color: 'yellow',
//         },
//         {
//           key: 'a31',
//          color: '#FFF',
//         },
//         {
//           key: 'a31',
//           color: '#FFF',
//         },
//         {
//           key: 'a32',
//           color: '#FFF',
//         },
//       ],
//       a4: [
//         {
//           key: 'a40',
//           color: 'yellow',
//         },
//         {
//           key: 'a41',
//          color: '#FFF',
//         },
//       ],
//       a5: [
//         {
//           key: 'a50',
//           color: 'yellow',
//         },
//         {
//           key: 'a51',
//          color: '#FFF',
//         },
//       ],
//       a6: [
//         {
//           key: 'a60',
//           color: 'yellow',
//         },
//         {
//           key: 'a61',
//           color: '#FFF',
//         },
//       ],
//       a7: [
//         {
//           key: 'a70',
//           color: 'yellow',
//         },
//         {
//           key: 'a71',
//           color: '#FFF',
//         },
//       ],
//       a8: [
//         {
//           key: 'a80',
//           color: 'yellow',
//         },
//         {
//           key: 'a81',
//           color: '#FFF',
//         },
//       ],
//       a9: [
//         {
//           key: 'a90',
//           color: 'yellow',
//         },
//         {
//           key: '191',
//           color: '#FFF',
//         },
//       ],
//       a10: [
//         {
//           key: 'a100',
//           color: 'yellow',
//         },
//         {
//           key: 'a101',
//           color: '#FFF',
//         },
//         {
//           key: '102',
//           color: '#FFF',
//         },
//       ],
//     },
//   ]);

//   const [arr, setArr] = useState([
//     [
//       {
//         key: 'a10',
//         color: 'yellow',
//       },
//       {
//         key: 'a11',
//         color: '#FFF',
//       },
//     ],
//     [
//       {
//         key: 'a10',
//         color: 'red',
//       },
//       {
//         key: 'a11',
//      color: '#FFF',
//       },
//     ],
//     [
//       {
//         key: 'a30',
//         color: 'yellow',
//       },
//       {
//         key: 'a31',
//       color: '#FFF',
//       },
//       {
//         key: 'a31',
//       color: '#FFF',
//       },
//       {
//         key: 'a32',
//         color: '#FFF',
//       },
//     ],
//     [
//       {
//         key: 'a40',
//         color: 'yellow',
//       },
//       {
//         key: 'a41',
//         color: '#FFF',
//       },
//     ],
//     [
//       {
//         key: 'a50',
//         color: 'yellow',
//       },
//       {
//         key: 'a51',
//         color: '#FFF',
//       },
//     ],
//     [
//       {
//         key: 'a60',
//         color: 'yellow',
//       },
//       {
//         key: 'a61',
//         color: '#FFF',
//       },
//     ],
//     [
//       {
//         key: 'a70',
//         color: 'yellow',
//       },
//       {
//         key: 'a71',
//         color: '#FFF',
//       },
//     ],
//     [
//       {
//         key: 'a80',
//         color: 'yellow',
//       },
//       {
//         key: 'a81',
//         color: '#FFF',
//       },
//     ],
//     [
//       {
//         key: 'a90',
//         color: 'yellow',
//       },
//       {
//         key: '191',
//         color: '#FFF',
//       },
//     ],
//     [
//       {
//         key: 'a100',
//         color: 'yellow',
//       },
//       {
//         key: 'a101',
//         color: '#FFF',
//       },
//       {
//         key: '102',
//         color: '#FFF',
//       },
//     ],
//   ]);

//   const [arr1, setArr1] = useState([
//     {
//       title: 'a1',
//       data: [
//         {
//           key: 'a10',
//           color: 'yellow',
//         },
//         {
//           key: 'a11',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a2',
//       data: [
//         {
//           key: 'a20',
//           color: 'red',
//         },
//         {
//           key: 'a21',
//         color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a3',
//       data: [
//         {
//           key: 'a30',
//           color: 'yellow',
//         },
//         {
//           key: 'a31',
//         color: '#FFF',
//         },
//         {
//           key: 'a31',
//       color: '#FFF',
//         },
//         {
//           key: 'a32',
//         color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a4',
//       data: [
//         {
//           key: 'a40',
//           color: 'yellow',
//         },
//         {
//           key: 'a41',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a5',
//       data: [
//         {
//           key: 'a50',
//           color: 'yellow',
//         },
//         {
//           key: 'a51',
//           color: '#FFF',
//         },
//         {
//           key: 'a52',
//           color: '#FFF',
//         },
//         {
//           key: 'a53',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a6',
//       data: [
//         {
//           key: 'a60',
//           color: 'yellow',
//         },
//         {
//           key: 'a61',
//           color: '#FFF',
//         },
//         {
//           key: 'a62',
//           color: '#FFF',
//         },
//         {
//           key: 'a63',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a7',
//       data: [
//         {
//           key: 'a70',
//           color: 'yellow',
//         },
//         {
//           key: 'a71',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a8',
//       data: [
//         {
//           key: 'a80',
//           color: 'yellow',
//         },
//         {
//           key: 'a81',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a9',
//       data: [
//         {
//           key: 'a90',
//           color: 'yellow',
//         },
//         {
//           key: '191',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a10',
//       data: [
//         {
//           key: 'a100',
//           color: 'yellow',
//         },
//         {
//           key: 'a101',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a11',
//       data: [
//         {
//           key: 'a110',
//           color: 'yellow',
//         },
//         {
//           key: 'a111',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a12',
//       data: [
//         {
//           key: 'a120',
//           color: '#FFF',
//         },
//         {
//           key: 'a121',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a13',
//       data: [
//         {
//           key: 'a130',
//           color: '#FFF',
//         },
//         {
//           key: 'a131',
//           color: '#FFF',
//         },
//         {
//           key: 'a132',
//           color: '#FFF',
//         },
//         {
//           key: 'a133',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a14',
//       data: [
//         {
//           key: 'a140',
//           color: '#FFF',
//         },
//         {
//           key: 'a141',
//           color: '#FFF',
//         },
//         {
//           key: 'a142',
//           color: '#FFF',
//         },
//         {
//           key: 'a143',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a15',
//       data: [
//         {
//           key: 'a150',
//           color: '#FFF',
//         },
//         {
//           key: 'a151',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a16',
//       data: [
//         {
//           key: 'a160',
//           color: '#FFF',
//         },
//         {
//           key: 'a161',
//           color: '#FFF',
//         },
//         {
//           key: 'a162',
//           color: '#FFF',
//         },
//         {
//           key: 'a163',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a17',
//       data: [
//         {
//           key: 'a170',
//           color: '#FFF',
//         },
//         {
//           key: 'a171',
//           color: '#FFF',
//         },
//         {
//           key: 'a172',
//           color: '#FFF',
//         },
//         {
//           key: 'a173',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a18',
//       data: [
//         {
//           key: 'a180',
//           color: '#FFF',
//         },
//         {
//           key: 'a181',
//           color: '#FFF',
//         },
//       ],
//     },
//     {
//       title: 'a19',
//       data: [
//         {
//           key: 'a190',
//           color: '#FFF',
//         },
//         {
//           key: 'a191',
//           color: '#FFF',
//         },
//       ],
//     },
//   ]);

//   const updateRecord = (key, item) => {
//     console.log('item to update : ', key, item);
//     // let list = [...data[];
//     let selected = data[0].a10;
//     console.log('selected  : ', selected);
//     // const newData = selected?.map(element => {
//     //   if (element?.key == item?.key) {
//     //     return {
//     //       ...element,
//     //color: '#FFF',
//     //     };
//     //   } else {
//     //     return {
//     //       ...element,
//     //     };
//     //   }
//     // });
//     // list[key] = newData;
//     // setArr(list);
//   };
//   const updateRecord1 = (key, item) => {
//     console.log('item to update : ', key, item);
//     let list = [...arr];
//     let selected = arr[key];
//     const newData = selected?.map(element => {
//       if (element?.key == item?.key) {
//         return {
//           ...element,
//         color: '#FFF',
//         };
//       } else {
//         return {
//           ...element,
//         };
//       }
//     });
//     list[key] = newData;
//     setArr(list);
//   };
//   const updateRecord2 = (item, index, key) => {
//     console.log('item to update : ', item, index, key);
//     let list = [...arr1];
//     let selected = arr1[index];
//     // console.log('selected  : ', selected);
//     const newData = selected?.data?.map(element => {
//       if (element?.key == key) {
//         return {
//           ...element,
//           color: '#FFF',
//         };
//       } else {
//         return {
//           ...element,
//         };
//       }
//     });

//     // console.log('newData  : ', newData);
//     list[index] = {
//       title: item?.title,
//       data: newData,
//     };
//     setArr1(list);
//   };

//   return (
//     <View style={styles.container}>
//       <View style={{flexDirection: 'row'}}>
//         {/* {Object.entries(data[0])?.map(([key, value], i) => {
//           return (
//             <View key={i} style={styles.graphView}>
//               <Text style={{color: '#000', width: 35}}>{key}</Text>
//               {value?.map((e, i) => (
//                 <TouchableOpacity
//                   onPress={() => {
//                     updateRecord(key, e);
//                   }}
//                   style={{
//                     height: 20,
//                     flex: 1,
//                     borderWidth: 1,
//                     backgroundColor: e.color,
//                   }}></TouchableOpacity>
//               ))}
//             </View>
//           );
//         })} */}

//         {/* {arr.map((item, key) => {
//           return (
//             <View style={styles.graphView}>
//               <Text>a1 </Text>
//               {item?.map(e => {
//                 return (
//                   <TouchableOpacity
//                     onPress={() => {
//                       updateRecord(key, e);
//                     }}
//                     style={{
//                       height: 30,
//                       flex: 1,
//                       borderWidth: 1,
//                       backgroundColor: e?.color,
//                     }}></TouchableOpacity>
//                 );
//               })}
//             </View>
//           );
//         })} */}

//         <FlatList
//           //   style={{flexDirection: 'column-reverse'}}
//           data={arr1}
//           inverted
//           renderItem={({item, index}) => {
//             return (
//               <View style={styles.graphView}>
//                 <Text
//                   style={{
//                     color: '#000',
//                     textTransform: 'capitalize',
//                     width: 35,
//                   }}>
//                   {item?.title}{' '}
//                 </Text>
//                 <View style={{width: 500, flexGrow: 1}}>
//                   <FlatList
//                     data={item?.data}
//                     horizontal
//                     keyExtractor={(item, index) => index.toString()}
//                     renderItem={element => {
//                       return (
//                         <TouchableOpacity
//                           onPress={() => {
//                             updateRecord2(item, index, element.item.key);
//                           }}
//                           style={{
//                             height: 30,
//                             // flex: 1,
//                             width: 190 / item?.data?.length,
//                             borderWidth: 1,
//                             backgroundColor: element?.item?.color,
//                           }}></TouchableOpacity>
//                       );
//                     }}
//                   />
//                 </View>
//               </View>
//             );
//           }}
//         />
//         {/* {arr1?.length > 0 &&
//           arr1?.map((item, key) => {
//             return (
//               <View style={styles.graphView}>
//                 <Text style={{color: '#000', width: 35}}>{item?.title} </Text>
//                 {item?.data?.map(e => {
//                 return (
//                   <TouchableOpacity
//                     onPress={() => {
//                       updateRecord2(item, key, e.key);
//                     }}
//                     style={{
//                       height: 30,
//                       flex: 1,
//                       borderWidth: 1,
//                       backgroundColor: e?.color,
//                     }}></TouchableOpacity>
//                 );
//               })}
//               </View>
//             );
//           })} */}
//       </View>
//       {/* <View style={{flexDirection: 'row', backgroundColor: 'red', width: 170}}>
//         <View style={{height: 20, flex: 1, borderWidth: 1}}></View>
//         <View style={{height: 20, flex: 1, borderWidth: 1}}></View>
//         <View style={{height: 20, flex: 1, borderWidth: 1}}></View>
//         <View style={{height: 20, flex: 1, borderWidth: 1}}></View>
//       </View> */}
//     </View>
//   );
// };

// export default Graph;

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#FFF',
//     justifyContent: 'flex-end',
//     padding: 20,
//   },

//   graphView: {
//     flexDirection: 'row',
//     // backgroundColor: 'red',
//     width: 170,
//   },
// });
