import {StyleSheet, Text, View, ScrollView} from 'react-native';
import React, {useState, useEffect} from 'react';
import AuthHeader from '../../components/AuthHeader';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appColors from '../../../assets/colors';
import appFonts from '../../../assets/fonts';
import CTextInput from '../../components/CTextInput';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import CButton from '../../components/CButton/CButton';

import api from '../../constants/api';
import Loader from '../../components/Loader';
import Snackbar from 'react-native-snackbar';

const ForgetPassword = ({navigation}) => {
  const [email, setEmail] = useState('');
  const [isActive, setIsActive] = useState(false);

  const [loading, setLoading] = useState(false);

  const validate = email => {
    let reg = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w\w+)+$/;

    if (email?.length == 0) {
      Snackbar.show({
        text: 'Please Enter your email address',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (reg.test(email) == false) {
      Snackbar.show({
        text: 'Please Enter valid email address.',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else {
      return true;
    }
  };
  const handleSendCode = () => {
    if (validate(email)) {
      setLoading(true);
      var requestOptions = {
        method: 'POST',
        body: JSON.stringify({
          email: email,
        }),
        headers: {
          'Content-Type': 'application/json',
        },
      };
      fetch(api.send_OTP, requestOptions)
        .then(response => response.json())
        .then(async result => {
          console.log('response :   ', result);
          if (result) {
            let message = `Verification code sent to ${email} successfully.`;
            Snackbar.show({
              text: message,
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'green',
            });
            navigation?.replace('Verification', {
              email: email,
              code: result?.data?.otp,
            });
          } else {
            Snackbar.show({
              text: result?.message,
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'red',
            });
          }
        })
        .catch(error => {
          console.log('error raised  :  ', error);
          Snackbar.show({
            text: 'Something went wrong',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        })
        .finally(() => setLoading(false));
    }
  };
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <AuthHeader showLogo={true} showBackIcon />
        {loading && <Loader />}
        <View style={{flex: 1, alignItems: 'center'}}>
          <Text style={styles.heading}>Forgot your password?</Text>
          <CTextInput
            heading={'Email'}
            state={email}
            onChangeText={txt => setEmail(txt)}
            placeholder={'Enter your email'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="email"
            containerStyle={{width: wp(85)}}
            leftIcon={
              <MaterialCommunityIcons
                name="email"
                size={wp(5)}
                color={isActive == 'email' ? appColors.primary : '#D2D2D2'}
              />
            }
          />
          <CButton
            title="Send Verification Code"
            width={wp(80)}
            onPress={() => handleSendCode()}
          />
          <CButton
            title="Cancel"
            width={wp(50)}
            onPress={() => navigation?.goBack()}
          />
        </View>
      </ScrollView>
    </View>
  );
};

export default ForgetPassword;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  heading: {
    color: appColors.dark,
    fontSize: 22,
    fontFamily: appFonts.Time_New_Roman_Bold,
    marginBottom: hp(4),
  },
});
