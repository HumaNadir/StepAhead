import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import React, {useState} from 'react';
import appColors from '../../../../assets/colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appFonts from '../../../../assets/fonts';
import Header from '../../../components/Header';
import CTextInput from '../../../components/CTextInput';
import Feather from 'react-native-vector-icons/Feather';
import CButton from '../../../components/CButton/CButton';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import FontistoIcon from 'react-native-vector-icons/Fontisto';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

import api from '../../../constants/api';
import Loader from '../../../components/Loader';
import Snackbar from 'react-native-snackbar';

const RegisterStudent = () => {
  const [studentName, setStudentName] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [email, setEmail] = useState('');
  const [contactNo, setContactNo] = useState('');
  const [address, setAddress] = useState('');
  const [picture, setPicture] = useState('');
  const [pictureName, setPictureName] = useState('');
  const [pictureType, setPictureType] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [loading, setLoading] = useState(false);

  //pick image from gallery if
  const handleImagePicker = async () => {
    var options = {
      storageOptions: {
        skipBackup: true,
        path: 'images',
      },
      maxWidth: 500,
      maxHeight: 500,
      quality: 0.5,
    };
    await launchImageLibrary(options)
      .then(res => {
        setPictureName(res?.assets[0]?.fileName);
        setPictureType(res?.assets[0]?.type);
        setPicture(res?.assets[0]?.uri);
      })
      .catch(error => {
        console.log('error  :  ', error);
      });
  };

  const validate = () => {
    let reg = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w\w+)+$/;
    const re = /^[A-Za-z]+$/;
    console.log('re.test(studentName)  : ', re.test(studentName));

    if (studentName?.length == 0) {
      Snackbar.show({
        text: 'Please Enter Student Name',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (fatherName.length == 0) {
      Snackbar.show({
        text: 'Please Enter Student Father Name',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (re.test(studentName) != true) {
      Snackbar.show({
        text: 'Student Name Must be alphabet',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (re.test(fatherName) != true) {
      Snackbar.show({
        text: 'Father Name Must be alphabet',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (email?.length == 0) {
      Snackbar.show({
        text: 'Please Enter student email address',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (reg.test(email) == false) {
      Snackbar.show({
        text: 'Please Enter valid email address.',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (contactNo?.length < 11) {
      Snackbar.show({
        text: 'Please Enter 11 digit Contact Number',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (address.length == 0) {
      Snackbar.show({
        text: 'Please Enter Student Address',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
    } else if (pictureName?.length == 0) {
      Snackbar.show({
        text: 'Please Choose Student Profile Image',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
    } else if (password?.length == 0) {
      Snackbar.show({
        text: 'Please Enter student password',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (password.length < 6) {
      Snackbar.show({
        text: 'Password length must be at least 6 characters long',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else {
      return true;
    }
  };

  const handleRegisterStudent = () => {
    // navigation.navigate('RegisterStudent');
    // navigation.navigate('TabNavigation');

    if (validate()) {
      setLoading(true);

      const formData = new FormData();
      formData.append('user_name', studentName);
      formData.append('father_name', fatherName);
      formData.append('email', email);
      formData.append('contact_no', contactNo);
      formData.append('address', address);
      let imageObj = {
        uri: picture,
        type: pictureType,
        name: pictureName,
      };
      console.log('imageObj  :   ', imageObj);
      formData.append('image', imageObj);
      formData.append('password', password);
      formData.append('user_type', 'student');
      var requestOptions = {
        method: 'POST',
        body: formData,
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      };
      fetch(api.register, requestOptions)
        .then(response => response.json())
        .then(async result => {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'green',
          });
          resetAllFields();
        })
        .catch(error => {
          console.log('error raised  :  ', error);
          Snackbar.show({
            text: 'Something went wrong',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        })
        .finally(() => setLoading(false));
    }
  };

  const resetAllFields = () => {
    setStudentName('');
    setFatherName('');
    setEmail('');
    setContactNo('');
    setAddress('');
    setPictureName('');
    setPassword('');
  };
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <Header title={'Register Student'} />
        {loading && <Loader />}
        <View style={{flex: 1, alignItems: 'center'}}>
          <CTextInput
            state={studentName}
            onChangeText={txt => setStudentName(txt)}
            placeholder={'Student Name'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="studentName"
          />
          <CTextInput
            state={fatherName}
            onChangeText={txt => setFatherName(txt)}
            placeholder={'Father Name'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="fatherName"
          />
          <CTextInput
            state={email}
            onChangeText={txt => setEmail(txt)}
            placeholder={'abc@gmail.com'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="email"
          />
          <CTextInput
            state={contactNo}
            onChangeText={txt => setContactNo(txt)}
            placeholder={'03xx-xxxxxxx'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="contactNo"
          />
          <CTextInput
            state={address}
            onChangeText={txt => setAddress(txt)}
            placeholder={'Address'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="address"
          />
          <View style={styles.textInputContainer}>
            <View style={{...styles.txtInputView}}>
              <View style={{flex: 1}}>
                {pictureName ? (
                  <Text
                    style={{flex: 0.8, color: appColors.dark, fontSize: 13}}>
                    {pictureName}
                  </Text>
                ) : (
                  <Text>Image</Text>
                )}
              </View>

              <TouchableOpacity onPress={() => handleImagePicker()}>
                <Feather name="upload" size={25} color={appColors.dark} />
              </TouchableOpacity>
            </View>
            <CTextInput
              state={password}
              onChangeText={txt => setPassword(txt)}
              secureTextEntry={!showPassword}
              placeholder={'Password'}
              id="password"
              setIsActive={setIsActive}
              containerStyle={{width: wp(85)}}
              leftIcon={
                <FontistoIcon
                  name="locked"
                  size={wp(5)}
                  color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
                />
              }
              rightIcon={
                <EntypoIcon
                  onPress={() => setShowPassword(!showPassword)}
                  name={!showPassword ? 'eye-with-line' : 'eye'}
                  size={wp(5)}
                  color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
                />
              }
            />
          </View>
          <CButton title="Register" onPress={() => handleRegisterStudent()} />
        </View>
      </ScrollView>
    </View>
  );
};

export default RegisterStudent;

const styles = StyleSheet.create({
  textInputContainer: {
    marginVertical: hp(2),
    width: wp(85),
  },
  txtInputView: {
    borderWidth: 1.2,
    borderColor: '#D2D2D2',
    borderRadius: wp(1.5),
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: wp(2.5),
    height: hp(6.4),
  },
});
