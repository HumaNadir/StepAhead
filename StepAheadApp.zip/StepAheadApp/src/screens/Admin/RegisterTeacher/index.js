import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import React, {useState} from 'react';
import appColors from '../../../../assets/colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appFonts from '../../../../assets/fonts';
import Header from '../../../components/Header';
import CTextInput from '../../../components/CTextInput';
import Feather from 'react-native-vector-icons/Feather';
import CButton from '../../../components/CButton/CButton';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import FontistoIcon from 'react-native-vector-icons/Fontisto';

import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import DocumentPicker, {types} from 'react-native-document-picker';

import api from '../../../constants/api';
import Snackbar from 'react-native-snackbar';
import Loader from '../../../components/Loader';

const RegisterTeacher = () => {
  const [teacherName, setTeacherName] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [email, setEmail] = useState('');
  const [contactNo, setContactNo] = useState('');
  const [address, setAddress] = useState('');
  const [picture, setPicture] = useState('');
  const [pictureName, setPictureName] = useState('');
  const [pictureType, setPictureType] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [loading, setLoading] = useState(false);

  const [file, setFile] = useState({
    name: '',
    uri: '',
    type: '',
  });

  const handleCVPick = async () => {
    try {
      const response = await DocumentPicker.pick({
        presentationStyle: 'fullScreen',
        type: [types.pdf],
      });
      setFile({
        name: response[0].name,
        uri: response[0].uri,
        type: response[0].type,
      });
    } catch (err) {
      console.warn(err);
    }
  };

  const validate = () => {
    let reg = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w\w+)+$/;
    const re = /^[A-Za-z]+$/;

    if (teacherName?.length == 0) {
      Snackbar.show({
        text: 'Please Enter Teacher Name',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (re.test(teacherName) != true) {
      Snackbar.show({
        text: 'Teacher Name Must be alphabet',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (email?.length == 0) {
      Snackbar.show({
        text: 'Please Enter student email address',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (reg.test(email) == false) {
      Snackbar.show({
        text: 'Please Enter valid email address.',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (contactNo?.length < 11) {
      Snackbar.show({
        text: 'Please Enter 11 digit Contact Number',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (address.length == 0) {
      Snackbar.show({
        text: 'Please Enter Student Address',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
    } else if (file?.name?.length == 0) {
      Snackbar.show({
        text: 'Please Upload CV',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
    } else if (password?.length == 0) {
      Snackbar.show({
        text: 'Please Enter teacher password',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (password.length < 6) {
      Snackbar.show({
        text: 'Password length must be at least 6 characters long',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else {
      return true;
    }
  };

  const handleRegisterTeacher = () => {
    // navigation.navigate('RegisterStudent');
    // navigation.navigate('TabNavigation');

    if (validate()) {
      setLoading(true);

      const formData = new FormData();
      formData.append('user_name', teacherName);
      // formData.append('father_name', fatherName);
      formData.append('contact_no', contactNo);
      formData.append('email', email);
      formData.append('address', address);
      formData.append('cv', file);
      formData.append('password', password);
      formData.append('user_type', 'teacher');
      var requestOptions = {
        method: 'POST',
        body: formData,
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      };
      fetch(api.register, requestOptions)
        .then(response => response.json())
        .then(async result => {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'green',
          });
          resetAllFields();
        })
        .catch(error => {
          console.log('error raised  :  ', error);
          Snackbar.show({
            text: 'Something went wrong',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        })
        .finally(() => setLoading(false));
    }
  };

  const resetAllFields = () => {
    setTeacherName('');
    setContactNo('');
    setEmail('');
    setAddress('');
    setFile({
      name: '',
      uri: '',
      type: '',
    });
    setPassword('');
  };

  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <Header title={'Add Teacher'} />
        <View style={{flex: 1, alignItems: 'center'}}>
          <CTextInput
            state={teacherName}
            onChangeText={txt => setTeacherName(txt)}
            placeholder={'Teacher Name'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="teacherName"
          />
          <CTextInput
            state={contactNo}
            onChangeText={txt => setContactNo(txt)}
            placeholder={'03xx-xxxxxxx'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="contactNo"
          />
          <CTextInput
            state={email}
            onChangeText={txt => setEmail(txt)}
            placeholder={'abc@gmail.com'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="email"
          />

          <CTextInput
            state={address}
            onChangeText={txt => setAddress(txt)}
            placeholder={'Address'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="address"
          />
          <View style={styles.textInputContainer}>
            <View style={styles.txtInputView}>
              <View
                style={{
                  flex: 1,
                }}>
                {file.name ? (
                  <Text
                    style={{
                      width: '90%',
                      color: appColors.dark,
                      fontSize: 13,
                    }}>
                    {file.name}
                  </Text>
                ) : (
                  <Text style={{marginLeft: 15, color: '#D5D5D5'}}>CV</Text>
                )}
              </View>

              <TouchableOpacity onPress={() => handleCVPick()}>
                <Feather name="upload" size={25} color={appColors.dark} />
              </TouchableOpacity>
            </View>
          </View>
          <CTextInput
            state={password}
            onChangeText={txt => setPassword(txt)}
            secureTextEntry={!showPassword}
            placeholder={'Password'}
            id="password"
            setIsActive={setIsActive}
            containerStyle={{width: wp(85)}}
            leftIcon={
              <FontistoIcon
                name="locked"
                size={wp(5)}
                color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
              />
            }
            rightIcon={
              <EntypoIcon
                onPress={() => setShowPassword(!showPassword)}
                name={!showPassword ? 'eye-with-line' : 'eye'}
                size={wp(5)}
                color={isActive == 'password' ? appColors.primary : '#D2D2D2'}
              />
            }
          />
          <View
            style={{
              flex: 0.7,
              justifyContent: 'flex-end',
            }}>
            <CButton
              title="ADD"
              loading={loading}
              onPress={() => handleRegisterTeacher()}
            />
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default RegisterTeacher;

const styles = StyleSheet.create({
  textInputContainer: {
    marginVertical: hp(2),
    width: wp(85),
  },
  txtInputView: {
    borderWidth: 1.2,
    borderColor: '#D2D2D2',
    borderRadius: wp(1.5),
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: wp(2.5),
    height: hp(6.4),
  },
});
