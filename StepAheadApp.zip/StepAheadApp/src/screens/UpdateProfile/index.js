import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Image,
  InputAccessoryView,
} from 'react-native';
import React, {useState, useEffect} from 'react';
import appColors from '../../../assets/colors';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import appFonts from '../../../assets/fonts';
import Header from '../../components/Header';
import CTextInput from '../../components/CTextInput';
import Feather from 'react-native-vector-icons/Feather';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import FontistoIcon from 'react-native-vector-icons/Fontisto';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import CButton from '../../components/CButton/CButton';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import appImages from '../../../assets/images';

import Loader from '../../components/Loader';
import api, {BASE_URL_Image} from '../../constants/api';
import Snackbar from 'react-native-snackbar';
import AsyncStorage from '@react-native-async-storage/async-storage';

const UpdateProfile = ({navigation}) => {
  const [studentName, setStudentName] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [email, setEmail] = useState('');
  const [contactNo, setContactNo] = useState('');
  const [address, setAddress] = useState('');
  const [picture, setPicture] = useState('');
  const [pictureName, setPictureName] = useState('');
  const [pictureType, setPictureType] = useState('');
  const [isActive, setIsActive] = useState(false);

  const [userName, setUserName] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [phoneNo, setPhoneNo] = useState('');

  const [showCurrentPass, setShowCurrentPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);

  const [loading, setLoading] = useState(false);

  //pick image from gallery if
  const handleImagePicker = async () => {
    var options = {
      storageOptions: {
        skipBackup: true,
        path: 'images',
      },
      maxWidth: 500,
      maxHeight: 500,
      quality: 0.5,
    };
    await launchImageLibrary(options)
      .then(res => {
        setPictureName(res?.assets[0]?.fileName);
        setPictureType(res?.assets[0]?.type);
        setPicture(res?.assets[0]?.uri);
        updateImage(
          res?.assets[0]?.uri,
          res?.assets[0]?.type,
          res?.assets[0]?.fileName,
        );
      })
      .catch(error => {
        console.log('error  :  ', error);
      });
  };
  const handleLogout = async () => {
    await AsyncStorage.clear();
    navigation?.popToTop();
    navigation?.navigate('Login');
  };

  useEffect(() => {
    getUserDetail();
  }, []);

  const getUserDetail = async () => {
    setLoading(true);
    let user_id = await AsyncStorage.getItem('user_id');
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };

    fetch(`${api.get_specific_user}/${user_id}`, requestOptions)
      .then(response => response.json())
      .then(result => {
        if (result?.statusCode == 200) {
          let user_detail = result?.result;
          setUserName(user_detail?.user_name);
          setPhoneNo(user_detail?.contact_no);
          setAddress(user_detail?.address);
          if (user_detail?.image) {
            setPicture(BASE_URL_Image + user_detail?.image);
          }
          console.log('user_detail?.image  : ', user_detail?.image);
        } else {
          Snackbar.show({
            text: result?.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        }
      })
      .catch(error => console.log('error', error))
      .finally(() => setLoading(false));
  };

  const validate = () => {
    let reg = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w\w+)+$/;
    const re = /^[A-Za-z]+$/;

    if (userName.length == 0) {
      Snackbar.show({
        text: 'Please Enter S Name',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (re.test(userName) != true) {
      Snackbar.show({
        text: 'Name Must be alphabet',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (phoneNo?.length < 11) {
      Snackbar.show({
        text: 'Please Enter 11 digit Contact Number',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
      return false;
    } else if (address.length == 0) {
      Snackbar.show({
        text: 'Please Enter Address',
        duration: Snackbar.LENGTH_SHORT,
        backgroundColor: 'red',
      });
    } else {
      return true;
    }
  };

  const handleUpdateUser = async () => {
    if (validate()) {
      setLoading(true);
      let user_id = await AsyncStorage.getItem('user_id');
      var requestOptions = {
        method: 'PUT',
        body: JSON.stringify({
          user_id: user_id,
          user_name: userName,
          contact_no: phoneNo,
          address: address,
        }),
        headers: {
          'Content-Type': 'application/json',
        },
      };
      fetch(api.update_user, requestOptions)
        .then(response => response.json())
        .then(async result => {
          console.log('response :   ', result);
          if (result?.statusCode == 200) {
            await AsyncStorage.setItem('user', JSON.stringify(result?.result));
            Snackbar.show({
              text: 'Profile Updated Successfully',
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'green',
            });
          } else {
            Snackbar.show({
              text: result?.message,
              duration: Snackbar.LENGTH_SHORT,
              backgroundColor: 'red',
            });
          }
        })
        .catch(error => {
          console.log('error raised  :  ', error);
          Snackbar.show({
            text: 'Something went wrong',
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: 'red',
          });
        })
        .finally(() => setLoading(false));
    }
  };

  const updateImage = async (uri, type, name) => {
    let user_id = await AsyncStorage.getItem('user_id');
    setLoading(true);
    const formData = new FormData();
    let imageObj = {
      uri: uri,
      type: type,
      name: name,
    };
    console.log('user_id  : ', user_id);
    console.log('image  : ', imageObj);
    formData.append('user_id', user_id);
    formData.append('image', imageObj);

    var requestOptions = {
      method: 'PUT',
      body: formData,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    };
    fetch(api.update_image, requestOptions)
      .then(response => response.json())
      .then(async result => {
        console.log('result  : ', result);
        Snackbar.show({
          text: result?.message,
          duration: Snackbar.LENGTH_SHORT,
          backgroundColor: 'green',
        });
      })
      .catch(error => {
        console.log('error raised  :  ', error);
        Snackbar.show({
          text: 'Something went wrong',
          duration: Snackbar.LENGTH_SHORT,
          backgroundColor: 'red',
        });
      })
      .finally(() => setLoading(false));
  };

  const handleUpdatePassword = async () => {
    let user = await AsyncStorage.getItem('user');
    if (user) {
      let parse = JSON.parse(user);
      navigation?.navigate('ChangePassword', {
        email: parse?.email,
        screen: 'UpdateProfile',
      });
    }
  };
  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <ScrollView contentContainerStyle={{height: hp(100), width: wp(100)}}>
        <Header
          title={'Update Profile'}
          rightIcon={
            <TouchableOpacity onPress={() => handleLogout()}>
              <MaterialCommunityIcons name="logout" size={25} color="#FFF" />
            </TouchableOpacity>
          }
        />
        {loading && <Loader />}
        <View style={{flex: 1, alignItems: 'center'}}>
          <View
            style={{
              width: wp(40),
              height: wp(40),
              borderRadius: wp(40) / 2,

              marginVertical: 18,

              //   overflow: 'hidden',
            }}>
            {picture ? (
              <Image
                source={{uri: picture}}
                style={{
                  width: wp(40),
                  height: wp(40),
                  borderRadius: wp(40) / 2,
                  borderWidth: 1,
                  borderColor: appColors.primary,
                  // width: wp(26),
                  // height: wp(26),
                  // borderRadius: wp(40) / 2,
                  // tintColor: appColors.primary,
                  resizeMode: 'contain',
                }}
              />
            ) : (
              <View
                style={{
                  width: wp(40),
                  height: wp(40),
                  borderRadius: wp(40) / 2,
                  overflow: 'hidden',
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderWidth: 1,
                  borderColor: appColors.primary,
                }}>
                <Image
                  source={appImages.profile}
                  style={{
                    width: wp(26),
                    height: wp(26),
                    // borderRadius: wp(40) / 2,
                    tintColor: appColors.primary,
                    resizeMode: 'contain',
                  }}
                />
              </View>
            )}
            <TouchableOpacity
              onPress={() => handleImagePicker()}
              style={{position: 'absolute', right: -10, top: '60%', zIndex: 1}}>
              <FontAwesome name="camera" size={30} color={appColors.primary} />
            </TouchableOpacity>
          </View>
          <CTextInput
            state={userName}
            onChangeText={txt => setUserName(txt)}
            placeholder={'User Name'}
            setIsActive={setIsActive}
            isActive={isActive}
            containerStyle={{width: wp(85)}}
            id="userName"
            leftIcon={
              <FontAwesome
                name="user"
                size={wp(5)}
                color={isActive == 'userName' ? appColors.primary : '#D2D2D2'}
              />
            }
          />

          {/* <CTextInput
            state={currentPassword}
            onChangeText={txt => setCurrentPassword(txt)}
            placeholder={'Current Password'}
            secureTextEntry={!showCurrentPass}
            id="currentPassword"
            setIsActive={setIsActive}
            containerStyle={{width: wp(85)}}
            leftIcon={
              <FontistoIcon
                name="locked"
                size={wp(5)}
                color={
                  isActive == 'currentPassword' ? appColors.primary : '#D2D2D2'
                }
              />
            }
            rightIcon={
              <EntypoIcon
                onPress={() => setShowCurrentPass(!showCurrentPass)}
                name={!showCurrentPass ? 'eye-with-line' : 'eye'}
                size={wp(5)}
                color={
                  isActive == 'currentPassword' ? appColors.primary : '#D2D2D2'
                }
              />
            }
          />

          <CTextInput
            state={newPassword}
            onChangeText={txt => setNewPassword(txt)}
            placeholder={'New Password'}
            secureTextEntry={!showNewPass}
            id="newPassword"
            setIsActive={setIsActive}
            containerStyle={{width: wp(85)}}
            leftIcon={
              <FontistoIcon
                name="locked"
                size={wp(5)}
                color={
                  isActive == 'newPassword' ? appColors.primary : '#D2D2D2'
                }
              />
            }
            rightIcon={
              <EntypoIcon
                onPress={() => setShowNewPass(!showNewPass)}
                name={!showNewPass ? 'eye-with-line' : 'eye'}
                size={wp(5)}
                color={
                  isActive == 'newPassword' ? appColors.primary : '#D2D2D2'
                }
              />
            }
          /> */}

          <CTextInput
            state={phoneNo}
            onChangeText={txt => setPhoneNo(txt)}
            placeholder={'03xx-xxxxxxx'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="phoneNo"
            containerStyle={{width: wp(85)}}
            keyboardType={'phone-pad'}
            leftIcon={
              <EntypoIcon
                name="phone"
                size={wp(5)}
                color={isActive == 'phoneNo' ? appColors.primary : '#D2D2D2'}
              />
            }
          />
          <CTextInput
            state={address}
            onChangeText={txt => setAddress(txt)}
            placeholder={'Address'}
            setIsActive={setIsActive}
            isActive={isActive}
            id="address"
            containerStyle={{width: wp(85)}}
            // leftIcon={
            //   <EntypoIcon
            //     name="phone"
            //     size={wp(5)}
            //     color={isActive == 'address' ? appColors.primary : '#D2D2D2'}
            //   />
            // }
          />

          <CButton title="Update" onPress={() => handleUpdateUser()} />
          <CButton
            title="Change Password"
            transparent
            style={{borderWidth: 1, borderColor: appColors.primary}}
            onPress={() => handleUpdatePassword()}
          />
        </View>
      </ScrollView>
    </View>
  );
};

export default UpdateProfile;

const styles = StyleSheet.create({
  textInputContainer: {
    marginVertical: hp(2),
    width: wp(90),
  },
  txtInputView: {
    borderWidth: 1.2,
    borderColor: '#D2D2D2',
    borderRadius: wp(1.5),
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: wp(2.5),
    height: hp(6.4),
  },
});
