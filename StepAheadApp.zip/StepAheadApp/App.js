import {StatusBar, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';

import AccountType from './src/screens/AccountType';
import Login from './src/screens/Login';
import ForgetPassword from './src/screens/ForgetPassword';
import Verification from './src/screens/Verification';
import ChangePassword from './src/screens/ChangePassword';

//admin
import RegisterTeacher from './src/screens/Admin/RegisterTeacher';
import RegisterStudent from './src/screens/Admin/RegisterStudent';

import TabNavigation from './src/Navigation/TabNavigation';
import TabNavigation_Teacher from './src/Navigation/TabNavigation_Teacher';
import TabNavigation_Student from './src/Navigation/TabNavigation_Student';

import CreateClass from './src/screens/Classes/CreateClass';
import ClassDetail from './src/screens/Classes/ClassDetail';

import Attendance from './src/screens/Classes/Attendance';
import AttendanceStudent from './src/screens/Classes/Attendance/AttendanceStudent';

import DrawerNavigation_Student from './src/Navigation/DrawerNavigation_Student';
import DrawerNavigation_Teacher from './src/Navigation/DrawerNavigation_Teacher';
import DrawerNavigation_Admin from './src/Navigation/DrawerNavigation_Admin';

import Splash from './src/screens/Splash';
import ChooseOptions from './src/screens/Classes/ChooseOptions';
import Students from './src/screens/Classes/Students';
import MarkTodayActivity from './src/screens/TodayActivity/MarkTodayActivity';
import ViewTodayActivity from './src/screens/TodayActivity/ViewTodayActivity';
import Conversations from './src/screens/Chat/Conversations';
import Graph from './src/screens/Graph';

import {firebase} from '@react-native-firebase/storage';

// Import the functions you need from the SDKs you need
import {initializeApp} from 'firebase/app';
import appColors from './assets/colors';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: 'AIzaSyALLbfjgaScfLE96lH7oH3zLh3LlKupSNA',
  authDomain: 'steapahead-c979a.firebaseapp.com',
  databaseURL: 'https://steapahead-c979a-default-rtdb.firebaseio.com',
  projectId: 'steapahead-c979a',
  storageBucket: 'steapahead-c979a.appspot.com',
  messagingSenderId: '408878096103',
  appId: '1:408878096103:web:8f43da333600adc838cc42',
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
// export const storage = firebase.storage();
// export const storageRef = storage.ref();

const App = () => {
  const Stack = createStackNavigator();

  return (
    <NavigationContainer>
      <StatusBar
        backgroundColor={appColors.primary}
        barStyle={'light-content'}
      />
      <Stack.Navigator screenOptions={{headerShown: false}}>
        <Stack.Screen name="Splash" component={Splash} />
        <Stack.Screen name="Graph" component={Graph} />
        <Stack.Screen name="AccountType" component={AccountType} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="ForgetPassword" component={ForgetPassword} />
        <Stack.Screen name="Verification" component={Verification} />
        <Stack.Screen name="ChangePassword" component={ChangePassword} />
        <Stack.Screen name="RegisterTeacher" component={RegisterTeacher} />
        <Stack.Screen name="RegisterStudent" component={RegisterStudent} />
        <Stack.Screen name="CreateClass" component={CreateClass} />
        <Stack.Screen name="ClassDetail" component={ClassDetail} />
        <Stack.Screen
          name="DrawerNavigation_Teacher"
          component={DrawerNavigation_Teacher}
        />
        <Stack.Screen
          name="DrawerNavigation_Admin"
          component={DrawerNavigation_Admin}
        />
        <Stack.Screen
          name="DrawerNavigation_Student"
          component={DrawerNavigation_Student}
        />
        <Stack.Screen name="TabNavigation" component={TabNavigation} />
        <Stack.Screen
          name="TabNavigation_Teacher"
          component={TabNavigation_Teacher}
        />
        <Stack.Screen
          name="TabNavigation_Student"
          component={TabNavigation_Student}
        />
        <Stack.Screen name="Attendance" component={Attendance} />
        <Stack.Screen name="ChooseOptions" component={ChooseOptions} />
        <Stack.Screen name="Students" component={Students} />
        <Stack.Screen name="Conversations" component={Conversations} />
        <Stack.Screen name="MarkTodayActivity" component={MarkTodayActivity} />
        <Stack.Screen name="ViewTodayActivity" component={ViewTodayActivity} />
        <Stack.Screen name="AttendanceStudent" component={AttendanceStudent} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;

const styles = StyleSheet.create({});
